﻿Imports System.Web.UI.WebControls.Expressions
Imports System.Data
Imports System.Data.SqlClient

Partial Class Tracking_AssetInvVer
    Inherits System.Web.UI.Page

#Region " Declarations "
    Dim sql As String = ""
    'Dim str As String    
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        SwmsAccess.ValidateSession()

        If Not Page.IsPostBack Then
            lblTitle.Text = "Asset Inventory Verification"
            filterPanel.Visible = False
            subgroupdiv.Visible = False
            createNewDiv.Visible = False
            populateInvNameDropDown()
        End If
    End Sub

    Sub populateInvNameDropDown()

        Using dc As New AssetVerifyDataContext(SwmsAccess.GetSwmsConnection())
            Me.ddlInvName.DataSource = (From row In dc.AssetVerifyLocationsViews Order By row.SnapshotDate Descending
                Select New With {.InventoryName = row.InventoryName} Distinct).ToList()

            Me.ddlInvName.DataTextField = "InventoryName"
            Me.ddlInvName.DataValueField = "InventoryName"
            Me.ddlInvName.DataBind()

            Dim blankItem As New ListItem("---", "---")
            ddlInvName.Items.Insert(0, blankItem)

            Dim createNew As New ListItem("Create New", "New")
            ddlInvName.Items.Insert(1, createNew)

            If CStr(Session("InventoryName")) <> "" Then ' --- returned from count sheet; 
                ddlInvName.SelectedValue = CStr(Session("InventoryName"))
                populateSubGroupList()
            End If
        End Using
    End Sub

    Protected Sub ddlInvName_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlInvName.SelectedIndexChanged

        lblTotals.Text = ""
        lblTitle.Text = "Asset Inventory Verification"

        filterPanel.Visible = False
        subgroupdiv.Visible = False
        createNewDiv.Visible = False
        clearLocationListGridView()
        clearSubGroupView()

        Session("avLocation") = Nothing
        Session("avBuilding") = Nothing
        Session("avBin") = Nothing
        Session("avSubGroup") = Nothing
        Session("InventoryName") = Nothing
        Session("InvVerPage") = Nothing
        Session("alvId") = Nothing
        Session("viewMethod") = Nothing

        Select Case ddlInvName.SelectedValue
            Case "---"
            Case "New"
                lblTitle.Text = "Initiate New Annual Verification"
                createNewDiv.Visible = True

                sql = "select isnull(year(max(left(inventoryname,4))) + 1 , year(getdate()) - 1) as yr from  AssetVerSubGroupPercent"
                Dim rs As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, Nothing)
                If rs.Rows(0)("yr") > 0 Then
                    txtYear.Text = rs.Rows(0)("yr")
                End If
            Case Else
                populateSubGroupList()
        End Select

        Session("InventoryName") = ddlInvName.SelectedValue

    End Sub

    Protected Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Dim yearExists As Integer = 1
        
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyCreateSnapshot", SwmsAccess.GetSwmsConnection())

        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@year", Server.HtmlEncode(txtYear.Text.Trim))

        ' --- check if snapshot was already created for the year entered ---
        cmd.Parameters.Add("@yearExists", SqlDbType.Int)
        cmd.Parameters("@yearExists").Direction = ParameterDirection.Output

        SwmsAccess.ExecuteNonQuery(cmd)

        yearExists = cmd.Parameters("@yearExists").Value
        If yearExists > 0 Then ' --- yes
            lblTotals.Text = "Snapshot already exists for " & Server.HtmlEncode(txtYear.Text.Trim)
            txtYear.Text = ""
        Else
            populateInvNameDropDown()
            ddlInvName.SelectedValue = Server.HtmlEncode(txtYear.Text.Trim) & " Verification"
            populateSubGroupList()
            createNewDiv.Visible = False
        End If



    End Sub

#Region "SubGroups"
    Protected Sub LinqDataSource2_ContextCreating(sender As Object, e As LinqDataSourceContextEventArgs) Handles LinqDataSource2.ContextCreating
        e.ObjectInstance = New AssetVerifyDataContext(SwmsAccess.GetSwmsConnection())
    End Sub

    Sub populateSubGroupList()
      
        sql = "select distinct completedate,"
        sql &= "    (select count(avsgid) as cn from AssetVerSubGroupPercent "
        sql &= "    where inventoryname = avsg.InventoryName and percentage is null) as cn"
        sql &= " from AssetVerSubGroupPercent avsg"
        sql &= " where inventoryname = @inventoryName"

        Dim rs As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
            new SqlParameter("@InventoryName", Server.HtmlEncode(ddlInvName.SelectedValue))
        })


        If rs.Rows.Count > 0 Then
            If rs.Rows(0)("completedate") <> "" Then ' --- sub groups are finalized; no more editing subgroups. show location list
                ' --- populate readonly datagrid ---
                subGroupsRO.DataSource = LinqDataSource2
                subGroupsRO.DataBind()
                btnFinal.Visible = False
                updAllDiv.Visible = False
                populateLocationList()
            Else
                ' --- populate editable datagrid ---
                subGroups.DataSource = LinqDataSource2
                subGroups.DataBind()
                subGroupDiv.Visible = True

                btnFinal.Visible = True
                updAllDiv.Visible = True
                If rs.Rows(0)("cn") > 0 Then ' --- not all percentages have been entered, do not enable finalize button
                    btnFinal.Enabled = False
                    btnUpdAll.Enabled = True
                Else ' ----------------------------  all percentages have been entered,  enable finalize button
                    btnFinal.Enabled = True
                    btnUpdAll.Enabled = False
                End If
            End If
        End If

    End Sub

    Private Sub clearSubGroupView()
        subGroups.DataSource = Nothing
        subGroups.DataBind()

        subGroupsRO.DataSource = Nothing
        subGroupsRO.DataBind()
    End Sub

    Protected Sub subGroups_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles subGroups.RowDataBound

        If (DataBinder.Eval(e.Row.DataItem, "completedate")) <> "" Then
            e.Row.Cells(7).Text = ""
            e.Row.Cells(7).Width = Unit.Pixel(0)
        End If
  

        ' --- hides the id & complete date fields ---
        If e.Row.Cells.Count > 4 Then
            e.Row.Cells(0).Visible = False
            e.Row.Cells(1).Visible = False
        End If

    End Sub

    Protected Sub subGroups_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles subGroups.RowEditing
        subGroups.EditIndex = e.NewEditIndex
        populateSubGroupList()

        ' --- Put 100 as default value ---
        Dim avsgId As String = e.NewEditIndex.ToString
        Dim subGroupPercent As TextBox = DirectCast(subGroups.Rows(e.NewEditIndex).FindControl("txtPercent"), TextBox)
        If subGroupPercent.Text = "" Then
            subGroupPercent.Text = "100"
        End If
        subGroupPercent.Focus()

    End Sub

    Protected Sub subGroups_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles subGroups.RowCancelingEdit
        subGroups.EditIndex = -1
        populateSubGroupList()
    End Sub

    Protected Sub subGroups_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles subGroups.RowUpdating
        Dim avsgId As String = subGroups.DataKeys(e.RowIndex).Values("AVSGId").ToString()
        Dim subGroupPercent As TextBox = DirectCast(subGroups.Rows(e.RowIndex).FindControl("txtPercent"), TextBox)
        Dim myPercent As String = Server.HtmlEncode(subGroupPercent.Text)
        If CStr(subGroupPercent.Text) = "" Then
            myPercent = -1
        End If

        'onn.ConnectionString = Session("swmsDbConnection")
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerSubGroupExempt", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@avsgId", avsgId.ToString())
        cmd.Parameters.AddWithValue("@userId", Session("swmsUid"))
        cmd.Parameters.AddWithValue("@percent", myPercent)
        cmd.Parameters.AddWithValue("@invName", Server.HtmlEncode(ddlInvName.SelectedValue))
        cmd.Parameters.AddWithValue("@updateAll", "")

        SwmsAccess.ExecuteNonQuery(cmd)

        subGroups.EditIndex = -1
        populateSubGroupList()

    End Sub

    Protected Sub btnUpdAll_Click(sender As Object, e As EventArgs) Handles btnUpdAll.Click

        'conn.ConnectionString = Session("swmsDbConnection")
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerSubGroupExempt", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@avsgId", "0")
        cmd.Parameters.AddWithValue("@userId", Session("swmsUid"))
        cmd.Parameters.AddWithValue("@percent", Server.HtmlEncode(txtUpdAll.Text.Trim))
        cmd.Parameters.AddWithValue("@invName", Server.HtmlEncode(ddlInvName.SelectedValue))
        cmd.Parameters.AddWithValue("@updateAll", "yes")

        SwmsAccess.ExecuteNonQuery(cmd)

        txtUpdAll.Text = ""
        subGroups.EditIndex = -1
        populateSubGroupList()
    End Sub

    Protected Sub btnFinal_Click(sender As Object, e As EventArgs) Handles btnFinal.Click
        'conn.ConnectionString = Session("swmsDbConnection")
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerSubGroupExempt", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@avsgId", "0")
        cmd.Parameters.AddWithValue("@userId", "0")
        cmd.Parameters.AddWithValue("@percent", "0")
        cmd.Parameters.AddWithValue("@invName", Server.HtmlEncode(ddlInvName.SelectedValue))
        cmd.Parameters.AddWithValue("@updateAll", "final")

        SwmsAccess.ExecuteNonQuery(cmd)

        clearSubGroupView()
        txtUpdAll.Text = ""
        subGroups.EditIndex = -1
        populateSubGroupList()
    End Sub

#End Region

#Region "Locations"
    Protected Sub LinqDataSource1_ContextCreating(sender As Object, e As LinqDataSourceContextEventArgs) Handles LinqDataSource1.ContextCreating
        e.ObjectInstance = New AssetVerifyDataContext(SwmsAccess.GetSwmsConnection())

        If chkExempt.Checked = True Then
            If ddlSg.SelectedValue = "" Then
                LinqDataSource1.EntityTypeName = ""
                LinqDataSource1.TableName = "AssetVerifyLocationsExemptViews"
                LinqDataSource1.OrderBy = "Location, Building, Bin"
            Else
                LinqDataSource1.EntityTypeName = ""
                LinqDataSource1.TableName = "AssetVerifyLocationSubGroupExemptViews"
                LinqDataSource1.OrderBy = "Location, Building, Bin"
            End If
        Else
            If ddlSg.SelectedValue = "" Then
                LinqDataSource1.EntityTypeName = ""
                LinqDataSource1.TableName = "AssetVerifyLocationsViews"
                LinqDataSource1.OrderBy = "Location, Building, Bin"
            Else
                LinqDataSource1.EntityTypeName = ""
                LinqDataSource1.TableName = "AssetVerifyLocationSubGroupViews"
                LinqDataSource1.OrderBy = "Location, Building, Bin"
            End If
        End If

    End Sub

    Protected Sub FilterStatus(ByVal sender As Object, ByVal e As CustomExpressionEventArgs)

        If chkExempt.Checked = True Then
            If ddlSg.SelectedValue <> "" Then
                e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupExemptView)() Where (row.subgroup = ddlSg.SelectedValue)

                ' --- Parse out the % as wildcard ------------------------------------
                If CStr(txtBin.Text) <> "" Then
                    Dim str As String = Server.HtmlEncode(txtBin.Text.ToString)
                    If Left(str, 1) = "%" And Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupExemptView)() Where (row.Bin.Contains(Replace(str, "%", "")))
                    ElseIf Left(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupExemptView)() Where (row.Bin.EndsWith(Replace(str, "%", "")))
                    ElseIf Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupExemptView)() Where (row.Bin.StartsWith(Replace(str, "%", "")))
                    ElseIf Left(str, 1) <> "%" And Right(str, 1) <> "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupExemptView)() Where (row.Bin = str)
                    End If
                End If
                If chkInCmpLoc.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupExemptView)() Where (row.CompleteDate = "")
                End If
                If chkZero.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupExemptView)() Where (row.currAssets = 0)
                End If
            Else

                ' --- Parse out the % as wildcard ------------------------------------
                If CStr(txtBin.Text) <> "" Then
                    Dim str As String = Server.HtmlEncode(txtBin.Text.ToString)
                    If Left(str, 1) = "%" And Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsExemptView)() Where (row.Bin.Contains(Replace(str, "%", "")))
                    ElseIf Left(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsExemptView)() Where (row.Bin.EndsWith(Replace(str, "%", "")))
                    ElseIf Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsExemptView)() Where (row.Bin.StartsWith(Replace(str, "%", "")))
                    ElseIf Left(str, 1) <> "%" And Right(str, 1) <> "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsExemptView)() Where (row.Bin = str)
                    End If
                End If

                If chkInCmpLoc.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsExemptView)() Where (row.CompleteDate = "")
                End If
                If chkZero.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsExemptView)() Where (row.currAssets = 0)
                End If
            End If
        Else ' --- chkExempt not checked
            If ddlSg.SelectedValue <> "" Then
                e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupView)() Where (row.subgroup = ddlSg.SelectedValue)

                ' --- Parse out the % as wildcard ------------------------------------
                If CStr(txtBin.Text) <> "" Then
                    Dim str As String = Server.HtmlEncode(txtBin.Text.ToString)
                    If Left(str, 1) = "%" And Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupView)() Where (row.Bin.Contains(Replace(str, "%", "")))
                    ElseIf Left(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupView)() Where (row.Bin.EndsWith(Replace(str, "%", "")))
                    ElseIf Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupView)() Where (row.Bin.StartsWith(Replace(str, "%", "")))
                    ElseIf Left(str, 1) <> "%" And Right(str, 1) <> "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupView)() Where (row.Bin = str)
                    End If
                End If
                If chkInCmpLoc.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupView)() Where (row.CompleteDate = "")
                End If
                If chkZero.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationSubGroupView)() Where (row.currAssets = 0)
                End If
            Else

                ' --- Parse out the % as wildcard ------------------------------------
                If CStr(txtBin.Text) <> "" Then
                    Dim str As String = Server.HtmlEncode(txtBin.Text.ToString)
                    If Left(str, 1) = "%" And Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsView)() Where (row.Bin.Contains(Replace(str, "%", "")))
                    ElseIf Left(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsView)() Where (row.Bin.EndsWith(Replace(str, "%", "")))
                    ElseIf Right(str, 1) = "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsView)() Where (row.Bin.StartsWith(Replace(str, "%", "")))
                    ElseIf Left(str, 1) <> "%" And Right(str, 1) <> "%" Then
                        e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsView)() Where (row.Bin = str)
                    End If
                End If

                If chkInCmpLoc.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsView)() Where (row.CompleteDate = "")
                End If
                If chkZero.Checked = True Then
                    e.Query = From row In e.Query.Cast(Of AssetVerifyLocationsView)() Where (row.currAssets = 0)
                End If
            End If
        End If

    End Sub

    Sub populateLocationDropDown()
        Using dc As New AssetVerifyDataContext(SwmsAccess.GetSwmsConnection())
            Me.ddlLoc.DataSource = (From row In dc.AssetVerifyLocationsViews
                Select New With {.Location = row.Location} Distinct).ToList()

            Me.ddlLoc.DataTextField = "Location"
            Me.ddlLoc.DataValueField = "Location"
            Me.ddlLoc.DataBind()

            Dim blankItem As New ListItem("---", "")
            ddlLoc.Items.Insert(0, blankItem)

            If CStr(Session("avLocation")) <> "" Then
                ddlLoc.SelectedValue = Session("avLocation")
            End If

        End Using
    End Sub

    Sub populateBldgDropdown()
        Using dc As New AssetVerifyDataContext(SwmsAccess.GetSwmsConnection())
            Me.ddlBldg.DataSource = (From row In dc.AssetVerifyLocationsViews
                Select New With {.Building = row.Building} Distinct).ToList()

            Me.ddlBldg.DataTextField = "Building"
            Me.ddlBldg.DataValueField = "Building"
            Me.ddlBldg.DataBind()

            Dim blankItem As New ListItem("---", "")
            ddlBldg.Items.Insert(0, blankItem)

            If CStr(Session("avBuilding")) <> "" Then
                ddlBldg.SelectedValue = Session("avBuilding")
            End If

        End Using
    End Sub

    Sub populateSubGroupDropdown()
        Using dc As New AssetVerifyDataContext(SwmsAccess.GetSwmsConnection())
            Me.ddlSg.DataSource = (From row In dc.AssetVerSubGroupPercents
                Select New With {.subgroup = row.SubGroup} Distinct).ToList()

            Me.ddlSg.DataTextField = "subgroup"
            Me.ddlSg.DataValueField = "subgroup"
            Me.ddlSg.DataBind()

            Dim blankItem As New ListItem("---", "")
            ddlSg.Items.Insert(0, blankItem)

            If CStr(Session("avSubGroup")) <> "" Then
                ddlSg.SelectedValue = Session("avSubGroup")
            End If

        End Using
    End Sub

    Sub populateLocationList(Optional ByVal includeDD As Boolean = True)

        filterPanel.Visible = True
        If includeDD = True Then
            populateLocationDropDown()
            populateBldgDropdown()
            populateSubGroupDropdown()
            txtBin.Text = CStr(Session("avBin"))
        End If

        locationList.DataSource = LinqDataSource1
        If CStr(Session("InvVerPage")) <> "" Then
            locationList.PageIndex = Session("InvVerPage")
        Else
            locationList.PageIndex = 0
        End If
        locationList.DataBind()

        getRunningTotals()
    End Sub

    Private Sub getRunningTotals()
        
        Dim cmd As New SqlCommand("AssetVerifyRunningTotals", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@inventoryName", CStr(ddlInvName.SelectedValue))

        Try
            Dim da = New Data.SqlClient.SqlDataAdapter(cmd)
            Dim ds = New DataSet
            da.Fill(ds)

            If (ds.Tables(0).Rows.Count = 0) Then
                lblTotals.Text = ""
            Else
                lblTotals.Text = ds.Tables(0).Rows(0)("Inventoryname") & ": " & FormatNumber(ds.Tables(0).Rows(0)("total"), 0) & " Assets in " & FormatNumber(ds.Tables(0).Rows(0)("numlocations"), 0) & " Locations "
                lblTotals.Text &= " - Recorded: " & FormatDateTime(ds.Tables(0).Rows(0)("snapshotdate"), 2)
                lblTotals.Text &= "<hr width=""80%""><a href=""AssetVerProgress.aspx"">PROGRESS</a><br />"
                lblTotals.Text &= "LOCATIONS: VERIFIED " & FormatNumber(ds.Tables(0).Rows(0)("locationsverified"), 0) & "; REMAINING " & FormatNumber(ds.Tables(0).Rows(0)("numlocations") - ds.Tables(0).Rows(0)("locationsverified"), 0)
                lblTotals.Text &= " - ASSETS: VERIFIED " & FormatNumber(ds.Tables(0).Rows(0)("verified"), 0) & "; REMAINING " & FormatNumber(ds.Tables(0).Rows(0)("remaining"), 0)
                lblTotals.Text &= "<hr width=""80%"">"
                ' --- if locations are complete  ---'
                If ds.Tables(0).Rows(0)("numlocations") = ds.Tables(0).Rows(0)("locationsverified") Then
                    btnScrubList.Visible = True
                    btnScrubList.Text = getScrubStatus()
                Else
                    btnScrubList.Visible = False
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub

    Private Sub clearLocationListGridView()
        locationList.DataSource = Nothing
        locationList.DataBind()
    End Sub

    Protected Sub LinqDataSource1_Selected(sender As Object, e As System.Web.UI.WebControls.LinqDataSourceStatusEventArgs) Handles LinqDataSource1.Selected
        'If CStr(ddlInvName.SelectedValue) = "---" Then
        '    RecordCountlbl.Text = "&nbsp;"
        'Else
        '    If e.TotalRowCount = 1 Then
        '        Me.RecordCountlbl.Text = "1 Record"
        '    Else
        '        Me.RecordCountlbl.Text = e.TotalRowCount.ToString() & " Records "
        '    End If
        'End If
    End Sub

    Protected Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Session("InvVerPage") = Nothing
        populateLocationList(False)
    End Sub

    Protected Sub pageGridView(sender As Object, e As GridViewPageEventArgs)
        locationList.PageIndex = e.NewPageIndex
        locationList.DataSource = LinqDataSource1
        locationList.DataBind()
    End Sub

    Protected Sub locationList_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles locationList.RowDataBound

        ' --- make the enter link bold ---
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim ee As LinkButton = e.Row.FindControl("view")
            If ee.Text = "Enter" Then
                ee.CssClass = "smBContent"
            Else
                ee.CssClass = "SmContent"
            End If
        End If

        ' --- hides the id and the action fields ---
        If e.Row.Cells.Count > 4 Then
            e.Row.Cells(0).Visible = False
            e.Row.Cells(1).Visible = False
        End If
    End Sub

    Protected Sub locationList_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles locationList.SelectedIndexChanged
        ' --- using the "select" function to select count sheet ---

        Session("avLocation") = Nothing
        Session("avBuilding") = Nothing
        Session("avBin") = Nothing
        Session("avSubGroup") = Nothing

        If ddlLoc.SelectedValue <> "" Then
            Session("avLocation") = ddlLoc.SelectedValue
        End If
        If ddlBldg.SelectedValue <> "" Then
            Session("avBuilding") = ddlBldg.SelectedValue
        End If
        If CStr(txtBin.Text) <> "" Then
            Session("avBin") = Server.HtmlEncode(txtBin.Text.Trim)
        End If
        If ddlSg.SelectedValue <> "" Then
            Session("avSubGroup") = ddlSg.SelectedValue
        End If

        Session("InventoryName") = ddlInvName.SelectedValue
        Session("InvVerPage") = locationList.PageIndex
        Session("alvId") = Me.locationList.SelectedRow.Cells(0).Text.ToString
        Session("viewMethod") = locationList.SelectedRow.Cells(1).Text.ToString
        Response.Redirect("~/Tracking/CountSheet.aspx")
    End Sub

    Function getScrubStatus() As String
        Dim buttonText As String = "Scrub List"

        sql = "select avid from assetverify where inventoryname = @inventoryName and PrintedLocation  is null"
        Dim rs As DataTable = SwmsAccess.ExecuteScalar(sql, new SqlParameter(){
            new SqlParameter("@inventoryName", Server.HtmlEncode(ddlInvName.SelectedValue))
        })
        If rs.Rows.Count > 0 Then
            buttonText = "Assets Not Verified List"
        End If

        Return buttonText
    End Function

    Protected Sub btnScrubList_Click(sender As Object, e As EventArgs) Handles btnScrubList.Click

        If getScrubStatus() = "Assets Not Verified List" Then
            ' --- updates the printed location to 0 where CompletionMethod is null 
            ' --- which creates a scrub list for this inventory cycle
            
            Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyPrintCountSheet", SwmsAccess.GetSwmsConnection())
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@AVLId", "0")
            cmd.Parameters.AddWithValue("@inventoryName", Session("InventoryName"))

            SwmsAccess.ExecuteNonQuery(cmd)
        End If

        Session("avLocation") = Nothing
        Session("avBuilding") = Nothing
        Session("avBin") = Nothing
        Session("avSubGroup") = Nothing
        Session("alvId") = Nothing

        If ddlLoc.SelectedValue <> "" Then
            Session("avLocation") = ddlLoc.SelectedValue
        End If
        If ddlBldg.SelectedValue <> "" Then
            Session("avBuilding") = ddlBldg.SelectedValue
        End If
        If CStr(txtBin.Text) <> "" Then
            Session("avBin") = Server.HtmlEncode(txtBin.Text.Trim)
        End If
        If ddlSg.SelectedValue <> "" Then
            Session("avSubGroup") = ddlSg.SelectedValue
        End If

        Session("InventoryName") = ddlInvName.SelectedValue
        Session("InvVerPage") = locationList.PageIndex

        Response.Redirect("~/Tracking/AssetVerScrubList.aspx")
    End Sub

#End Region

End Class
