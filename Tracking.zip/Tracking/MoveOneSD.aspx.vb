﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Partial Class Tracking_MoveOneSD
    Inherits System.Web.UI.Page


    Dim cC As New commonClass
    Dim sql As String = ""

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("SWMSlvl") < 10 Or Session("SWMSlvl") = Nothing) Then
            Response.Redirect("../Main/jfa.aspx")
        Else
            cC.HitCount(Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"))
        End If

        'add required maxlength attribute to the textarea
        txtRemarks.Attributes.Add("maxlength", 500)

        If Not Page.IsPostBack Then ' NEW Page

            fillDlls()
            If Request.QueryString("Aid") <> "" Then
                txtAid.Text = Request.QueryString("Aid")
                '
                sql = "SELECT  "
                sql &= " A.AssetId, A.Pid, A.PartNumber, A.NIIN, A.Nomenclature, ISNULL(A.ModelNumber, '') AS ModelNumber, ISNULL(Manufacturer, '') AS CAGE,  "
                sql &= " ISNULL(L2.LocationIdCode, '') AS Locality, ISNULL(L3.LocationIdCode, '') AS Bldg, ISNULL(L4.LocationIdCode , '') AS Bin,"
                sql &= " ISNULL(A.SerialNumber, '') AS SerialNumber, ISNULL(A.ICNnum, '') AS ICNnum,  ISNULL(CAST(A.ICNseq as varchar(4)), '') AS ICNseq,"
                sql &= " ISNULL(A.CurrentCondition, '') AS CurrentCondition, ISNULL(A.SubGroup, '') AS SubGroup, ISNULL(A.PIN, '') AS Acct, "
                sql &= " ISNULL(A.DocumentNumber, '') AS DocumentNumber, ISNULL(A.LocationId, 0) AS LocationId, ISNULL(A.Location2, 0) AS Location2, "
                sql &= " ISNULL(A.Location3, 0) AS Location3, ISNULL(A.Location4, 0) AS Location4 "
                sql &= " FROM Assets A"
                sql &= " INNER JOIN Locations L2 ON A.Location2 = L2.LocationId	"   '/* warehouse/shop */"
                sql &= " INNER JOIN Locations L3 ON A.Location3 = L3.LocationId	"   '/* bldg/code */"
                sql &= " INNER JOIN Locations L4 ON A.Location4 = L4.LocationId	"   '/* bin */"
                sql &= " WHERE (A.AssetId = " & txtAid.Text & ")"
                sql &= " AND (A.LocationId = 1)"
                '
                Dim dr As SqlDataReader

                Dim swmsDb As New SqlConnection(Session("swmsDbConnection"))
                swmsDb.Open()
                Dim SqlCmd As New SqlCommand(sql, swmsDb)
                dr = SqlCmd.ExecuteReader()
                '
                If dr.Read() Then
                    lblNIIN.Text = dr("NIIN")
                    lblPartNumber.Text = dr("PartNumber")
                    lblNomenclature.Text = dr("Nomenclature")
                    lblModelNumber.Text = dr("ModelNumber")
                    lblCAGE.Text = dr("CAGE")
                    lblSerial.Text = dr("SerialNumber")
                    lblCC.Text = dr("CurrentCondition")
                    lblDocument.Text = dr("DocumentNumber")
                    If dr("ICNseq") <> "" Then
                        lblICN.Text = dr("ICNnum") & "-" & Right("0000" & dr("ICNseq"), 4)
                    Else
                        lblICN.Text = dr("ICNnum")
                    End If
                    lblSubGroup.Text = dr("SubGroup")
                    lblAcct.Text = dr("Acct")
                    '
                    lblLocation.Text = dr("Locality")
                    lblWarehouse.Text = dr("Bldg")
                    lblBin.Text = dr("Bin")
                    '
                    lblCurrentCC.Text = dr("CurrentCondition")
                    ddlCC.SelectedIndex = ddlCC.Items.IndexOf(ddlCC.Items.FindByValue(dr("CurrentCondition")))
                    '
                    fillLocations(dr("Location2"), dr("Location3"), dr("Location4"))
                    ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(dr("Location3")))
                    ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(dr("Location4")))
                    '
                End If
                dr.Close()
                swmsDb.Close()

            End If
        Else

        End If

    End Sub

    Private Sub fillDlls()

        '' reason -------------------------------------
        ddlReason.Items.Clear()
        Dim rSql As String = "SELECT '-' as SVD_Attribute UNION ALL "
        rSql &= " SELECT SUBSTRING( SVD_Attribute, 6, 50) AS  FROM System_Validation_Dictionary "
        rSql &= " WHERE (SVD_Name = 'AssetReason') AND (SVD_Attribute LIKE 'MOVE%') "
        rSql &= " ORDER BY SVD_Attribute;"
        ddlReason.DataSource = cC.getAsDataTable(rSql, Session("swmsDbConnection"))
        ddlReason.DataValueField = "SVD_Attribute"
        ddlReason.DataTextField = "SVD_Attribute"
        ddlReason.DataBind()
        '  
        '' condition code --------------------------------------------
        ddlCC.Items.Clear()
        Dim ccSql As String = " Select '-' as SVD_Attribute UNION ALL "
        ccSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        ccSql &= " WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute;"
        ddlCC.DataSource = cC.getAsDataTable(ccSql, Session("swmsDbConnection"))
        ddlCC.DataValueField = "SVD_Attribute"
        ddlCC.DataTextField = "SVD_Attribute"
        ddlCC.DataBind()
        '
    End Sub

    Sub fillLocations(ByVal Lc2 As Integer, ByVal Lc3 As Integer, ByVal Lc4 As Integer)
        '
        'Dim sql2 As String = "select top 1 locationid, "
        'sql2 &= " parentlocationid from locations"
        'sql2 &= " where (locationidcode = '" & cC.BufStr(txtLoc2.Text.Trim) & "')"
        'sql2 &= " and (locationlevel = 2)"
        'sql2 &= " and (parentlocationid = 1)" '--------------------
        'sql2 &= " order by locationid"
        'Dim rl2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
        'If rl2.Rows.Count > 0 Then ' its a match
        ' = rl2.Rows(0)("locationid")
        'loc1 = rl2.Rows(0)("parentlocationid")
        'Else
        'UsrMsg.Value &= "Location '" & cC.BufStr(txtLoc2.Text.Trim) & "' not found "
        'End If


        '  If limited to where things have been
        '/* where they have been */
        'SELECT 3 AS Location2, 'WHSE' AS Locality, 
        'L3.LocationId AS Location3, W.Warehouse, 
        'L4.LocationId AS Location4, W.Bin 
        'FROM Warehouses W
        'INNER JOIN Locations L3 ON W.Warehouse = L3.LocationIdCode AND L3.LocationLevel = 3
        'INNER JOIN Locations L4 ON W.Bin = L4.LocationIdCode AND L4.LocationLevel = 4
        '/*WHERE Pid = 1431*/ 
        'GROUP BY L3.LocationId, W.Warehouse, 
        'L4.LocationId, W.Bin 
        'UNION 
        '/* Where they are now */
        'SELECT  A.Location2, L2.LocationIdCode AS Locality, 
        'A.Location3, L3.LocationIdCode AS Warehouse, 
        'A.Location4, L4.LocationIdCode AS Bin
        'FROM Assets A 
        'INNER JOIN Locations L2 ON A.Location2 = L2.LocationId
        'INNER JOIN Locations L3 ON A.Location3 = L3.LocationId
        'INNER JOIN Locations L4 ON A.Location4 = L4.LocationId
        'WHERE A.Pid = 1431 
        'GROUP BY A.Location2, L2.LocationIdCode, A.Location3, 
        'L3.LocationIdCode, A.Location4, L4.LocationIdCode 

        ' Location --------- "Location" ------------------------
        'ddlSavLvl2.Items.Clear()
        'Dim sql2 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        'sql2 &= " WHERE (LocationLevel = 2)"
        'sql2 &= " ORDER BY LocationIdCode"
        'Dim rtn2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
        'ddlSavLvl2.DataSource = rtn2
        'ddlSavLvl2.DataValueField = "ParentLocationID"
        'ddlSavLvl2.DataTextField = "Code"
        'ddlSavLvl2.DataBind()
        '
        'ddlLocLvl2.Items.Clear()
        'Dim tli As New ListItem
        'tli.Text = "--"
        'tli.Value = "0"
        'ddlLocLvl2.Items.Add(tli)
        '' re-Populate the control after the data record has been read
        'Dim j As Integer = 0
        'For i As Integer = 0 To rtn2.Rows.Count - 1
        '    If rtn2.Rows(i)("ParentLocationID") = 1 Then
        '        j = InStr(rtn2.Rows(i)("Code"), "@")
        '        Dim litm As New ListItem
        '        litm.Value = Left(rtn2.Rows(i)("Code"), j - 1)
        '        litm.Text = Mid(rtn2.Rows(i)("Code"), j + 1)
        '        ddlLocLvl2.Items.Add(litm)
        '    End If
        'Next

        '' location2 ----------------------------------
        Dim l2Sql As String = "SELECT LocationId, LocationIdCode FROM Locations WHERE ParentLocationId = 1"
        ddlLocLvl2.DataSource = cC.getAsDataTable(l2Sql, Session("swmsDbConnection"))
        ddlLocLvl2.DataValueField = "LocationId"
        ddlLocLvl2.DataTextField = "LocationIdCode"
        ddlLocLvl2.DataBind()

        ' Sub -------------- "Building" -------------------
        ddlSavLvl3.Items.Clear()
        Dim sql3 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql3 &= " WHERE (LocationLevel = 3)"
        sql3 &= " ORDER BY LocationIdCode"
        Dim rtn3 As DataTable = cC.getAsDataTable(sql3, Session("swmsDbConnection"))
        ddlSavLvl3.DataSource = rtn3
        ddlSavLvl3.DataValueField = "ParentLocationID"
        ddlSavLvl3.DataTextField = "Code"
        ddlSavLvl3.DataBind()
        '
        Dim j As Integer = 0
        ddlLocLvl3.Items.Clear()
        Dim tli3 As New ListItem
        tli3.Text = "--"
        tli3.Value = "0"
        ddlLocLvl3.Items.Add(tli3)
        ' Populate the control after the data record has been read
        For i As Integer = 0 To rtn3.Rows.Count - 1
            If rtn3.Rows(i)("ParentLocationID") = Lc2 Then         'ddlLocLvl2.SelectedValue
                j = InStr(rtn3.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn3.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn3.Rows(i)("Code"), j + 1)
                ddlLocLvl3.Items.Add(litm)
            End If
        Next
        '

        ' Micro -------------- "Bin" -------------------
        ddlSavLvl4.Items.Clear()
        Dim sql4 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql4 &= " WHERE (LocationLevel = 4)"
        sql4 &= " ORDER BY LocationIdCode"
        Dim rtn4 As DataTable = cC.getAsDataTable(sql4, Session("swmsDbConnection"))
        ddlSavLvl4.DataSource = rtn4
        ddlSavLvl4.DataValueField = "ParentLocationID"
        ddlSavLvl4.DataTextField = "Code"
        ddlSavLvl4.DataBind()
        '
        j = 0
        ddlLocLvl4.Items.Clear()
        Dim tli4 As New ListItem
        tli4.Text = "--"
        tli4.Value = "0"
        ddlLocLvl4.Items.Add(tli4)
        ' Populate the control after the data record has been read
        For i As Integer = 0 To rtn4.Rows.Count - 1
            If rtn4.Rows(i)("ParentLocationID") = Lc3 Then      ' ddlLocLvl3.SelectedValue 
                j = InStr(rtn4.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn4.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn4.Rows(i)("Code"), j + 1)
                ddlLocLvl4.Items.Add(litm)
            End If
        Next

    End Sub

    Protected Sub btnTransfer_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTransfer.Click
        '
        btnTransfer.Text = "Transfering Asset, Please Wait..."
        btnTransfer.Enabled = False
        ' remember the selections
        Dim lx2 As String = ""
        Dim lx3 As String = ""
        Dim lx4 As String = ""
        Dim l2 As String = "SELECT LocationId, LocationIdCode FROM Locations WHERE LocationId = " & Request.Form("ddlLocLvl2")
        Dim l3 As String = "SELECT LocationId, LocationIdCode FROM Locations WHERE LocationId = " & Request.Form("ddlLocLvl3")
        Dim l4 As String = "SELECT LocationId, LocationIdCode FROM Locations WHERE LocationId = " & Request.Form("ddlLocLvl4")

        Dim dr As SqlDataReader
        Dim swmsDb As New SqlConnection(Session("swmsDbConnection"))
        swmsDb.Open()
        Dim SqlCmd As New SqlCommand(l2, swmsDb)
        '
        dr = SqlCmd.ExecuteReader()
        If dr.Read() Then
            lx2 = dr("LocationIdCode")
        End If
        dr.Close()
        SqlCmd.CommandText = l3
        dr = SqlCmd.ExecuteReader()
        If dr.Read() Then
            lx3 = dr("LocationIdCode")
        End If
        dr.Close()
        SqlCmd.CommandText = l4
        dr = SqlCmd.ExecuteReader()
        If dr.Read() Then
            lx4 = dr("LocationIdCode")
        End If
        dr.Close()
        swmsDb.Close()

        'validateTrans()
        If UsrMsg.Value = "" Then
            sql = "DECLARE @RightNow as datetime; "
            sql &= " SELECT @RightNow = Getdate(); "
            '
            sql &= " UPDATE Assets SET"
            sql &= " Location2 = " & Request.Form("ddlLocLvl2") & ", Location3 = " & Request.Form("ddlLocLvl3") & ", Location4 = " & Request.Form("ddlLocLvl4") & ","
            sql &= " CurrentCondition = '" & ddlCC.SelectedItem.Text & "',"
            sql &= " Reason = '" & ddlReason.SelectedItem.Text & "',"
            sql &= " Remarks = '" & Left(cC.BufStr(txtRemarks.Text), 500) & "', "
            If IsDate(txtDate.Text) Then
                sql &= " EffectiveDate = '" & txtDate.Text & "', "
            Else
                sql &= " EffectiveDate = @RightNow, "
            End If
            sql &= " LastTrans = 'TRANSFER', "
            sql &= " LastTransDate = @RightNow, "
            sql &= " LastTransBy = " & Session("SWMSUId")
            sql &= " WHERE (AssetId = " & txtAid.Text & ")"
            '
            sql &= "; UPDATE InventoryLocation SET"         '
            sql &= " WareHouse = '" & lx3 & "', Bin = '" & lx4 & "', "
            sql &= " Condition_Code = '" & ddlCC.SelectedItem.Text & "'"
            sql &= " WHERE (AssetId = " & txtAid.Text & ")"
            '
            sql &= "; INSERT INTO AssetHistory ("
            sql &= " AssetId, AssetInvId, ConditionCode, TransType, TransDate, TransBy,"
            sql &= " Remarks, Reason, DocumentNumber,"
            sql &= " LocationId, Location2, Location3, Location4,"
            sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
            '   --Status, PurposeCode, ProcurementCode, MaintDocNumber,
            sql &= " EffectiveDate,"
            '   --oldAssetId, ReworkNumber, oldId,
            sql &= " ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN"
            sql &= " ) VALUES ("
            sql &= txtAid.Text & ", NULL, '" & ddlCC.SelectedItem.Text & "', 'Transfered Asset', @RightNow, " & Session("SWMSUId") & ", "
            sql &= " 'TRANSFER FROM " & lblWarehouse.Text & "/" & lblBin.Text & " TO " & lx3 & "/" & lx4 & "', "
            sql &= " '" & ddlReason.SelectedItem.Text & "', '" & lblDocument.Text & "', "
            sql &= " 1, " & Request.Form("ddlLocLvl2") & ", " & Request.Form("ddlLocLvl3") & ", " & Request.Form("ddlLocLvl4") & ", "
            sql &= " 'ACTIVE', '" & lx2 & "', '" & lx3 & "', '" & lx4 & "', "
            '   --NULL, NULL, NULL, NULL, 
            If txtDate.Text.Trim <> "" Then
                If CDate(txtDate.Text.Trim) < CDate(Today) Then
                    sql &= "'" & txtDate.Text.Trim & "', "      'EffectiveDate,
                Else
                    sql &= " @RightNow, "      'EffectiveDate,
                End If
            Else
                sql &= " @RightNow, "      'EffectiveDate,
            End If
            '   --NULL, NULL, NULL, 
            sql &= " '" & Left(lblICN.Text, 8) & "', "
            If lblICN.Text.Length > 8 Then
                sql &= Right(lblICN.Text, 4) & ", "
            Else
                sql &= " NULL, "
            End If
            sql &= " '" & lblSubGroup.Text & "', NULL, NULL, '" & lblAcct.Text & "'"
            sql &= " )"
            '
            sql &= "; INSERT INTO EventsHistory ("
            sql &= " Event, InvId, Pid, PartNumber, Factory, Warehouse, Bin, "
            sql &= " Serial, LotNum, Program, "
            sql &= " SupplierId, Order_Number, CreateDate, ExpirationDate, "
            sql &= " OrigQty, TransQty, Quantity, SumBefore, SumAfter, "
            sql &= " Comments, IssuedTo, PeopleID, UserName, EventDate, "
            sql &= " SONum, LocalDocNumber, PickListID, Supplier, NIIN, "
            sql &= " Reserved_For_ShopOrder, Condition_Code, "
            sql &= " Receipt, Issue, Audit, ConditionCode, ProcurementCode, ShopOrder "
            sql &= " ) "
            sql &= " SELECT "
            sql &= " 'Transfered Asset' AS Event, IL.InvId, IL.Pid, IL.PartNumber, Factory, IL.Warehouse, IL.Bin, "
            sql &= " IL.Serial, IL.LotNum, A.SubGroup AS Program, "
            sql &= " IL.SupplierId, IL.Order_Number, IL.CreateDate, IL.ExpirationDate, "
            sql &= " IL.Quantity AS OrigQty, IL.Quantity AS TransQty, IL.Quantity AS Quantity, IL.Quantity AS SumBefore, IL.Quantity AS SumAfter, "
            sql &= " 'TRANSFER FROM " & lblWarehouse.Text & "/" & lblBin.Text & " TO " & lx3 & "/" & lx4 & "' AS Comments, "
            sql &= " NULL AS IssuedTo, " & Session("SWMSUId") & " AS PeopleID, '" & Session("DsplName") & "' AS UserName, @RightNow AS EventDate, "
            sql &= " NULL AS SONum, NULL AS LocalDocNumber, IL.PickListID, IL.Supplier, IL.NIIN, "
            sql &= " Reserved_For_ShopOrder, Condition_Code, "
            sql &= " 0 AS Receipt, 0 AS Issue, 0 AS Audit, PM.ConditionCode, PM.ProcurementCode, NULL AS ShopOrder "
            sql &= " FROM InventoryLocation IL "
            sql &= " INNER JOIN Assets A ON IL.AssetId = A.AssetId "
            sql &= " INNER JOIN PartsMaster PM ON IL.Pid = PM.Pid "
            sql &= " WHERE (IL.AssetId = " & txtAid.Text & ")"
            '
            '
            cC.executeNonQuery(sql, Session("swmsDbConnection"))
            cC.LogIt("assets", "Assets: niin:" & lblNIIN.Text & " part: " & lblPartNumber.Text & " S/N:" & lblSerial.Text & " Received ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))
            '
            Session("UserMsg") = "Asset serial# " & lblSerial.Text & " transfered to " & lx3 & "/" & lx4 & "."
            btnTransfer.Text = "Transfer"
            btnTransfer.Enabled = True
            '
            txtComplete.Text = "Complete"               'Response.Redirect("./TransferAssetsSD.aspx?Aid=" & txtAid.Text)
            '
        End If

    End Sub

    Sub validateTrans()
        'start out clean
        ddlLocLvl3.BackColor = Drawing.Color.White
        ddlLocLvl4.BackColor = Drawing.Color.White
        ddlReason.BackColor = Drawing.Color.White
        txtRemarks.BackColor = Drawing.Color.White
        '
        If ddlLocLvl3.SelectedIndex < 1 Then
            UsrMsg.Value &= "Please indicate new Warehouse for this transfer."
            ddlLocLvl3.BackColor = Drawing.Color.MistyRose
        End If
        If ddlLocLvl4.SelectedIndex < 1 Then
            If txtBin.Text.Trim = "" Then
                UsrMsg.Value &= "Please indicate new Bin for this transfer."
                ddlLocLvl4.BackColor = Drawing.Color.MistyRose
            Else
                'test txtBin.text for valid bin
            End If
        End If
        If ddlReason.SelectedIndex < 1 Then
            UsrMsg.Value &= "Please indicate reason for this transfer."
            ddlReason.BackColor = Drawing.Color.MistyRose
        End If
        If txtRemarks.Text.Length < 1 Then
            UsrMsg.Value &= "Please enter remarks."
            txtRemarks.BackColor = Drawing.Color.MistyRose
        End If
    End Sub

End Class
