﻿Imports System.Data
Partial Class Tracking_RecordAssetInv
    Inherits System.Web.UI.Page

#Region "declarations"
    Dim cC As New commonClass
    Dim sql As String = ""
    Dim str As String = ""
#End Region

#Region "pageLoad"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
        If msg <> "" Then
            Response.Redirect(msg)
        End If

        If Not Page.IsPostBack Then
            ddls()
            If CStr(Request.QueryString("id")) <> "" Then ' an asset is selected for edit
                displayInvRecord(Request.QueryString("id"))
                btnUPd.Visible = True
                btnAdd.Visible = False
            Else ' form is blank for adding a new asst
                btnUPd.Visible = False
                btnAdd.Visible = True
            End If
        Else
            Select Case txtCommand.Value
                Case "add" ' adds new assetinventory record
                    addInvRecord()
                Case "upd" '  update the assetinventory record
                    updInvRecord()
                Case "addSn" ' adds a new serial number to the inventory list
                    addSerialNumber()
                Case "updSn"
                    validLocations() ' updateLocation()
                Case "snCheck"
                    checkForSerial()
                Case "delSn"
                    deleteSerialNumber()
            End Select
            displayInvRecord(Request.QueryString("id"))
        End If
    End Sub
#End Region

    Sub displayInvRecord(ByVal AId As String)
        Session("AId") = AId

        If CStr(AId) = "" Then
            Response.Redirect("FindInvRecord.aspx")
        Else
            sql = "SELECT AssetInvId, isnull(InventoryType,'') as invType, isnull(InvDescription,'') as invDesc, invDate, "
            sql &= " isnull(InvComments,'') as invComments FROM AssetInventory WHERE (AssetInvId = " & AId & ")"

            Dim rp As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\RecordAssetInv.aspx.vb - displayInvRecord()")
            If rp.Rows.Count > 0 Then
                txtInvDesc.Text = rp.Rows(0)("invDesc")
                txtInvComments.Text = rp.Rows(0)("invComments")
                If IsDate(rp.Rows(0)("invDate")) Then
                    If CStr(rp.Rows(0)("invDate")) <> "1/1/1900" Then
                        txtInvDate.Text = FormatDateTime(rp.Rows(0)("invDate"), 2)
                    End If
                End If
                
                Try
                    ddlInvType.SelectedValue = rp.Rows(0)("invType") ' rdr("invType")
                Catch ex As Exception
                End Try
            End If

        End If

        displayAssetList()
    End Sub

    Sub ddls()

        ' inventory type --------------------------------------------
        ddlInvType.Items.Clear()
        sql = " SELECT SVD_Attribute FROM System_Validation_Dictionary WHERE (SVD_Name = 'InventoryType') ORDER BY SVD_Attribute"
        ddlInvType.DataSource = cC.getAsDataTable(sql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "tracking\RecordAssetInv.aspx.vb - ddls()")
        ddlInvType.DataValueField = "SVD_Attribute"
        ddlInvType.DataTextField = "SVD_Attribute"
        ddlInvType.DataBind()

    End Sub

    Sub resultsHeader()
        Dim x1 As New TableRow

        x1.Cells.Add(cC.DataCell("#", "center"))
        x1.Cells.Add(cC.DataCell("Serial #", "center"))
        x1.Cells.Add(cC.DataCell("Location", "center"))
        x1.Cells.Add(cC.DataCell("", "center"))

        x1.BackColor = System.Drawing.Color.LightSteelBlue
        x1.CssClass = "smBContent"
        tblResults.Rows.Add(x1)
    End Sub

    Sub addSNRow()
        Dim x1 As New TableRow
        If txtCommand.Value = "addSnPrep" Then
            str = "<input type=""text"" name=""txtSn"" id=""txtSn"" value=""" & Request.Form("txtSn") & """ "
            str &= " class=""SmContent"" maxlength=""50"" size=""10"">&nbsp;"
            str &= "<a href=""javascript:snSearch(" & Request.Form("txtSn") & ")"");"">Find</a>&nbsp;"
            str &= "<a href=""javascript:addSn('" & Request.Form("txtSn") & "')"");"">Add</a>&nbsp;"
            str &= "<a href=""javascript:done();"">Cancel</a>"
            x1.Cells.Add(cC.DataCell(str, "center", 2))
        Else
            x1.Cells.Add(cC.DataCell("<a href=""javascript:addSnPrep();"">Add Serial Number</a>", "center", 2))
        End If
        tblResults.Rows.Add(x1)
    End Sub

    Sub displayAssetList()
        addSNRow()
        resultsHeader()

        sql = "SELECT ah.AssetHistoryId, ah.AssetId, "
        sql &= " isnull(loc1.locationidcode,'') as loc1,"
        sql &= " isnull(loc2.locationidcode,'') as loc2,"
        sql &= " isnull(loc3.locationidcode,'') as loc3,"
        sql &= " isnull(loc4.locationidcode,'') as loc4,"
        sql &= " isnull(ah.LocationId,0) as LocationId, isnull(ass.SerialNumber,'') as sn, "
        sql &= " isnull(loc1.LocationIdcode,' - ') + ' - ' + isnull(loc2.LocationIdcode,'') "
        sql &= "    + ' - ' + isnull(loc3.LocationIdcode,'') + ' - ' + isnull(loc4.LocationIdcode,'') as locName "
        sql &= " FROM AssetHistory AS ah "
        sql &= "    INNER JOIN Assets AS ass ON ah.AssetId = ass.AssetId"
        sql &= "    left outer join locations loc1 on ah.locationid = loc1.locationid"
        sql &= "    left outer join locations loc2 on ah.location2 = loc2.locationid"
        sql &= "    left outer join locations loc3 on ah.location3 = loc3.locationid"
        sql &= "    left outer join locations loc4 on ah.location4 = loc4.locationid"
        sql &= " WHERE (ah.AssetInvId = " & Request.QueryString("id") & ") AND (ah.AssetId IS NOT NULL)"

        Try
            Dim rx As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"), Integer.Parse(ConfigurationManager.AppSettings("IncreaseSQLTimeOut").ToString), Session("SWMSUId"), "Tracking\RecordAssetInv.aspx.vb - displayAssetList()")
            If rx.Rows.Count > 0 Then
                Dim altRow As Boolean = False

                Dim i As Integer
                For i = 0 To rx.Rows.Count - 1
                    If rx.Rows.Count = 1 Then
                        lblRowCount.Text = "1 Asset"
                    Else
                        lblRowCount.Text = rx.Rows.Count & " Assets"
                    End If
                    Dim x1 As New TableRow
                    x1.Cells.Add(cC.DataCell(i + 1, "right"))

                    str = "<a href=""EditAsset.aspx?id=" & rx.Rows(i)("AssetId") & "&inv=" & Request.QueryString("id") & """>" & rx.Rows(i)("sn") & "</a>"
                    x1.Cells.Add(cC.DataCell(str, "center"))

                    If txtAid.Value = CStr(rx.Rows(i)("AssetId")) Then
                        str = "<input type=""text"" class=""SmContent"" size=""15"" id = ""txtLoc1""   "
                        str &= "name=""txtLoc1"" maxlength=""15"" value=""" & rx.Rows(i)("loc1") & """>"

                        str &= "<input type=""text"" class=""SmContent""  size=""15"" id = ""txtLoc2""  "
                        str &= " name=""txtLoc2"" maxlength=""15"" value=""" & rx.Rows(i)("loc2") & """>"

                        str &= "<input type=""text"" class=""SmContent"" size=""15"" id = ""txtLoc3"""
                        str &= " name=""txtLoc3"" maxlength=""15"" value=""" & rx.Rows(i)("loc3") & """>"

                        str &= "<input type=""text"" class=""SmContent""  size=""15"" id = ""txtLoc4"""
                        str &= " name=""txtLoc4"" maxlength=""15"" value=""" & rx.Rows(i)("loc4") & """>"
                    Else
                        str = rx.Rows(i)("locname") ' rdr("locname")
                    End If
                    x1.Cells.Add(cC.DataCell(str, "left"))

                    If txtAid.Value = CStr(rx.Rows(i)("AssetId")) Then
                        str = "<a href=""javascript:updSn();"">Upd</a>&nbsp;"
                        str &= "<a href=""javascript:done();"">Can</a>&nbsp;"
                        str &= "<a href=""javascript:del();"">Del</a>"
                    Else
                        str = "<a href=""javascript:picMe('" & rx.Rows(i)("AssetId") & "');"">Edit</a>"
                    End If
                    x1.Cells.Add(cC.DataCell(str, "center"))

                    If altRow = False Then
                        x1.BackColor = System.Drawing.Color.White
                        altRow = True
                    Else
                        x1.BackColor = System.Drawing.Color.WhiteSmoke
                        altRow = False
                    End If
                    tblResults.Rows.Add(x1)
                Next
            Else
                lblRowCount.Text = "No Assets"
            End If
        Catch ex As Exception
            lblRowCount.Text = ex.ToString
        End Try

    End Sub

    Sub addInvRecord()

        sql = "INSERT INTO AssetInventory  (InventoryType, InvDescription, InvDate, InvComments)"
        sql &= " VALUES ('" & ddlInvType.SelectedValue & "', " ' InventoryType
        sql &= " '" & cC.BufStr(txtInvDesc.Text.Trim) & "', " ' InvDescription
        If IsDate(txtInvDate.Text) Then
            sql &= " '" & cC.BufStr(txtInvDate.Text.Trim) & "', " ' InvDate
        Else
            sql &= " NULL, " ' InvDate
        End If
        sql &= " '" & Left(cC.BufStr(txtInvComments.Text), 200).Trim & "')" ' InvComments
        sql &= " SELECT SCOPE_IDENTITY() "

        Dim newId As Integer = 0
        Dim dlId As DataTable = cC.getAsDataTable(sql, Session("SWMSDBConnection").ToString, , Session("SWMSUID").ToString, "Business/copyQuote.aspx.vb")
        If dlId.Rows.Count > 0 Then
            newId = dlId.Rows(0).Item(0)

            'insert into eventlog --------------
            cC.LogIt("Assets", "AssetInv: Inventory " & txtInvDesc.Text & " Created ", "", Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), Session("PQnum"), Session("swmsDbConnection"))
            Response.Redirect("RecordAssetInv.aspx?id=" & newId)
        End If

        txtCommand.Value = ""
    End Sub

    Sub validLocations()
        '---validate the locations
        UsrMsg.Value = ""
        Dim ds As New Data.DataSet
        Dim loc1 As Integer = 0, loc2 As Integer = 0
        Dim loc3 As Integer = 0, loc4 As Integer = 0
        Dim i As Integer = -1 ' dynamically index dataset tables

        '---1st level - super
        If CStr(Request.Form("txtLoc1").Trim) <> "" Then
            i += 1
            Dim sql1 As String = "select top 1 LocationId from locations"
            sql1 &= " where (locationlevel = 1) and (locationidcode = '" & cC.BufStr(Request.Form("txtLoc1").Trim) & "')"
            sql1 &= " order by locationid"
            ds.Tables.Add(cC.getAsDataTable(sql1, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "tracking\RecordAssetInv.aspx.vb - validLocations() - 1st Level"))
            ds.Tables(i).TableName = "locTab1"
            If ds.Tables("locTab1").Rows.Count > 0 Then ' its a match
                loc1 = ds.Tables("locTab1").Rows(0)("locationid")
            Else
                UsrMsg.Value &= "Super location '" & cC.BufStr(Request.Form("txtLoc1").Trim) & "' not found "
            End If
        End If

        '---2nd level - location
        If CStr(Request.Form("txtLoc2").Trim) <> "" Then
            i += 1
            Dim sql2 As String = "select top 1 locationid, parentlocationid from locations"
            sql2 &= " where (locationidcode = '" & cC.BufStr(Request.Form("txtLoc2").Trim) & "') and (locationlevel = 2)"
            If loc1 <> 0 Then
                sql2 &= " and (parentlocationid = " & loc1 & ")" '--------------------
            End If
            sql2 &= " order by locationid"
            ds.Tables.Add(cC.getAsDataTable(sql2, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "tracking\RecordAssetInv.aspx.vb - validLocations() - 2nd Level"))
            ds.Tables(i).TableName = "locTab2"
            If ds.Tables("locTab2").Rows.Count > 0 Then ' its a match
                loc2 = ds.Tables("locTab2").Rows(0)("locationid")
                loc1 = ds.Tables("locTab2").Rows(0)("parentlocationid")
            Else
                UsrMsg.Value &= "Location '" & cC.BufStr(Request.Form("txtLoc2").Trim) & "' not found "
            End If
        End If

        '---3rd level - sub
        If CStr(Request.Form("txtLoc3").Trim) <> "" Then
            i += 1
            Dim sql3 As String = " select  top 1 locationid, parentlocationid, "
            sql3 &= " isnull((select parentlocationid from locations "
            sql3 &= "   where locationid = loc.parentlocationid),0) as grandLocationid "
            sql3 &= " from locations loc"
            sql3 &= " where (locationidcode = '" & cC.BufStr(Request.Form("txtLoc3").Trim) & "')"
            sql3 &= " and (locationlevel = 3)"
            If loc2 <> 0 Then
                sql3 &= " and (parentlocationid = " & loc2 & ")" '--------------------
            End If
            sql3 &= " order by locationid"
            ds.Tables.Add(cC.getAsDataTable(sql3, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "tracking\RecordAssetInv.aspx.vb - validLocations() - 3rd Level"))
            ds.Tables(i).TableName = "locTab3"
            If ds.Tables("locTab3").Rows.Count > 0 Then ' its a match
                loc3 = ds.Tables("locTab3").Rows(0)("locationid")
                loc2 = ds.Tables("locTab3").Rows(0)("parentlocationid")
                loc1 = ds.Tables("locTab3").Rows(0)("grandLocationid")
            Else
                UsrMsg.Value &= "Sub Location '" & cC.BufStr(Request.Form("txtLoc3").Trim) & "' not found "
            End If
        End If

        '---4th level - micro
        If CStr(Request.Form("txtLoc4").Trim) <> "" Then
            i += 1
            Dim sql4 As String = " select top 1 locationid, parentlocationid, "
            sql4 &= " isnull((select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid),0) as grandLocationid, "
            sql4 &= " isnull((select parentlocationid from locations"
            sql4 &= "   where locationid = (select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid)),0) as greatlocationid"
            sql4 &= "  from locations loc"
            sql4 &= " where (locationidcode = '" & cC.BufStr(Request.Form("txtLoc4").Trim) & "')"
            sql4 &= " and (locationlevel = 4)"
            If loc3 <> 0 Then
                sql4 &= " and (parentlocationid = " & loc3 & ")" '--------------------
            End If
            sql4 &= " order by locationid"
            ds.Tables.Add(cC.getAsDataTable(sql4, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "tracking\RecordAssetInv.aspx.vb - validLocations() - 4th Level"))
            ds.Tables(i).TableName = "locTab4"
            If ds.Tables("locTab4").Rows.Count > 0 Then ' its a match
                loc4 = ds.Tables("locTab4").Rows(0)("locationid")
                loc3 = ds.Tables("locTab4").Rows(0)("parentlocationid")
                loc2 = ds.Tables("locTab4").Rows(0)("grandlocationid")
                loc1 = ds.Tables("locTab4").Rows(0)("greatlocationid")
            Else
                UsrMsg.Value &= "Micro Location '" & cC.BufStr(Request.Form("txtLoc4").Trim) & "' not found"
            End If
        End If

        If UsrMsg.Value = "" Then
            updateLocation(loc1, loc2, loc3, loc4)
        End If
    End Sub

    Sub updInvRecord()

        sql = " UPDATE AssetInventory SET"
        sql &= " InventoryType = '" & ddlInvType.SelectedValue & "', "
        sql &= " InvDescription = '" & cC.BufStr(txtInvDesc.Text.Trim) & "', "
        If IsDate(txtInvDate.Text) Then
            sql &= " InvDate = '" & cC.BufStr(txtInvDate.Text.Trim) & "', "
        Else
            sql &= " InvDate = NULL, "
        End If
        sql &= " InvComments = '" & Left(cC.BufStr(txtInvComments.Text), 200).Trim & "'"
        sql &= " WHERE (AssetInvId = " & Request.QueryString("id") & ")"
        cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "Tracking\RecordAssetInv.aspx.vb - updInvRecord()")

        txtCommand.Value = ""

        'insert into eventlog --------------
        cC.LogIt("Assets", "AssetInv: Inventory " & txtInvDesc.Text & " Updated ", "", Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), Session("PQnum"), Session("swmsDbConnection"))
        Response.Redirect("RecordAssetInv.aspx?id=" & Request.QueryString("id"))
    End Sub

    Sub addSerialNumber()

        'if there no location, try inserting the top-most location from all the other... 
        ' ... assets associated with this inventory action
        sql = "insert into AssetHistory (AssetId, AssetInvId, BSSId, "
        sql &= "    ConditionCode, TransDate, TransBy, Remarks, Reason, "
        sql &= "    DocumentNumber, ILSMISControlNumber, "
        sql &= "    LocationId, Location2, location3, location4, Status, PurposeCode, ProcurementCode)"
        sql &= " SELECT top 1 AssetId, " & Request.QueryString("id") & " as AssetInvId,  "
        sql &= "    BSSId,ConditionCode, getdate(), "
        sql &= Session("SWMSUId") & " as TransBy, Remarks, Reason, DocumentNumber, ILSMISControlNumber, "
        sql &= "    LocationId, Location2, location3, location4, Status, PurposeCode, ProcurementCode "
        sql &= " FROM AssetHistory "
        sql &= " WHERE (AssetId = " & txtAid.Value & ")"
        sql &= " ORDER BY transdate desc"

        Dim rowAdd As Boolean = cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "AssetTracking\RecordAssetInv.aspx.vb - addSerialNumber()")

        ' if there is no history, create a new record
        If Not rowAdd Then
            sql &= " insert into AssetHistory (AssetId, AssetInvId, BSSId,TransDate, TransBy, Remarks)"
            sql &= " select assetid, "
            sql &= Request.QueryString("id") & " as AssetInvId, "
            sql &= " BSSId, '" & cC.BufStr(txtInvDate.Text.Trim) & "' as TransDate,"
            sql &= Session("SWMSUId") & " as TransBy, "
            sql &= " 'Create from Inventory' as remarks"
            sql &= " from assets where (assetid = " & txtAid.Value & ")"
            cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "AssetTracking\RecordAssetInv.aspx.vb - addSerialNumber() - InsAssetHist")
        End If

        txtCommand.Value = ""
        txtPicked.Value = ""
    End Sub

    Sub checkForSerial()
        Dim strSn As String = txtAid.Value.Trim

        If txtPicked.Value = "pick" Then
            addSerialNumber()
        Else
            'look for an asset that matches the serial number
            sql = "select assetid from assets   where serialnumber = '" & cC.BufStr(Request.Form("txtSn")) & "'"
            Dim kp As DataTable = cC.getAsDataTable(sql, Session("swmsDBConnection"))
            If kp.Rows.Count > 0 Then
                txtAid.Value = kp.Rows(0)("assetid")
            End If

            'if ONLY one match is found call addSerialNumber
            If kp.Rows.Count = 1 Then
                addSerialNumber()
            Else
                Dim snPopUp As String
                If kp.Rows.Count = 0 Then 'suggest redirect to maintain assets page
                    snPopUp = "if (confirm('" & Request.Form("txtSn") & " was not found. Do you want to add it?')) {"
                    snPopUp &= "window.navigate('EditAsset.aspx?sn=" & Request.Form("txtSn")
                    snPopUp &= "&inv=" & Request.QueryString("id") & "');}"
                Else ' more than one match was found, pop-up the search screen
                    txtCommand.Value = "addSnPrep"
                    snPopUp = "vWinSch = window.open(""SNSearch.aspx?sn=" & Request.Form("txtSn") & """,""SN"","
                    snPopUp &= """width=400,height=424,status=no,resizable=yes,top=75,left=175,scrollbars=yes"");"
                    snPopUp &= "vWinSch.opener = self;"
                    snPopUp &= "vWinSch.focus();"
                End If
                Response.Write("<SCRIPT LANGUAGE='JavaScript'>" & snPopUp & "</SCRIPT>")
            End If
        End If

    End Sub

    Sub deleteSerialNumber()

        sql = "DELETE FROM assetHistory where (assetid = " & txtAid.Value & ")"
        sql &= " and (assetinvid = " & Request.QueryString("id") & ")"
        cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "Tracking\RecordAssetInv.aspx.vb - deleteSerialNumber()")

        txtCommand.Value = ""
        txtLoc.Value = ""
        txtAid.Value = ""
        txtParentLoc.Value = ""
    End Sub

    Sub updateLocation(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)

        sql = "update assetHistory set"
        sql &= " locationid = " & loc1 & ", "
        sql &= " location2 = " & loc2 & ", "
        sql &= " location3 = " & loc3 & ", "
        sql &= " location4 = " & loc4
        sql &= " where (assetid = " & txtAid.Value & ")"
        sql &= " and (assetinvid = " & Request.QueryString("id") & ")"

        cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "Tracking\RecordAssetInv.aspx.vb - updateLocation()")

        txtCommand.Value = ""
        txtLoc.Value = ""
        txtAid.Value = ""
        txtParentLoc.Value = ""
    End Sub

End Class
