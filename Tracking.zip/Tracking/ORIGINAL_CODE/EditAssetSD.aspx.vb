﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Partial Class Tracking_EditAssetSD
    Inherits System.Web.UI.Page

    Dim cC As New commonClass
    Dim sql As String = ""
    Dim str As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
        If msg <> "" Then
            Response.Redirect(msg)
        End If

        'If Request.QueryString("inv") <> "" Then
        '    lnkInv.Text = "Return to Inventory"
        '    lnkInv.NavigateUrl = "RecordAssetInv.aspx?id=" & Request.QueryString("inv")
        '    lnkInv.Visible = True
        'Else
        lnkInv.Visible = False
        'End If

        If CStr(Request.QueryString("id")) <> "" Then
            lnkRet.NavigateUrl = "FindAssetsSD.aspx?id=" & Request.QueryString("id")
        Else
            lnkRet.NavigateUrl = "FindAssetsSD.aspx"
        End If

        If Not Page.IsPostBack Then ' NEW Page
            fillDdls()
            If CStr(Request.QueryString("id")) <> "" Then
                ' an asset is selected for edit
                displayAsset(Request.QueryString("id"))
                btnUPd.Visible = True
                '
                historyPanel.Visible = False        'True
                showHideDeleteButton()
            Else ' form is blank for adding a new asst
                If Request.QueryString("sn") <> "" Then
                    txtSn.Text = Request.QueryString("sn")
                    lblSerial.Text = Request.QueryString("sn")
                End If
                historyPanel.Visible = False
                btnDel.Visible = False
                btnHist.Visible = False
                btnUPd.Visible = False
                dspUpdBy2.Visible = False
            End If
        Else ' this is the postback routine
            If CStr(Request.QueryString("id")) <> "" Then
                historyPanel.Visible = False        'True
            End If
            Select Case txtCommand.Value
                Case "add" ' adds new asset record
                    validLocations("add") 'addNew()
                Case "upd" ' the update button was clicked 
                    validLocations("upd") ' updAsset()
                Case "del" ' the delete button was clicked
                    deleteAsset()
                Case Else '
            End Select
            txtCommand.Value = ""
            showHideDeleteButton()
        End If

    End Sub

    Sub fillDdls()

        ' SubGroup & Purpose Code  -------------------------------
        ddlSubGroup.Items.Clear()
        Dim sgSql As String = "SELECT '-' AS TPMCode, '' AS Purp "
        sgSql &= " UNION ALL "
        sgSql &= " SELECT TPMCode, Purp "
        sgSql &= " FROM TPM "
        sgSql &= " ORDER BY TPMCode"

        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing

        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(sgSql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sgSql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/EditAssetSD.aspx")
            Throw ex
        Finally
            swmsDb.Close()
        End Try

        ddlSubGroup.DataSource = sqldt
        ddlSubGroup.DataValueField = "TPMCode"
        ddlSubGroup.DataTextField = "TPMCode"
        ddlSubGroup.DataBind()
        '
        ' condition code --------------------------------------------
        ddlCc.Items.Clear()
        Dim ccSql As String = " Select '-' as SVD_Attribute UNION ALL "
        ccSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        ccSql &= " WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute"
        ddlCc.DataSource = cC.getAsDataTable(ccSql, Session("swmsDbConnection"))
        ddlCc.DataValueField = "SVD_Attribute"
        ddlCc.DataTextField = "SVD_Attribute"
        ddlCc.DataBind()
        '
        ' procurement code -----------------------------------------
        ddlProcCd.Items.Clear()
        Dim pcSql As String = "SELECT '-' AS ProcCd, '-' AS ProcDesc"
        pcSql &= " UNION ALL"
        pcSql &= " SELECT ProcCd, ProcDesc"
        pcSql &= " FROM ProcMakeBuyCodes "
        pcSql &= " WHERE MakeBuy = 'M' "
        pcSql &= " ORDER BY ProcCd"
        ddlProcCd.DataSource = cC.getAsDataTable(pcSql, Session("swmsDbConnection"))
        ddlProcCd.DataValueField = "ProcCd"
        ddlProcCd.DataTextField = "ProcCd"
        ddlProcCd.DataBind()

        ' reason -------------------------------------
        ddlReason.Items.Clear()
        Dim rSql As String = "SELECT '-' as SVD_Attribute UNION ALL "
        rSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        rSql &= " WHERE (SVD_Name = 'AssetReason') ORDER BY SVD_Attribute"
        ddlReason.DataSource = cC.getAsDataTable(rSql, Session("swmsDbConnection"))
        ddlReason.DataValueField = "SVD_Attribute"
        ddlReason.DataTextField = "SVD_Attribute"
        ddlReason.DataBind()

        ' Super Location --- "Status" ------------------------------
        ddlLocLvl1.Items.Clear()
        Dim sql1 As String = "SELECT LocationId, LocationIdCode FROM Locations "
        sql1 &= " WHERE (LocationLevel = 1)"
        'sql1 &= " and (locationidcode = '" & cC.BufStr(txtLoc1.Text.Trim) & "')"
        sql1 &= " ORDER BY LocationIdCode"
        ddlLocLvl1.DataSource = cC.getAsDataTable(sql1, Session("swmsDbConnection"))
        ddlLocLvl1.DataValueField = "LocationId"
        ddlLocLvl1.DataTextField = "LocationIdCode"
        ddlLocLvl1.DataBind()
        'default
        ddlLocLvl1.SelectedValue = "ACTIVE"

        ' Location --------- "Location" ------------------------
        ddlSavLvl2.Items.Clear()
        Dim sql2 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql2 &= " WHERE (LocationLevel = 2)"
        sql2 &= " ORDER BY LocationIdCode"
        Dim rtn2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
        ddlSavLvl2.DataSource = rtn2
        ddlSavLvl2.DataValueField = "ParentLocationID"
        ddlSavLvl2.DataTextField = "Code"
        ddlSavLvl2.DataBind()
        '
        ddlLocLvl2.Items.Clear()
        Dim tli As New ListItem
        tli.Text = "--"
        tli.Value = "0"
        ddlLocLvl2.Items.Add(tli)
        ' re-Populate the control after the data record has been read
        Dim j As Integer = 0
        For i As Integer = 0 To rtn2.Rows.Count - 1
            If rtn2.Rows(i)("ParentLocationID") = ddlLocLvl1.SelectedValue Then
                j = InStr(rtn2.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn2.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn2.Rows(i)("Code"), j + 1)
                ddlLocLvl2.Items.Add(litm)
            End If
        Next

        ' Sub -------------- "Building" ------------------- 
        ddlSavLvl3.Items.Clear()
        Dim sql3 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql3 &= " WHERE (LocationLevel = 3)"
        sql3 &= " ORDER BY LocationIdCode"
        Dim rtn3 As DataTable = cC.getAsDataTable(sql3, Session("swmsDbConnection"))
        ddlSavLvl3.DataSource = rtn3
        ddlSavLvl3.DataValueField = "ParentLocationID"
        ddlSavLvl3.DataTextField = "Code"
        ddlSavLvl3.DataBind()
        '
        ddlLocLvl3.Items.Clear()
        Dim tli3 As New ListItem
        tli3.Text = "--"
        tli3.Value = "0"
        ddlLocLvl3.Items.Add(tli3)
        ' Populate the control after the data record has been read
        'For i As Integer = 0 To rtn3.Rows.Count - 1
        '    If rtn3.Rows(i)("ParentLocationID") = ddlLocLvl2.SelectedValue Then
        '        j = InStr(rtn3.Rows(i)("Code"), "@")
        '        Dim litm As New ListItem
        '        litm.Value = Left(rtn3.Rows(i)("Code"), j - 1)
        '        litm.Text = Mid(rtn3.Rows(i)("Code"), j + 1)
        '        ddlLocLvl3.Items.Add(litm)
        '    End If
        'Next

        ' Micro ------------ "Bin" --------------------
        ddlSavLvl4.Items.Clear()
        Dim sql4 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql4 &= " WHERE (LocationLevel = 4)"
        sql4 &= " ORDER BY LocationIdCode"
        Dim rtn4 As DataTable = cC.getAsDataTable(sql4, Session("swmsDbConnection"))
        ddlSavLvl4.DataSource = rtn4
        ddlSavLvl4.DataValueField = "ParentLocationID"
        ddlSavLvl4.DataTextField = "Code"
        ddlSavLvl4.DataBind()
        '
        ddlLocLvl4.Items.Clear()
        Dim tli4 As New ListItem
        tli4.Text = "--"
        tli4.Value = "0"
        ddlLocLvl4.Items.Add(tli4)
        ' Populate the control after the data record has been read
        'For i As Integer = 0 To rtn4.Rows.Count - 1
        '    If rtn4.Rows(i)("ParentLocationID") = ddlLocLvl3.SelectedValue Then
        '        j = InStr(rtn4.Rows(i)("Code"), "@")
        '        Dim litm As New ListItem
        '        litm.Value = Left(rtn4.Rows(i)("Code"), j - 1)
        '        litm.Text = Mid(rtn4.Rows(i)("Code"), j + 1)
        '        ddlLocLvl4.Items.Add(litm)

        '    End If
        'Next
    End Sub

    Sub displayAsset(ByVal AId As String)
        Session("AId") = AId

        If CStr(AId) = "" Then
            Response.Redirect("FindAssetsSD.aspx")
        Else
            sql = "SELECT A.AssetId, A.Pid,"
            sql &= " ISNULL(A.SubGroup, '') AS SubGroup,"
            sql &= " ISNULL(A.PartNumber, '') AS PartNumber, "
            sql &= " ISNULL(A.NIIN, '') AS NIIN, "
            sql &= " ISNULL(A.SerialNumber, '') AS SerialNumber,"
            sql &= " ISNULL(A.Nomenclature, '') AS Nomenclature,"
            sql &= " ISNULL(A.ModelNumber, '') AS ModelNumber,"
            sql &= " ISNULL(A.CurrentCondition, '') AS ConditionCode,"
            sql &= " ISNULL(A.PIN, '') AS AcctCd,"
            sql &= " ISNULL(L1.LocationIdCode, 'Unknown') AS Status,"
            sql &= " ISNULL(L2.LocationIdCode, '') + ' - ' + ISNULL(L3.LocationIdCode, '')"
            sql &= "  + ' - ' + ISNULL(L4.LocationIdCode, '') AS Location,"
            sql &= " ISNULL(A.LocationId, 0) as LocN1, "
            sql &= " ISNULL(A.Location2, 0) as LocN2, "
            sql &= " ISNULL(A.Location3, 0) as LocN3, "
            sql &= " ISNULL(A.Location4, 0) as LocN4, "
            sql &= " ISNULL(A.ICNnum, '') AS ICN, ISNULL(ICNseq, 0) AS ICNseq,"
            sql &= " ISNULL(A.Reason, '') AS Reason,"
            sql &= " ISNULL(M.ProcurementCode, '') AS ProcurementCode,"
            sql &= " ISNULL(A.DocumentNumber, '') AS DocumentNumber,"
            sql &= " ISNULL(A.ReceivedFrom, '') AS ReceivedFrom,"
            sql &= " ISNULL(A.Manufacturer, '') AS CAGE,"
            sql &= " ISNULL(A.IssuedTo, '') AS IssuedTo,"
            sql &= " ISNULL(A.Remarks, '') AS Remarks,"
            sql &= " A.EffectiveDate, A.LastTransDate, "
            sql &= " ISNULL(P1.UserName, '') AS UpdatedBy"
            sql &= " FROM Assets A"
            sql &= " INNER JOIN PartsMaster M On A.Pid = M.Pid"
            sql &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationId"
            sql &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationId"
            sql &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationId"
            sql &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationId"
            sql &= " LEFT OUTER JOIN People P1 ON A.LastTransBy = P1.PeopleId"
            sql &= " WHERE (A.AssetId  = " & AId & ")"

            Dim locId As Integer = 0
            Dim rs As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
            If rs.Rows.Count > 0 Then

                lblpn.Text = rs.Rows(0)("PartNumber")
                lblAId.Text = rs.Rows(0)("AssetId")
                lblNomen.Text = rs.Rows(0)("Nomenclature")
                lblNiin.Text = rs.Rows(0)("NIIN")
                txtPid.Text = rs.Rows(0)("Pid") ' rdr("PID")
                txtManu.Text = rs.Rows(0)("CAGE")  ' rdr("manu")
                txtPn.Visible = False
                btnPart.Visible = False
                btnAdd.Visible = False
                lblSerial.Text = rs.Rows(0)("SerialNumber")
                txtSn.Text = rs.Rows(0)("SerialNumber") ' rdr("sn")
                lblModel.Text = rs.Rows(0)("ModelNumber") ' rdr("model")

                'Dim hSql As String = "SELECT TOP (1) AssetHistoryId, isnull(ah.ConditionCode,'') as cc, "
                'hSql &= "   isnull(ah.ProcurementCode,'') as pc, isnull(ah.PurposeCode,'') as purp, "
                'hSql &= "   isnull(ah.Status,'') as stat, isnull(ah.ReworkNumber,'') as rwk, "
                'hSql &= "   isnull(ah.LocationId,0) as loc, isnull(ah.ILSMISControlNumber,'') as ils, "
                'hSql &= "   isnull(ah.MaintDocNumber,'') as maintDoc, ah.EffectiveDate as effDate,"
                'hSql &= "   isnull(ah.ReceivedFrom, '') as ReceivedFrom, isnull(ah.IssuedTo, '') as IssuedTo, "
                'hSql &= "   isnull(ah.DocumentNumber,'') as docNum, isnull(ah.Remarks,'') as remarks, "
                'hSql &= "   isnull(ah.ICNnum,'') as ICN,  "
                'hSql &= "   isnull(ah.ICNSeq, '') as ICNSeq, "
                'hSql &= "   isnull(ah.SubGroup,'') as SubGroup,"
                'hSql &= "   isnull(ah.Reason,'') as reason, ah.TransDate as transDate, "
                'hSql &= "   isnull(pp.LastName, '') + ', ' + isnull(pp.FirstName,'') as modBy, "
                'hSql &= "   isnull(ah.LocationId, 0) as locN1, "
                'hSql &= "   isnull(ah.Location2, 0) as locN2, "
                'hSql &= "   isnull(ah.Location3, 0) as locN3, "
                'hSql &= "   isnull(ah.Location4, 0) as locN4, "
                'hSql &= "   isnull(loc1.LocationIdcode,' - ') + ' - ' + isnull(loc2.LocationIdcode,'') "
                'hSql &= "       + ' - ' + isnull(loc3.LocationIdcode,'') + ' - ' + isnull(loc4.LocationIdcode,'') as locName"
                ''
                'hSql &= " FROM AssetHistory ah"
                'hSql &= "    LEFT OUTER JOIN People pp on ah.TransBy = pp.PeopleId"
                'hSql &= "    left outer join locations loc1 on ah.LocationId = loc1.LocationId"
                'hSql &= "    left outer join locations loc2 on ah.Location2 = loc2.LocationId"
                'hSql &= "    left outer join locations loc3 on ah.Location3 = loc3.LocationId"
                'hSql &= "    left outer join locations loc4 on ah.Location4 = loc4.LocationId"
                'hSql &= " WHERE (ah.AssetId = " & AId & ") ORDER BY ah.TransDate DESC, assethistoryid desc"
                'Dim rf As DataTable = cC.getAsDataTable(hSql, Session("swmsDbConnection"))

                'If rf.Rows.Count > 0 Then

                dspRemarks.Text = rs.Rows(0)("remarks")

                txtICN.Text = rs.Rows(0)("ICN")
                If rs.Rows(0)("ICNseq") <> 0 Then
                    txtICNSeq.Text = Right("0000" & rs.Rows(0)("ICNseq"), 4)
                    dspICN.Text = rs.Rows(0)("ICN") & "-" & Right("0000" & rs.Rows(0)("ICNseq"), 4)
                Else
                    txtICNSeq.Text = ""
                    dspICN.Text = rs.Rows(0)("ICN")
                End If
                dspSubGroup.Text = rs.Rows(0)("SubGroup")
                ddlSubGroup.SelectedIndex = ddlSubGroup.Items.IndexOf(ddlSubGroup.Items.FindByValue(rs.Rows(0)("SubGroup")))
                txtPIN.Text = rs.Rows(0)("AcctCd")

                txtReceivedFrom.Text = UCase(rs.Rows(0)("ReceivedFrom"))
                txtIssuedTo.Text = UCase(rs.Rows(0)("IssuedTo"))
                dspCC.Text = rs.Rows(0)("ConditionCode")
                ddlCc.SelectedIndex = ddlCc.Items.IndexOf(ddlCc.Items.FindByValue(rs.Rows(0)("ConditionCode")))
                dspReason.Text = rs.Rows(0)("Reason")
                ddlReason.SelectedIndex = ddlReason.Items.IndexOf(ddlReason.Items.FindByValue(rs.Rows(0)("Reason")))

                If Not IsDBNull(rs.Rows(0)("EffectiveDate")) Then
                    If CStr(rs.Rows(0)("EffectiveDate")) <> "1/1/1900" Then
                        dspEffDate.Text = rs.Rows(0)("EffectiveDate")
                        txtEffDate.Text = rs.Rows(0)("EffectiveDate")
                    End If
                End If
                dspDocNum.Text = rs.Rows(0)("DocumentNumber")
                txtDocNum.Text = rs.Rows(0)("DocumentNumber")

                If Not IsDBNull(rs.Rows(0)("LastTransDate")) Then
                    If CStr(rs.Rows(0)("LastTransDate")) <> "1/1/1900" Then
                        dspHistoryDate.Text = FormatDateTime(rs.Rows(0)("LastTransDate"), 2)
                        lblHistoryDate.Text = FormatDateTime(rs.Rows(0)("LastTransDate"), 2)
                    End If
                End If
                dspUpdBy2.Visible = True
                dspUpdby.Text = rs.Rows(0)("UpdatedBy")
                lblUpdatedBy.Text = rs.Rows(0)("UpdatedBy")

                dspLoc.Text = rs.Rows(0)("Location")
                ddlLocLvl1.SelectedIndex = ddlLocLvl1.Items.IndexOf(ddlLocLvl1.Items.FindByValue(rs.Rows(0)("LocN1")))
                '
                Dim tliz As New ListItem
                tliz.Text = "--"
                tliz.Value = "0"
                ' re-Populate the controls after the data record has been read
                ddlLocLvl2.Items.Clear()
                ddlLocLvl2.Items.Add(tliz)
                Dim j As Integer = 0
                For i As Integer = 0 To ddlSavLvl2.Items.Count - 1
                    If ddlSavLvl2.Items(i).Value = ddlLocLvl1.SelectedValue Then
                        j = InStr(ddlSavLvl2.Items(i).Text, "@")
                        Dim litm As New ListItem
                        litm.Value = Left(ddlSavLvl2.Items(i).Text, j - 1)
                        litm.Text = Mid(ddlSavLvl2.Items(i).Text, j + 1)
                        ddlLocLvl2.Items.Add(litm)
                    End If
                Next
                ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByValue(rs.Rows(0)("LocN2")))
                '
                ddlLocLvl3.Items.Clear()
                Dim tlix As New ListItem
                tlix.Text = "--"
                tlix.Value = "0"
                ddlLocLvl3.Items.Add(tlix)
                j = 0
                For i As Integer = 0 To ddlSavLvl3.Items.Count - 1
                    If ddlSavLvl3.Items(i).Value = ddlLocLvl2.SelectedValue Then
                        j = InStr(ddlSavLvl3.Items(i).Text, "@")
                        Dim litm As New ListItem
                        litm.Value = Left(ddlSavLvl3.Items(i).Text, j - 1)
                        litm.Text = Mid(ddlSavLvl3.Items(i).Text, j + 1)
                        ddlLocLvl3.Items.Add(litm)
                    End If
                Next
                ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(rs.Rows(0)("LocN3")))
                '
                ddlLocLvl4.Items.Clear()
                Dim tliy As New ListItem
                tliy.Text = "--"
                tliy.Value = "0"
                ddlLocLvl4.Items.Add(tliy)
                j = 0
                For i As Integer = 0 To ddlSavLvl4.Items.Count - 1
                    If ddlSavLvl4.Items(i).Value = ddlLocLvl3.SelectedValue Then
                        j = InStr(ddlSavLvl4.Items(i).Text, "@")
                        Dim litm As New ListItem
                        litm.Value = Left(ddlSavLvl4.Items(i).Text, j - 1)
                        litm.Text = Mid(ddlSavLvl4.Items(i).Text, j + 1)
                        ddlLocLvl4.Items.Add(litm)
                    End If
                Next
                ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(rs.Rows(0)("LocN4")))
                '
                'txtAHId.Text = rs.Rows(0)("AssetHistoryId")

            Else
                txtAHId.Text = 0
                dspUpdBy2.Visible = False
            End If
            'showShopOrders(AId)
        End If

    End Sub

    Sub showHideDeleteButton()

        'sql = "select count(*) as allow from SWMSSecurity.dbo.PeopleFunctionClasses pfc  "
        'sql &= " where  (functionclassid in (99,98)) and peopleid = " & Session("SWMSUId")

        'Dim rp As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))

        'If rp.Rows.Count > 0 Then
        '    lblSerial.Visible = False
        '    txtSn.Visible = True
        '    btnDel.Visible = True
        'Else
        lblSerial.Visible = True
        txtSn.Visible = False
        btnDel.Visible = False
        'End If

    End Sub

    Sub validLocations(ByVal action As String)
        '---validate the locations
        UsrMsg.Value = ""

        Dim loc1 As Integer = 0, loc2 As Integer = 0
        Dim loc3 As Integer = 0, loc4 As Integer = 0

        '---1st level - super
        If Request.Form("ddlLocLvl1") <> "" Then
            loc1 = Request.Form("ddlLocLvl1")
        End If
        'If CStr(Request.Form("txtLoc1").Trim) <> "" Then
        '    Dim sql1 As String = "select top 1 LocationId from locations"
        '    sql1 &= " where (locationlevel = 1)"
        '    sql1 &= " and (locationidcode = '" & cC.BufStr(txtLoc1.Text.Trim) & "')"
        '    sql1 &= " order by locationid"
        '    Dim rl1 As DataTable = cC.getAsDataTable(sql1, Session("swmsDbConnection"))
        '    If rl1.Rows.Count > 0 Then ' its a match
        '        loc1 = rl1.Rows(0)("locationid")
        '    Else
        '        UsrMsg.Value &= "Super location '" & cC.BufStr(txtLoc1.Text.Trim) & "' not found "
        '    End If
        'End If

        '---2nd level - location
        If Request.Form("ddlLocLvl2") <> "" Then
            loc2 = Request.Form("ddlLocLvl2")
        End If
        'If CStr(Request.Form("txtLoc2").Trim) <> "" Then
        '    Dim sql2 As String = "select top 1 locationid, "
        '    sql2 &= " parentlocationid from locations"
        '    sql2 &= " where (locationidcode = '" & cC.BufStr(txtLoc2.Text.Trim) & "')"
        '    sql2 &= " and (locationlevel = 2)"
        '    If loc1 <> 0 Then
        '        sql2 &= " and (parentlocationid = " & loc1 & ")" '--------------------
        '    End If
        '    sql2 &= " order by locationid"
        '    Dim rl2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
        '    If rl2.Rows.Count > 0 Then ' its a match
        '        loc2 = rl2.Rows(0)("locationid")
        '        loc1 = rl2.Rows(0)("parentlocationid")
        '    Else
        '        UsrMsg.Value &= "Location '" & cC.BufStr(txtLoc2.Text.Trim) & "' not found "
        '    End If
        'End If

        '---3rd level - sub
        If Request.Form("ddlLocLvl3") <> "" Then
            loc3 = Request.Form("ddlLocLvl3")
        End If
        'If CStr(Request.Form("txtLoc3").Trim) <> "" Then
        '    Dim sql3 As String = " select  top 1 locationid, parentlocationid, "
        '    sql3 &= " isnull((select parentlocationid from locations "
        '    sql3 &= "   where locationid = loc.parentlocationid),0) as grandLocationid "
        '    sql3 &= " from locations loc"
        '    sql3 &= " where (locationidcode = '" & cC.BufStr(txtLoc3.Text.Trim) & "')"
        '    sql3 &= " and (locationlevel = 3)"
        '    If loc2 <> 0 Then
        '        sql3 &= " and (parentlocationid = " & loc2 & ")" '--------------------
        '    End If
        '    sql3 &= " order by locationid"
        '    Dim rl3 As DataTable = cC.getAsDataTable(sql3, Session("swmsDbConnection"))
        '    If rl3.Rows.Count > 0 Then ' its a match
        '        loc3 = rl3.Rows(0)("locationid")
        '        loc2 = rl3.Rows(0)("parentlocationid")
        '        loc1 = rl3.Rows(0)("grandLocationid")
        '    Else
        '        UsrMsg.Value &= "Sub Location '" & cC.BufStr(txtLoc3.Text.Trim) & "' not found "
        '    End If
        'End If

        '---4th level - micro
        If Request.Form("ddlLocLvl4") <> "" Then
            loc4 = Request.Form("ddlLocLvl4")
        End If
        'If CStr(Request.Form("txtLoc4").Trim) <> "" Then
        '    Dim sql4 As String = " select top 1 locationid, parentlocationid, "
        '    sql4 &= " isnull((select parentlocationid from locations "
        '    sql4 &= "   where locationid = loc.parentlocationid),0) as grandLocationid, "
        '    sql4 &= " isnull((select parentlocationid from locations"
        '    sql4 &= "   where locationid = (select parentlocationid from locations "
        '    sql4 &= "   where locationid = loc.parentlocationid)),0) as greatlocationid"
        '    sql4 &= "  from locations loc"
        '    sql4 &= " where (locationidcode = '" & cC.BufStr(txtLoc4.Text.Trim) & "')"
        '    sql4 &= " and (locationlevel = 4)"
        '    If loc3 <> 0 Then
        '        sql4 &= " and (parentlocationid = " & loc3 & ")" '--------------------
        '    End If
        '    sql4 &= " order by locationid"
        '    Dim rl4 As DataTable = cC.getAsDataTable(sql4, Session("swmsDbConnection"))
        '    If rl4.Rows.Count > 0 Then ' its a match
        '        loc4 = rl4.Rows(0)("locationid")
        '        loc3 = rl4.Rows(0)("parentlocationid")
        '        loc2 = rl4.Rows(0)("grandlocationid")
        '        loc1 = rl4.Rows(0)("greatlocationid")
        '    Else
        '        UsrMsg.Value &= "Micro Location '" & cC.BufStr(txtLoc4.Text.Trim) & "' not found"
        '    End If
        'End If

        ' other validation routines
        If txtICNSeq.Text.Trim <> "" Then
            If Not IsNumeric(txtICNSeq.Text.Trim) Then
                UsrMsg.Value = "ICN Sequence is not numeric."
            Else
                If Not IsNNInteger(txtICNSeq.Text.Trim) Then
                    UsrMsg.Value = "ICN Sequence should be a positive integer."
                End If
            End If
        End If

        If UsrMsg.Value = "" Then
            If action = "add" Then
                addNew(loc1, loc2, loc3, loc4)
            End If
            If action = "upd" Then
                updAsset(loc1, loc2, loc3, loc4)
            End If
        Else
            'failed validation
            '   what do you do next?              
            fillDdls()
            If CStr(Request.QueryString("id")) <> "" Then ' an asset is selected for edit
                displayAsset(Request.QueryString("id"))
                txtPn.Visible = False
                btnPart.Visible = False
                btnAdd.Visible = False
            Else
                btnUPd.Visible = False
            End If

        End If
    End Sub

    Sub showShopOrders(ByVal AId As String)

        sql = "select sonum from shoporders where assetid = " & AId
        sql &= " union select shoporder from bssdata where assetid = " & AId
        sql &= " ORDER BY sonum DESC "

        Dim so As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))


        If so.Rows.Count > 0 Then

            lblShopOrders.Visible = True
            If so.Rows.Count = 1 Then
                lblShopOrders.Text = "Shop Order:"
            Else
                lblShopOrders.Text = "Shop Orders:"
            End If
            Dim i As Integer
            For i = 0 To so.Rows.Count - 1

                Dim x1 As New TableRow
                str = "<a href='javascript:ShoSO(" & so.Rows(i)("SONum") & ");' title='Click to View Shop Order.'>" & so.Rows(i)("SONum") & "</a>"
                x1.Cells.Add(cC.DataCell(str, "center"))
                Table1.Rows.Add(x1)

            Next
        End If

    End Sub


    Sub updAssetOnly()

        Dim luSql As String = "select assetid from assets where pid = " & txtPid.Text
        luSql &= " and (serialnumber = '" & cC.BufStr(txtSn.Text.Trim) & "') "
        luSql &= " and (assetid <> " & Request.QueryString("id") & ")"
        Dim ru As DataTable = cC.getAsDataTable(luSql, Session("swmsDbConnection"))
        If ru.Rows.Count > 0 Then
            UsrMsg.Value = "Serial # " & txtSn.Text & " for Part # " & txtPn.Text & " already exists in SWMS"
        End If

        If UsrMsg.Value = "" Then
            Dim commaFirst As String = ""
            'lookup up the asset to compare changes
            Dim aSql As String = "SELECT AcceptanceDate AS accDate, ISNULL(SerialNumber,'') AS sn, "
            aSql &= " WarrantyBeginDate  AS warDate, WarrantyExpireDate AS warEnd, ISNULL(ModelNumber,'') AS model, "
            aSql &= " ISNULL(Manufacturer,'') AS manu, ISNULL(VendorId,0) AS vndId "
            aSql &= " FROM Assets "
            aSql &= " WHERE (AssetId = " & Request.QueryString("id") & ") "
            Dim ra As DataTable = cC.getAsDataTable(aSql, Session("swmsDbConnection"))
            If ra.Rows.Count > 0 Then
                Dim uSql As String = "UPDATE Assets SET"
                If ra.Rows(0)("sn") <> cC.BufStr(txtSn.Text.Trim) Then
                    uSql &= " SerialNumber = '" & cC.BufStr(txtSn.Text.Trim) & "'"
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If CStr(ra.Rows(0)("vndId")) <> CStr(Request.Form("ddlVnd")) Then ' ddlVnd.SelectedValue
                    uSql &= commaFirst & " VendorId = " & CStr(Request.Form("ddlVnd")) & " "
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If ra.Rows(0)("manu") <> cC.BufStr(txtManu.Text.Trim) Then
                    uSql &= commaFirst & " Manufacturer = '" & cC.BufStr(txtManu.Text.Trim) & "' "
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                ' If IsDate(txtAccDate.Text) Then
                '    If IsDBNull(ra.Rows(0)("accDate")) Then
                '        uSql &= commaFirst & " AcceptanceDate = '" & cC.BufStr(txtAccDate.Text.Trim) & "'"
                '        commaFirst = ", "
                '    Else
                '        If CStr(ra.Rows(0)("accDate")) <> CStr(txtAccDate.Text.Trim) Then
                '            uSql &= commaFirst & " AcceptanceDate = '" & cC.BufStr(txtAccDate.Text.Trim) & "'"
                '            commaFirst = ", "
                '        End If
                '    End If
                'End If

                uSql &= " WHERE (AssetId = " & Request.QueryString("id") & ")"
                '-------------------------------------------------------
                If commaFirst <> "" Then
                    cC.executeNonQuery(uSql, Session("swmsDbConnection"))
                    cC.LogIt("assets", "Assets: part #: " & lblpn.Text & " S/N: " & txtSn.Text & " updated ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))
                End If
            End If

            If txtCommand.Value = "updAO" Then
                Dim newPage As String = "EditAssetSD.aspx?id=" & Request.QueryString("id")
                If Request.QueryString("inv") <> "" Then
                    newPage &= "&inv=" & Request.QueryString("inv")
                End If
                Response.Redirect(newPage)
            End If

        End If
    End Sub

    Sub deleteAsset()

        If txtNewAssetId.Text = "" Then 'if new assetid was NOT entered,
            'delete
            sql = "DELETE FROM Assets where assetid = " & Request.QueryString("id")
            cC.executeNonQuery(sql, Session("swmsDbConnection"))

            sql = "DELETE FROM Assethistory where assetid = " & Request.QueryString("id")
            cC.executeNonQuery(sql, Session("swmsDbConnection"))

            Response.Redirect("FindAssetsSD.aspx")
        Else
            If Not IsNumeric(txtNewAssetId.Text) Then
                UsrMsg.Value = "New AssetId must be numeric (" & txtNewAssetId.Text & ")"
            Else
                'insert assethistory record for what we are about to do
                '------------- per Glenda ------------------
                'When inserting “asset history moved” record, 
                'copy all asset history data elements (cc, purp, ect) 
                'from maximum assethistoryid record of the asset being moved to (new assetId)
                Dim sqli As String = "insert into assethistory "
                sqli &= " (assetid, assetinvid, conditioncode, transdate, transby, remarks,"
                sqli &= " reason, documentnumber, ilsmiscontrolnumber, locationid, "
                sqli &= " location2, location3, location4, status, purposecode, procurementcode,"
                sqli &= " MaintDocNumber, EffectiveDate )"

                sqli &= " select top 1 assetid, assetinvid, conditioncode, getdate(),"
                sqli &= Session("SWMSUId") & " as transby, "
                sqli &= " 'asset history moved to " & txtNewAssetId.Text & "' as remarks, "
                sqli &= " reason, documentnumber, ilsmiscontrolnumber,"
                sqli &= " locationid, location2, location3, location4, status, "
                sqli &= " purposecode, procurementcode, MaintDocNumber, EffectiveDate "
                sqli &= " from assethistory where(assetid = " & txtNewAssetId.Text & ")"
                sqli &= " ORDER BY transdate DESC "
                cC.executeNonQuery(sqli, Session("swmsDbConnection"))

                '-------------------- per Glenda ------------------------------
                'provide option to overwrite asset data elements from deleted asset to new asset
                'If Request.Form("chkOvw") = "on" Then
                '    Dim updSql As String = "UPDATE Assets SET"
                '    If IsDate(txtAccDate.Text) Then
                '        updSql &= " AcceptanceDate = '" & cC.BufStr(txtAccDate.Text.Trim) & "', "
                '    End If
                '     updSql &= " VendorId = " & Request.Form("ddlVnd") & ", "
                '    If IsDate(txtWarDate.Text) Then
                '        updSql &= " WarrantyBeginDate = '" & cC.BufStr(txtWarDate.Text.Trim) & "', "
                '    End If
                '    updSql &= " Manufacturer = '" & cC.BufStr(txtManu.Text.Trim) & "'  "
                '    updSql &= " WHERE AssetId = " & txtNewAssetId.Text
                '    cC.executeNonQuery(updSql, Session("swmsDbConnection"))
                'End If

                'update oldassetid to aid to current assetid
                sql = "update assethistory set "
                sql &= " assetid = " & txtNewAssetId.Text & ","
                sql &= " oldassetid = " & Request.QueryString("id")
                sql &= " where (assetid = " & Request.QueryString("id") & ")"
                cC.executeNonQuery(sql, Session("swmsDbConnection"))

                'then delete asset
                sql = "DELETE FROM Assets where assetid = " & Request.QueryString("id")
                cC.executeNonQuery(sql, Session("swmsDbConnection"))

                'then redirect to new assetid
                Dim newPage As String = "EditAssetSD.aspx?id=" & txtNewAssetId.Text
                If Request.QueryString("inv") <> "" Then
                    newPage &= "&inv=" & Request.QueryString("inv")
                End If
                Response.Redirect(newPage)
            End If
        End If

    End Sub

    Sub addNew(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)
        UsrMsg.Value = ""

        'check for pid
        If CStr(txtPid.Text) = "" Then
            sql = " SELECT TOP 1 PId FROM PartsMaster WHERE (PartNumber = '" & cC.BufStr(txtPn.Text.Trim) & "') ORDER BY PId "
            Dim rp As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
            If rp.Rows.Count > 0 Then
                txtPid.Text = rp.Rows(0)("PId")
            Else
                UsrMsg.Value = "Part # " & txtPn.Text & " does not exist in SWMS" & Chr(13)
            End If
        End If

        'check for serial
        If CStr(txtSn.Text) = "" Then
            If (CStr(txtICN.Text) = "" Or CStr(txtICNSeq.Text) = "") Then
                UsrMsg.Value &= "Serial # or ICN & Seq Required" & Chr(13)
            End If
        End If

        If UsrMsg.Value <> "" Then
            'Response.Redirect(Request.ServerVariables("HTTP_REFERER"))
            'Response.Redirect(Request.RawUrl)
            'Response.Write("<script language=javascript> history.back(-1); </script>")
        Else
            If CStr(txtPid.Text) <> "" Then
                'check if asset already exists first!!!!
                sql = "SELECT AssetId from Assets  WHERE (Pid = " & txtPid.Text & ") "
                sql &= " AND (SerialNumber = '" & cC.BufStr(txtSn.Text.Trim) & "')"
                Dim rq As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
                If rq.Rows.Count > 0 Then
                    UsrMsg.Value &= "Part # " & txtPn.Text & Chr(13)
                    UsrMsg.Value &= "Serial # " & txtSn.Text & " already exists" & Chr(13)
                Else
                    'insert into assets --------------

                    Dim unifiedDate As Date = Date.Now
                    sql = "INSERT INTO Assets (Pid, SerialNumber, ModelNumber, AcceptanceDate, "
                    sql &= " WarrantyBeginDate, VendorId, Manufacturer, DateRecorded, RecordedBy)"
                    sql &= " Values (" & txtPid.Text & ", " '--Pid, "
                    sql &= " '" & cC.BufStr(txtSn.Text.Trim) & "', " '--SerialNumber, "
                    'If Not IsDate(txtAccDate.Text) Then
                    '    sql &= " NULL, " '--AcceptanceDate,"
                    'Else
                    '    sql &= " '" & cC.BufStr(txtAccDate.Text.Trim) & "', " '--AcceptanceDate,"
                    'End If
                    'If Not IsDate(txtWarDate.Text) Then
                    '    sql &= " NULL, " '--WarrantyBeginDate, "
                    'Else
                    '    sql &= " '" & cC.BufStr(txtWarDate.Text.Trim) & "', " '--WarrantyBeginDate, "
                    'End If
                    'sql &= Request.Form("ddlVnd") & ", " ' --VendorId, "
                    sql &= " '" & cC.BufStr(txtManu.Text.Trim) & "', " '--Manufacturer, "
                    sql &= " '" & unifiedDate & "', " '  --DateRecorded,"
                    sql &= Session("SWMSUId") & ") " ' --RecordedBy)"
                    sql &= " SELECT SCOPE_IDENTITY() "

                    '                    INSERT INTO Asset ( 
                    '                    PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber,
                    '                    ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition,
                    '                    LocationId, Location2, Location3, Location4, Remarks,
                    '                    SubGroup, DocumentNumber, Reason, ReceivedFrom, IssuedTo,
                    '                    EffectiveDate, LastTrans, LastTransDate, LastTransBy,
                    '                    DateRecorded, VendorId, PIN, IntendedUse, AcceptanceDate
                    ' ) VALUES (
                    '                    PID,
                    '                    PartNumber,
                    '                    Revision,
                    '                    NIIN,
                    '                    Nomenclature,
                    '                    SerialNumber,
                    '                    ModelNumber,
                    '                    Manufacturer,
                    '                    ICNnum,
                    '                    ICNseq,
                    '                    CurrentCondition,
                    '                    LocationId,
                    '                    Location2,
                    '                    Location3,
                    '                    Location4,
                    '                    Remarks,
                    '                    SubGroup,
                    '                    DocumentNumber,
                    '                    Reason,
                    '                    ReceivedFrom,
                    '                    IssuedTo,
                    '                    EffectiveDate,
                    '                    LastTrans,
                    '                    LastTransDate,
                    '                    LastTransBy,
                    '                    DateRecorded,
                    '                    VendorId,
                    '                    PIN,
                    '                    IntendedUse,
                    '                    AcceptanceDate
                    ')

                    'get the new asset id --------------
                    Dim newId As Integer = 0
                    Dim dfId As DataTable = cC.getAsDataTable(sql, Session("SWMSDBConnection").ToString, , Session("SWMSUID"))
                    If dfId.Rows.Count > 0 Then
                        newId = dfId.Rows(0).Item(0)
                    End If

                    ' insert into asset history --------------
                    Dim hSql As String = " INSERT INTO AssetHistory (AssetId, "
                    hSql &= " ConditionCode, Reason, "
                    If Request.QueryString("inv") <> "" Then
                        hSql &= " AssetInvId, "
                    End If
                    hSql &= " LocationId, Location2, Location3, Location4, "
                    hSql &= " Status, DocumentNumber,  "
                    hSql &= " EffectiveDate, Remarks, TransDate, TransBy)"
                    hSql &= " VALUES (" & newId & ", " 'AssetId"
                    hSql &= " '" & Request.Form("ddlCc") & "', " 'ConditionCode"
                    hSql &= " '" & Request.Form("ddlReason") & "', " 'reason"
                    If Request.QueryString("inv") <> "" Then
                        hSql &= Request.QueryString("inv") & ", " ' AssetInvId
                    End If
                    '*****************************************
                    If loc1 = 0 Then
                        hSql &= " NULL, " 'location 1"
                    Else
                        hSql &= loc1 & ", " 'location 1"
                    End If
                    If loc2 = 0 Then
                        hSql &= " NULL, " 'location 2"
                    Else
                        hSql &= loc2 & ", " 'location 2"
                    End If
                    If loc3 = 0 Then
                        hSql &= " NULL, " 'location 3"
                    Else
                        hSql &= loc3 & ", " 'location 3"
                    End If
                    If loc4 = 0 Then
                        hSql &= " NULL, " 'location 4"
                    Else
                        hSql &= loc4 & ", " 'location 4"
                    End If
                    '*****************************************
                    hSql &= " '" & Request.Form("ddlStatus") & "', " ' status"
                    hSql &= " '" & cC.BufStr(txtDocNum.Text.Trim) & "', " 'documentnumber"
                    If IsDate(cC.BufStr(txtEffDate.Text.Trim)) Then
                        hSql &= " '" & cC.BufStr(txtEffDate.Text.Trim) & "', " 'EffectiveDate"
                    Else
                        hSql &= " NULL, " 'EffectiveDate"
                    End If
                    hSql &= " '" & Left(cC.BufStr(txtRemarks.Text.Trim), 250) & "', " 'remarks"
                    hSql &= " '" & unifiedDate & "', " 'transdate"
                    hSql &= Session("SWMSUId") & ")" 'transby"

                    cC.executeNonQuery(hSql, Session("swmsDbConnection"))

                    'insert into eventlog --------------
                    cC.LogIt("assets", "Assets: part # " & txtPn.Text & " serial " & txtSn.Text & " added ", "", Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), Session("PQnum"), Session("swmsDbConnection"))
                    Dim newPage As String = "EditAssetSD.aspx?id=" & newId

                    If Request.QueryString("inv") <> "" Then
                        newPage &= "&inv=" & Request.QueryString("inv")
                    End If
                    If Request.QueryString("mtr") <> "" Then ' ???
                        newPage &= "&mtr=" & Request.QueryString("mtr")
                    End If
                    If Request.QueryString("loc") <> "" Then ' ???
                        newPage &= "&loc=" & Request.QueryString("loc")
                    End If
                    If Request.QueryString("sn") <> "" Then ' ???
                        newPage &= "&sn=" & Request.QueryString("sn")
                    End If
                    Response.Redirect(newPage)

                End If
            End If

        End If

    End Sub

    Sub updAsset(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)
        updAssetOnly()

        If UsrMsg.Value = "" Then

            Dim addNewHistoryRecord As Boolean = False ' do we do it?
            Dim rwkNum As String = ""
            If CStr(txtAHId.Text) = "0" Then ' theres no history record for it
                addNewHistoryRecord = True
            Else
                ' look up the asset history to compare changes
                Dim ahSql As String = "SELECT AssetId, "
                ahSql &= " ISNULL(ConditionCode, '') AS cc, "
                ahSql &= " ISNULL(Remarks, '') AS rmks, "
                ahSql &= " ISNULL(Reason, '') AS reason, "
                ahSql &= " ISNULL(DocumentNumber, '') AS docNum, "
                ahSql &= " ISNULL(LocationId, '') AS loc1, "
                ahSql &= " ISNULL(Location2, '') AS loc2, "
                ahSql &= " ISNULL(Location3, '') AS loc3, "
                ahSql &= " ISNULL(Location4, '') AS loc4, "
                ahSql &= " ISNULL(EffectiveDate, '') AS effDate, "
                ahSql &= " ISNULL(ICNnum, '') AS ICN, "
                ahSql &= " ISNULL(ICNSeq, '') AS ICNSeq, "
                ahSql &= " ISNULL(SubGroup, '') AS SubGroup, "
                ahSql &= " ISNULL(ReceivedFrom, '') AS ReceivedFrom, "
                ahSql &= " ISNULL(IssuedTo, '') AS IssuedTo "
                ahSql &= " FROM AssetHistory "
                ahSql &= " WHERE (AssetHistoryId = " & txtAHId.Text & ")"

                Dim rh As DataTable = cC.getAsDataTable(ahSql, Session("swmsDbConnection"))
                If rh.Rows.Count > 0 Then ' has anything changed?
                    Dim condCode As String = "-"
                    If rh.Rows(0)("cc") <> "" And rh.Rows(0)("cc") <> "-" Then
                        condCode = rh.Rows(0)("cc")
                    End If
                    Dim iseq As String = ""
                    If rh.Rows(0)("ICNSeq") <> 0 Then
                        iseq = Right("0000" + CStr(rh.Rows(0)("ICNSeq")), 4)
                    End If
                    If CStr(rh.Rows(0)("cc")) <> CStr(Request.Form("ddlCc")) Or _
                        CStr(rh.Rows(0)("loc1")) <> CStr(loc1) Or _
                        CStr(rh.Rows(0)("loc2")) <> CStr(loc2) Or _
                        CStr(rh.Rows(0)("loc3")) <> CStr(loc3) Or _
                        CStr(rh.Rows(0)("loc4")) <> CStr(loc4) Or _
                        rh.Rows(0)("reason") <> CStr(Request.Form("ddlReason")) Or _
                        rh.Rows(0)("docNum") <> cC.BufStr(txtDocNum.Text.Trim) Or _
                        rh.Rows(0)("rmks") <> cC.BufStr(txtRemarks.Text.Trim) Or _
                        rh.Rows(0)("ICN") <> cC.BufStr(txtRemarks.Text.Trim) Or _
                        iseq <> Right("0000" + cC.BufStr(txtICNSeq.Text.Trim), 4) Or _
                        rh.Rows(0)("SubGroup") <> CStr(Request.Form("ddlSubGroup")) Or _
                        rh.Rows(0)("ReceivedFrom") <> cC.BufStr(txtReceivedFrom.Text.Trim) Or _
                        rh.Rows(0)("IssuedTo") <> cC.BufStr(txtIssuedTo.Text.Trim) Or _
                        rh.Rows(0)("effDate") <> cC.BufStr(txtEffDate.Text.Trim) Then

                        addNewHistoryRecord = True
                    Else
                        UsrMsg.Value = "No change detected..."
                    End If
                End If
            End If ' If txtAHId.Text = 0 Then

            If addNewHistoryRecord = True Then
                Dim ihSql As String = "INSERT INTO AssetHistory ("
                ihSql &= " AssetId, ConditionCode, Remarks, Reason, DocumentNumber, "
                ihSql &= " LocationId, Location2, Location3, Location4, "
                ihSql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, "
                ihSql &= " ReceivedFrom, IssuedTo, TransDate, TransBy "
                '
                ihSql &= "  ) VALUES ("
                '
                ihSql &= Request.QueryString("id") & ", "   ' AssetId
                If CStr(Request.Form("ddlCc")) = "-" Then
                    ihSql &= "'', " ' ConditionCode
                Else
                    ihSql &= "'" & CStr(Request.Form("ddlCc")) & "', " ' ConditionCode
                End If
                ihSql &= "'" & cC.BufStr(txtRemarks.Text.Trim) & "', " ' Remarks
                ihSql &= "'" & CStr(Request.Form("ddlReason")) & "', " ' reason
                ihSql &= "'" & cC.BufStr(txtDocNum.Text.Trim) & "', " ' DocumentNumber
                If loc1 = 0 Then
                    ihSql &= " NULL, " 'location 1"
                Else
                    ihSql &= loc1 & ", " 'location 1"
                End If
                If loc2 = 0 Then
                    ihSql &= " NULL, " 'location 2"
                Else
                    ihSql &= loc2 & ", " 'location 2"
                End If
                If loc3 = 0 Then
                    ihSql &= " NULL, " 'location 3"
                Else
                    ihSql &= loc3 & ", " 'location 3"
                End If
                If loc4 = 0 Then
                    ihSql &= " NULL, " 'location 4"
                Else
                    ihSql &= loc4 & ", " 'location 4"
                End If
                If IsDate(txtEffDate.Text) Then
                    ihSql &= "'" & cC.BufStr(txtEffDate.Text.Trim) & "', " ' EffectiveDate
                Else
                    ihSql &= "NULL, " ' EffectiveDate
                End If
                ihSql &= "'" & cC.BufStr(txtICN.Text.Trim) & "', " ' ICNnum
                If (txtICNSeq.Text.Trim <> "") Then
                    If (CInt(txtICNSeq.Text.Trim) <> 0) Then
                        ihSql &= txtICNSeq.Text.Trim & ", " ' ICNSeq
                    Else
                        ihSql &= "NULL, " ' ICNSeq
                    End If
                End If
                ihSql &= "'" & CStr(Request.Form("ddlSubGroup")) & "', " ' SubGroup
                ihSql &= "'" & cC.BufStr(txtReceivedFrom.Text.Trim) & "', " ' ReceivedFrom
                ihSql &= "'" & cC.BufStr(txtIssuedTo.Text.Trim) & "', " ' IssuedTo
                '
                ihSql &= "getdate(), " ' TransDate
                ihSql &= Session("SWMSUId") & ")" ' TransBy
                cC.executeNonQuery(ihSql, Session("swmsDBConnection"))

                cC.LogIt("Assets", "Asset history created for Part #: " & lblpn.Text & " S/N: " & txtSn.Text & " (AssetId: " & Request.QueryString("id") & ")", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))
            End If

            Dim newPage As String = "EditAssetSD.aspx?id=" & Request.QueryString("id")
            If Request.QueryString("inv") <> "" Then
                newPage &= "&inv=" & Request.QueryString("inv")
            End If
            Response.Redirect(newPage)

        End If
    End Sub

    Public Function IsNNInteger(ByVal value As String) As Boolean
        If (value = "") Then
            value = 0
        End If
        'test for Non-negative integer
        Dim re As New Regex("^\d+$")
        Dim mt As Match = re.Match(value)

        Return mt.Success
    End Function

    Public Function IsPositiveFloat(ByVal value As String) As Boolean
        If (value = "") Then
            value = 0
        End If
        Dim re As New Regex("^[0-9]*(\.\d+)?$")
        Dim mt As Match = re.Match(value)

        Return mt.Success
    End Function

End Class
