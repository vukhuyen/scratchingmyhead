﻿Imports System.Data
Partial Class Tracking_EditMeters
    Inherits System.Web.UI.Page

#Region "declarations"
    Dim cC As New commonClass
    Dim sql As String = ""
    Dim str As String
#End Region

#Region "pageLoad"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
        If msg <> "" Then
            Response.Redirect(msg)
        End If

        If Request.QueryString("sn") <> "" Then
            If Request.QueryString("sn") <> CStr(txtSn.Text) Then
                lblSnWarning.Text = "Click update to apply new serial number"
            End If
        End If
        '
        If Not Page.IsPostBack Then
            fillDdls()
            If CStr(Request.QueryString("id")) <> "" And _
             CStr(Request.QueryString("id")) <> "0" Then ' an asset is selected for edit
                displayMeter(Request.QueryString("id"))
                btnUPd.Visible = True
                btnAdd.Visible = False
            Else ' form is blank for adding a new asst

                If Request.QueryString("sn") <> "" Then
                    txtSn.Text = Request.QueryString("sn")
                End If
                btnUPd.Visible = False
                btnAdd.Visible = True
            End If
        Else
            Select Case txtCommand.Value
                Case "add" ' adds new meter record
                    addNew()
                Case "upd" ' the update button was clicked 
                    updMeter()
                Case "addPrep", "pic", "can"
                    displayMeter(Request.QueryString("id"))
                Case "addRdg"
                    addRdg()
                Case "updRdg"
                    updRdg()
                Case "delRdg"
                    delRdg()
                Case Else ' a new location was selected or added OR the add level button was clicked
                    displayReadings()
            End Select
            txtCommand.Value = ""
        End If

    End Sub
#End Region

#Region " meters "

    '---fill the dropdown lists (except for locations)
    Sub fillDdls()
        ' meter type --------------------------------------------
        ddlMtrType.Items.Clear()
        sql = "" 'select '---' as SVD_Attribute union all"
        sql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        sql &= " WHERE (SVD_Name = 'MeterType') ORDER BY SVD_Attribute"

        ddlMtrType.DataSource = cC.getAsDataTable(sql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\EditMeters.aspx.vb - fillDdls()")
        ddlMtrType.DataValueField = "SVD_Attribute"
        ddlMtrType.DataTextField = "SVD_Attribute"
        ddlMtrType.DataBind()
    End Sub

    '---displays the selected meter record
    Sub displayMeter(ByVal mtrId As String)
        Session("mtrId") = mtrId

        If CStr(mtrId) = "" Then
            Response.Redirect("FindMeters.aspx")
        Else
            sql = " select meterid, isnull(metertype,'') as mtrType,  "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "        loc1.locationidcode else locAh1.locationIdCode end,'') as loc1,  "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "            loc2.locationidcode else locAh2.locationIdCode end,'') as loc2, "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "        loc3.locationidcode else locAh3.locationIdCode end ,'') as loc3,  "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "        loc4.locationidcode else locAh4.locationIdCode end ,'') as loc4, "
            sql &= "    isnull(mtr.assetid,0) as assetId, isnull(ass.serialnumber,'') as sn,  "
            sql &= "    isnull(Rollover,0) as rolo, isnull(Comments,'') as cmt "
            sql &= " from meters mtr "
            sql &= "    left outer join assets ass on mtr.assetid = ass.assetid "
            '---join locations on meter
            sql &= "    left outer join locations loc1 on mtr.locationid = loc1.locationid  "
            sql &= "    left outer join locations loc2 on mtr.location2 = loc2.locationid  "
            sql &= "    left outer join locations loc3 on mtr.location3 = loc3.locationid  "
            sql &= "    left outer join locations loc4 on mtr.location4 = loc4.locationid  "
            '--- determine most recent assethistory record
            sql &= "    left outer join ( "
            sql &= "        select assetid, max(assethistoryid) as maxid from assethistory group by assetid "
            sql &= "    ) mah on mtr.assetid = mah.assetid "
            '--- join on most recent asset history record
            sql &= "    left outer join assethistory ah on mah.maxid = ah.assethistoryid "
            '---join locations on most recent asset history record
            sql &= "    left outer join locations locAh1 on ah.locationid = locAh1.locationid  "
            sql &= "    left outer join locations locAh2 on ah.location2 = locAh2.locationid  "
            sql &= "    left outer join locations locAh3 on ah.location3 = locAh3.locationid  "
            sql &= "    left outer join locations locAh4 on ah.location4 = locAh4.locationid "
            sql &= " where (meterid = " & mtrId & ")"

            Dim rs As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\EditMeters.aspx.vb - displayMeter()")

            lblId.Text = rs.Rows(0)("meterid") ' rdr("meterid")
            txtCmt.Text = rs.Rows(0)("cmt") ' rdr("cmt")
            txtRolo.Text = FormatNumber(rs.Rows(0)("rolo"), 0, , , 0)
            Try
                ddlMtrType.SelectedValue = rs.Rows(0)("mtrType") ' rdr("mtrType")
            Catch ex As Exception
            End Try
            ' ---these maybe affected if navigated from assets
            txtSn.Text = rs.Rows(0)("sn") ' rdr("sn")
            txtLoc1.Text = rs.Rows(0)("loc1")
            txtLoc2.Text = rs.Rows(0)("loc2")
            txtLoc3.Text = rs.Rows(0)("loc3")
            txtLoc4.Text = rs.Rows(0)("loc4")

            If CStr(Request.QueryString("aid")) <> "" Then
                txtAid.Value = Request.QueryString("aid")             
            Else
                txtAid.Value = rs.Rows(0)("assetId") ' rdr("assetId")
            End If

            If CStr(txtAid.value) = "0" Then '  the meter is NOT attached to an asset
                '  displayLocation(txtLoc.Text) ' allow the location to be edited
                lnkAst.Visible = False
                lblAst.Visible = False
            Else ' the meter IS attached to an asset 
                lblAst.Visible = True
                lnkAst.Visible = True ' link to asset from meter
                lnkAst.NavigateUrl = "EditAsset.aspx?id=" & txtAid.value
                lnkAst.Text = txtSn.Text
                'txtLoc1.ReadOnly = True
                'txtLoc2.ReadOnly = True
                'txtLoc3.ReadOnly = True
                'txtLoc4.ReadOnly = True
            End If

            displayReadings()
        End If

    End Sub

    '---begins the process of validating a new meter to the meters table
    Sub addNew()
        UsrMsg.Value = ""
        Dim ok2go As Boolean = False

        'deal with asset serial number ------
        If CStr(txtSn.Text) <> "" Then ' 
            If CStr(txtAid.value) = "" Then ' asset sn was entered but not verified
                '------------------------------------------------------------------
                Dim strSn As String = txtAid.value.Trim
                sql = "select ast.assetid,  "
                sql &= "    isnull(locAh1.locationIdCode,'') as loc1,"
                sql &= "    isnull(locAh2.locationIdCode,'') as loc2,"
                sql &= "    isnull(locAh3.locationIdCode,'') as loc3,"
                sql &= "    isnull(locAh4.locationIdCode,'') as loc4"
                sql &= " from assets ast"
                sql &= "    left outer join ( "
                sql &= "        select assetid, max(assethistoryid) as maxid from assethistory group by assetid "
                sql &= "    ) mah on ast.assetid = mah.assetid "
                sql &= "    left outer join assethistory ah on mah.maxid = ah.assethistoryid"
                sql &= "    left outer join locations locAh1 on ah.locationid = locAh1.locationid  "
                sql &= "    left outer join locations locAh2 on ah.location2 = locAh2.locationid  "
                sql &= "    left outer join locations locAh3 on ah.location3 = locAh3.locationid  "
                sql &= "    left outer join locations locAh4 on ah.location4 = locAh4.locationid"
                sql &= " where serialnumber = '" & cC.BufStr(Request.Form("txtSn")) & "'"

                Dim rq As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\EditMeters.aspx.vb - addNew()")

                Dim i As Integer
                For i = 0 To rq.Rows.Count - 1
                    txtAid.Value = rq.Rows(i)("AssetId") ' rdr("assetid")
                    txtLoc1.Text = rq.Rows(i)("loc1") ' rdr("assetid")
                    txtLoc2.Text = rq.Rows(i)("loc2") ' rdr("assetid")
                    txtLoc3.Text = rq.Rows(i)("loc3") ' rdr("assetid")
                    txtLoc4.Text = rq.Rows(i)("loc4") ' rdr("assetid")
                Next

                'if ONLY one match is found call addSerialNumber
                If rq.Rows.Count = 1 Then
                    ok2go = True
                Else
                    Dim snPopUp As String
                    If rq.Rows.Count = 0 Then 'suggest redirect to maintain assets page
                        snPopUp = "if (confirm('" & Request.Form("txtSn") & " was not found. Do you want to add it?')) {"
                        snPopUp &= "window.navigate('EditAsset.aspx?sn=" & Request.Form("txtSn")
                        snPopUp &= "&mtr=0');}"
                    Else ' more than one match was found, pop-up the search screen
                        txtCommand.Value = "addSnPrep"
                        snPopUp = "vWinSch = window.open(""SNSearch.aspx?sn=" & Request.Form("txtSn") & """,""SN"","
                        snPopUp &= """width=400,height=424,status=no,resizable=yes,top=75,left=175,scrollbars=yes"");"
                        snPopUp &= "vWinSch.opener = self;"
                        snPopUp &= "vWinSch.focus();"
                    End If
                    Response.Write("<SCRIPT LANGUAGE='JavaScript'>" & snPopUp & "</SCRIPT>")
                End If
                '------------------------------------------------------------------
            Else ' the id has been verified for the asset
                ok2go = True
            End If
        Else ' the meter is not attached to an asset
            ok2go = True
        End If

        If ok2go = True Then
            validLocations("add")
        End If

    End Sub

    '---really adds the meter
    Private Sub addMeter(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)
        '' insert the new meter record -----------
        sql = "insert into Meters (MeterType, LocationId, Location2, Location3, Location4, Rollover, Comments, AssetId)"
        sql &= " Values ('" & ddlMtrType.SelectedValue & "', " ' MeterType
        sql &= loc1 & ", " & loc2 & ", " & loc3 & ", " & loc4 & ", "
        If IsNumeric(txtRolo.Text) Then
            sql &= txtRolo.Text & ", "
        Else
            sql &= " NULL, "
        End If
        sql &= "'" & cC.BufStr(Left(txtCmt.Text, 200).Trim) & "', "
        If CStr(txtAid.Value) <> "" Then
            sql &= txtAid.Value & ")" ' AssetId
        Else
            sql &= " NULL)" ' AssetId
        End If
        sql &= " SELECT SCOPE_IDENTITY() "

        'get the new meterid -----------
        Dim dlId As DataTable = cC.getAsDataTable(sql, Session("SWMSDBConnection").ToString, , Session("SWMSUID").ToString, "Tracking/editMeters.aspx.vb")
        If dlId.Rows.Count > 0 Then
            Response.Redirect("EditMeters.aspx?id=" & dlId.Rows(0).Item(0))
        End If

    End Sub

    '---validates the locations
    Sub validLocations(ByVal action As String)
        '---validate the locations
        UsrMsg.Value = ""

        Dim loc1 As Integer = 0, loc2 As Integer = 0
        Dim loc3 As Integer = 0, loc4 As Integer = 0

        '---1st level - super
        If CStr(Request.Form("txtLoc1").Trim) <> "" Then
            Dim sql1 As String = "select top 1 LocationId from locations"
            sql1 &= " where (locationlevel = 1)"
            sql1 &= " and (locationidcode = '" & cC.BufStr(Request.Form("txtLoc1").Trim) & "')"
            sql1 &= " order by locationid"
            Dim rl1 As DataTable = cC.getAsDataTable(sql1, Session("swmsDbConnection"))
            If rl1.Rows.Count > 0 Then ' its a match
                loc1 = rl1.Rows(0)("locationid")
            Else
                UsrMsg.Value &= "Super location '" & cC.BufStr(Request.Form("txtLoc1").Trim) & "' not found "
            End If
        End If

        '---2nd level - location
        If CStr(Request.Form("txtLoc2").Trim) <> "" Then
            Dim sql2 As String = "select top 1 locationid, "
            sql2 &= " parentlocationid from locations"
            sql2 &= " where (locationidcode = '" & cC.BufStr(Request.Form("txtLoc2").Trim) & "')"
            sql2 &= " and (locationlevel = 2)"
            If loc1 <> 0 Then
                sql2 &= " and (parentlocationid = " & loc1 & ")" '--------------------
            End If
            sql2 &= " order by locationid"
            Dim rl2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
            If rl2.Rows.Count > 0 Then ' its a match
                loc2 = rl2.Rows(0)("locationid")
                loc1 = rl2.Rows(0)("parentlocationid")
            Else
                UsrMsg.Value &= "Location '" & cC.BufStr(Request.Form("txtLoc2").Trim) & "' not found "
            End If
        End If

        '---3rd level - sub
        If CStr(Request.Form("txtLoc3").Trim) <> "" Then
            Dim sql3 As String = " select  top 1 locationid, parentlocationid, "
            sql3 &= " isnull((select parentlocationid from locations "
            sql3 &= "   where locationid = loc.parentlocationid),0) as grandLocationid "
            sql3 &= " from locations loc"
            sql3 &= " where (locationidcode = '" & cC.BufStr(Request.Form("txtLoc3").Trim) & "')"
            sql3 &= " and (locationlevel = 3)"
            If loc2 <> 0 Then
                sql3 &= " and (parentlocationid = " & loc2 & ")" '--------------------
            End If
            sql3 &= " order by locationid"
            Dim rl3 As DataTable = cC.getAsDataTable(sql3, Session("swmsDbConnection"))
            If rl3.Rows.Count > 0 Then ' its a match
                loc3 = rl3.Rows(0)("locationid")
                loc2 = rl3.Rows(0)("parentlocationid")
                loc1 = rl3.Rows(0)("grandLocationid")
            Else
                UsrMsg.Value &= "Sub Location '" & cC.BufStr(Request.Form("txtLoc3").Trim) & "' not found "
            End If
        End If

        '---4th level - micro
        If CStr(Request.Form("txtLoc4").Trim) <> "" Then
            Dim sql4 As String = " select top 1 locationid, parentlocationid, "
            sql4 &= " isnull((select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid),0) as grandLocationid, "
            sql4 &= " isnull((select parentlocationid from locations"
            sql4 &= "   where locationid = (select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid)),0) as greatlocationid"
            sql4 &= "  from locations loc"
            sql4 &= " where (locationidcode = '" & cC.BufStr(Request.Form("txtLoc4").Trim) & "')"
            sql4 &= " and (locationlevel = 4)"
            If loc3 <> 0 Then
                sql4 &= " and (parentlocationid = " & loc3 & ")" '--------------------
            End If
            sql4 &= " order by locationid"
            Dim rl4 As DataTable = cC.getAsDataTable(sql4, Session("swmsDbConnection"))
            If rl4.Rows.Count > 0 Then ' its a match
                loc4 = rl4.Rows(0)("locationid")
                loc3 = rl4.Rows(0)("parentlocationid")
                loc2 = rl4.Rows(0)("grandlocationid")
                loc1 = rl4.Rows(0)("greatlocationid")
            Else
                UsrMsg.Value &= "Micro Location '" & cC.BufStr(Request.Form("txtLoc4").Trim) & "' not found"
            End If
        End If

        If UsrMsg.Value = "" Then

            If action = "add" Then
                addMeter(loc1, loc2, loc3, loc4)
            End If
            If action = "upd" Then
                reallyUpdateMeter(loc1, loc2, loc3, loc4)
            End If

        End If
    End Sub

    '---begins the process of validating updates to the meter record
    Sub updMeter()
        Dim ok2go As Boolean = False

        If txtPicked.Value = "pick" Then ' if a serial number is selected
            ok2go = True
        Else
            If CStr(txtSn.Text) = "" Then  ' if a serial number is not entered
                ok2go = True
            Else ' NO serial number is entered
                'look up the old serial number to see if its changed on the form
                Dim luSql As String = "select isnull(m.AssetId,0) as assetId, isnull(ass.Serialnumber,'') as sn"
                luSql &= " from meters m left outer join assets ass on m.assetid = ass.assetid"
                luSql &= " where (meterid = " & Request.QueryString("id") & ")"

                Dim rs As DataTable = cC.getAsDataTable(luSql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\EditMeters.aspx.vb - updMeter() - chkOldSN")

                If rs.Rows.Count > 0 Then
                    If cC.BufStr(rs.Rows(0)("sn")) = cC.BufStr(txtSn.Text.Trim) Then ' no change
                        ok2go = True
                    Else
                        'look up the entered serial number
                        Dim sql2 As String = "select assetid from assets where serialnumber = '" & cC.BufStr(Request.Form("txtSn")) & "'"

                        Dim rt As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\EditMeters.aspx.vb - updMeter() - chkSN")
                        Dim i As Integer
                        For i = 0 To rt.Rows.Count - 1
                            txtAid.Value = rt.Rows(i)("assetid") ' rdr2("assetid")
                        Next

                        If rt.Rows.Count = 1 Then 'if theres only 1, return the asset id
                            ok2go = True
                        Else
                            Dim snPopUp As String
                            If rt.Rows.Count = 0 Then 'suggest redirect to maintain assets page
                                snPopUp = "if (confirm('" & Request.Form("txtSn") & " was not found. Do you want to add it?')) {"
                                snPopUp &= "window.navigate('EditAsset.aspx?sn=" & Request.Form("txtSn")
                                snPopUp &= "&mtr=" & Request.QueryString("id") & "');}"
                            Else ' more than one match was found, pop-up the search screen
                                txtCommand.Value = "addSnPrep"
                                snPopUp = "vWinSch = window.open(""SNSearch.aspx?sn=" & Request.Form("txtSn") & """,""SN"","
                                snPopUp &= """width=400,height=424,status=no,resizable=yes,top=75,left=175,scrollbars=yes"");"
                                snPopUp &= "vWinSch.opener = self;"
                                snPopUp &= "vWinSch.focus();"
                            End If
                            Response.Write("<SCRIPT LANGUAGE='JavaScript'>" & snPopUp & "</SCRIPT>")
                        End If ' couunter = 1
                    End If ' matched
                End If ' If luRdr.Read Then
            End If ' serial number is entered
        End If ' If txtPicked.Text = "pick" Then
        'deal with the serial number

        If ok2go = True Then
            validLocations("upd")
        End If
        txtPicked.Value = ""
    End Sub

    '---really updates the meter
    Private Sub reallyUpdateMeter(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)

        Dim insAssetHist As Boolean = False

        sql = "update meters set "
        If CStr(txtSn.Text) = "" Then
            sql &= " assetid = NULL, "
        Else
            sql &= " assetid = " & txtAid.Value & ", "
        End If
        If IsNumeric(txtRolo.Text) Then
            sql &= " Rollover = " & txtRolo.Text & ","
        End If
        sql &= " MeterType = '" & ddlMtrType.SelectedValue & "',"
        sql &= " Comments = '" & Left(cC.BufStr(txtCmt.Text), 200).Trim & "'"
        If CStr(txtSn.Text) = "" Then ' meter is not attached to asset
            '---update the meter location
            sql &= ", LocationId = " & loc1 & ", Location2 = " & loc2 & ", "
            sql &= " Location3 = " & loc3 & ", Location4 = " & loc4
        Else ' meter is attached to asset
            '---update the most recent asset history location
            insAssetHist = True
        End If
        sql &= " where (MeterId = " & Request.QueryString("id") & ")"

        Try
            cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "Tracking\EditMeters.aspx.vb - reallyUpdateMeter() - updMeter")
        Catch ex As Exception
        End Try

        If insAssetHist = True Then
            sql = "Insert into assethistory "
            sql &= "    (assetid, bssid,conditioncode, transdate, transby, remarks,"
            sql &= "    reason, documentnumber, ilsmiscontrolnumber, LocationId, Location2, "
            sql &= "    location3, location4, Status, Purposecode, ProcurementCode, "
            sql &= "    MaintDocNumber, EffectiveDate, oldAssetId, ReworkNumber)"

            sql &= " select top 1 assetid, bssid, conditioncode, getdate(), "
            sql &= Session("SWMSUId") & " transby, 'Meter location update' as remarks, "
            sql &= "    reason, documentnumber, ilsmiscontrolnumber, "
            sql &= loc1 & ", " & loc2 & ", " & loc3 & ", " & loc4 & ", "
            sql &= "    status, purposecode, procurementcode, maintdocnumber, effectivedate, "
            sql &= "    oldassetid, reworknumber "
            sql &= " from assethistory WHERE (assetid = " & txtAid.Value & ") order by transdate desc"

            cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "AssetTracking\EditMeters.aspx.vb - reallyUpdateMeter() - InsAssetHist")
        
        End If

        Response.Redirect("EditMeters.aspx?id=" & Request.QueryString("id"))

    End Sub

#End Region

#Region " readings "

    'build the meter readings table
    Sub displayReadings()

        If CStr(Request.QueryString("id")) <> "" Then
            readingsHeader()
            addRow()

            sql = "select meterrdgid, rDate, rValue, rSrc, rCmt, stat, prevRdg, numDays, "
            sql &= " case when stat = 'Failed' then rFhpd else"
            '---if status is failed, then show what was entered
            '---ohter wise (current value - prev. value) / date diff
            sql &= "    (rValue - prevRdg) / numDays end as rFhpd  from ("

            sql &= " select meterrdgid, rdgDate as rDate, "
            sql &= "    isnull(rdgvalue,0) as rValue, isnull(failhrsperday,0) as rFhpd, "
            sql &= "        datediff(d, (select top 1 RdgDate from meterreadings "
            sql &= "        where (meterid = mr.meterid) and (rdgDate < mr.RdgDate) and (status <> 'Exclude')"
            sql &= "        order by rdgDate desc), rdgDate) as numDays,"
            sql &= "    (select top 1 rdgValue from meterreadings "
            sql &= "        where (meterid = mr.meterid) and (rdgDate < mr.RdgDate) and (status <> 'Exclude')"
            sql &= "        order by rdgDate desc) as prevRdg,"
            sql &= "    isnull(source,'') as rSrc, isnull(comments,'') as rCmt, isnull(status,'') as stat "
            sql &= " from meterreadings mr where (meterid = " & Request.QueryString("id") & ")"

            sql &= " ) ty ORDER BY rDate DESC"

            Dim rm As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\EditMeters.aspx.vb - displayReadings()")

            Dim altRow As Boolean = False
            Dim i As Integer
            For i = 0 To rm.Rows.Count - 1
                Dim x1 As New TableRow
                If CStr(rm.Rows(i)("meterrdgid")) = CStr(txtPicked.Value) Then

                    str = "<input type=""text"" class=""SmContent"" size=""10"" maxlength=""10"""
                    str &= " id=""txtDate"" name=""txtDate"" onblur=""javascript:return(chkDate(this));"" "
                    If IsDate(rm.Rows(i)("rdate")) Then
                        str &= " value="""">"
                    Else
                        str &= " value=""" & rm.Rows(i)("rdate") & """>"
                    End If
                    x1.Cells.Add(cC.DataCell(str, "center"))

                    str = "<input type=""text"" class=""SmContent"" maxlength=""10"" onblur=""javascript:numChk(this);"" "
                    str &= " size=""8""  id=""txtValue"" name=""txtValue"" value=""" & rm.Rows(i)("rValue") & """>"
                    x1.Cells.Add(cC.DataCell(str, "center"))

                    str = "<select name=""selStatus"" id=""selStatus"" class=""SmContent"">"
                    Dim stSql As String = " SELECT SVD_Attribute FROM System_Validation_Dictionary "
                    stSql &= " WHERE (SVD_Name = 'MeterStatus') ORDER BY SVD_Attribute"
                    Dim ri As DataTable = cC.getAsDataTable(stSql, Session("swmsDbConnection"))
                    If ri.Rows.Count > 0 Then
                        Dim j As Integer
                        For j = 0 To ri.Rows.Count - 1
                            str &= "<option value=""" & ri.Rows(j)("SVD_Attribute") & """"
                            If CStr(ri.Rows(j)("SVD_Attribute")) = CStr(rm.Rows(i)("stat")) Then
                                str &= " selected "
                            End If
                            str &= ">" & ri.Rows(j)("SVD_Attribute") & "</option>"
                        Next
                    End If
                    str &= "</select>"
                    x1.Cells.Add(cC.DataCell(str, "center"))

                    x1.Cells.Add(cC.DataCell("", "center"))

                    str = "<input type=""text"" class=""SmContent"" size=""5"" maxlength=""6"""
                    str &= " onblur=""javascript:numChk(this);"" id=""txtFh"" name=""txtFh"" "
                    If Not IsDBNull(rm.Rows(i)("rFhpd")) Then
                        str &= " value=""" & FormatNumber(rm.Rows(i)("rFhpd"), 2) & """ "
                    End If
                    str &= ">"
                    x1.Cells.Add(cC.DataCell(str, "center"))

                    str = "<input type=""text"" class=""SmContent"" size=""25"" maxlength=""200"""
                    str &= " id=""txtRdgCmt"" name=""txtRdgCmt"" value=""" & rm.Rows(i)("rCmt") & """>"
                    x1.Cells.Add(cC.DataCell(str, "center"))

                    str = "<a href=""javascript:updRdg();"">Upd</a>&nbsp; <a href=""javascript:can();"">Can</a>&nbsp;"
                    str &= "<a href=""javascript:delRdg();"">Del</a>"
                    x1.Cells.Add(cC.DataCell(str, "center"))
                Else

                    If IsDBNull(rm.Rows(i)("rDate")) Then
                        x1.Cells.Add(cC.DataCell(""))
                    Else
                        If rm.Rows(i)("rDate") = "1/1/1900" Then
                            x1.Cells.Add(cC.DataCell(""))
                        Else
                            x1.Cells.Add(cC.DataCell(rm.Rows(i)("rDate"), "center"))
                        End If
                    End If

                    x1.Cells.Add(cC.DataCell(rm.Rows(i)("rValue"), "center"))
                    x1.Cells.Add(cC.DataCell(rm.Rows(i)("stat"), "center"))
                    '--------------------------------------------------------------------------------------
                    If IsDBNull(rm.Rows(i)("numDays")) Or CStr(rm.Rows(i)("stat")) = "Exclude" Then
                        x1.Cells.Add(cC.DataCell("", "center"))
                    Else
                        x1.Cells.Add(cC.DataCell(rm.Rows(i)("numDays"), "center"))
                    End If
                    '--------------------------------------------------------------------------------------

                    Dim str2 As String = ""
                    If IsDBNull(rm.Rows(i)("rFhpd")) Or CStr(rm.Rows(i)("stat")) = "Exclude" Then
                        x1.Cells.Add(cC.DataCell("", "center"))
                    Else
                        str = FormatNumber(rm.Rows(i)("rFhpd"), 2)
                        str2 = "(" & rm.Rows(i)("rValue") & " - " & rm.Rows(i)("prevRdg") & ") / " & rm.Rows(i)("numDays") ' 
                        If CStr(rm.Rows(i)("stat")) = "Failed" Then
                            str &= "*"
                            str2 = "Estimate Hours Per Day"
                        End If
                        x1.Cells.Add(cC.DataCell(str, "center", , str2))
                    End If

                    '--------------------------------------------------------------------------------------
                    If Len(rm.Rows(i)("rCmt")) > 30 Then
                        x1.Cells.Add(cC.DataCell(Left(rm.Rows(i)("rCmt"), 27) & "...", "center", , rm.Rows(i)("rCmt")))
                    Else
                        x1.Cells.Add(cC.DataCell(rm.Rows(i)("rCmt"), "center"))
                    End If

                    x1.Cells.Add(cC.DataCell("<a href=""javascript:picMe('" & rm.Rows(i)("meterrdgid") & "');"">Edit</a>", "center"))
                End If

                If altRow = False Then
                    x1.BackColor = System.Drawing.Color.White
                    altRow = True
                Else
                    x1.BackColor = System.Drawing.Color.WhiteSmoke
                    altRow = False
                End If
                tblReadings.Rows.Add(x1)

            Next

        End If

    End Sub

    'builds the column headers for the readings table
    Sub readingsHeader()
        Dim x1 As New TableRow

        x1.Cells.Add(cC.DataCell("Date", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("Reading", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("Status", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("# Days", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("Hrs/Day", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("Comments", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("", "center", , , , "LightSteelBlue"))
        x1.CssClass = "smBContent"
        tblReadings.Rows.Add(x1)
    End Sub

    'creates the add reading link or add reading textboxes
    Sub addRow()
        Dim x1 As New TableRow
        If txtCommand.Value = "addPrep" Then

            str = "<input type=""text"" id=""txtDate"" class=""SmContent"" onblur=""javascript:return(chkDate(this));"" "
            str &= " value=""" & Request.Form("txtDate") & """ size=""10"" maxlength=""10"" name=""txtDate"" >*"
            x1.Cells.Add(cC.DataCell(str, "center"))

            str = "<input type=""text"" id=""txtValue"" name=""txtValue"" class=""SmContent"" size=""8"" "
            str &= " onblur=""javascript:numChk(this);"" value=""" & Request.Form("txtValue") & """  maxlength=""10"">*"
            x1.Cells.Add(cC.DataCell(str, "center"))

            str = "<select name=""selStatus"" id=""selStatus"" class=""SmContent"">"
            Dim stSql As String = " SELECT SVD_Attribute FROM System_Validation_Dictionary "
            stSql &= " WHERE (SVD_Name = 'MeterStatus') ORDER BY SVD_Attribute"
            Dim rh As DataTable = cC.getAsDataTable(stSql, Session("swmsDbConnection"))
            If rh.Rows.Count > 0 Then
                Dim i As Integer
                For i = 0 To rh.Rows.Count - 1
                    str &= "<option value=""" & rh.Rows(i)("SVD_Attribute") & """ "
                    If rh.Rows(i)("SVD_Attribute") = "Pending" Then
                        str &= " selected"
                    End If
                    str &= ">" & rh.Rows(i)("SVD_Attribute") & "</option>"
                Next
            End If
            str &= "</select>"
            x1.Cells.Add(cC.DataCell(str, "center"))

            x1.Cells.Add(cC.DataCell("", "center"))

            str = "<input type=""text"" id=""txtFh"" name=""txtFh"" class=""SmContent"" size=""5"" "
            str &= " onblur=""javascript:numChk(this);"" value=""" & Request.Form("txtFh") & """ maxlength=""6"">"
            x1.Cells.Add(cC.DataCell(str, "center"))

            str = "<input type=""text"" id=""txtRdgCmt"" name=""txtRdgCmt"" class=""SmContent"""
            str &= " value=""" & Request.Form("txtRdgCmt") & """ size=""25"" maxlength=""200"">"
            x1.Cells.Add(cC.DataCell(str, "center"))

            x1.Cells.Add(cC.DataCell("<a href=""javascript:addRdg();"">Add</a>&nbsp;<a href=""javascript:can();"">Can</a>", "center"))

        Else
            x1.Cells.Add(cC.DataCell("<a href=""javascript:addPrep();"">Add New</a>", "center", 7))
        End If

        tblReadings.Rows.Add(x1)
    End Sub

    'adds a new meter reading 
    Sub addRdg()
        sql = "insert into meterReadings "
        sql &= " (MeterId, RdgDate, RdgValue, Status, FailHrsPerDay, Source, Comments)"
        sql &= " values (" & Request.QueryString("id") & ", " ' MeterId
        sql &= "'" & cC.BufStr(Request.Form("txtDate").Trim) & "', " ' RdgDate
        sql &= cC.BufStr(Request.Form("txtValue").Trim) & ", " ' RdgValue
        sql &= "'" & Request.Form("selStatus") & "', " ' status
        If IsNumeric(Request.Form("txtFh")) Then
            sql &= cC.BufStr(Request.Form("txtFh").Trim) & ", " ' ' FailHrsPerDay
        Else
            sql &= "NULL, "  ' ' FailHrsPerDay
        End If
        sql &= "'EditMeters.aspx', " ' Source
        sql &= "'" & cC.BufStr(Left(Request.Form("txtRdgCmt"), 200).Trim) & "')" ' Comments
        cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "AssetTracking\EditMeters.aspx.vb - addRdg()")

        displayMeter(Request.QueryString("id"))
    End Sub

    'updates the selected reading
    Sub updRdg()

        sql = "update meterreadings set"
        sql &= " rdgDate = '" & cC.BufStr(Request.Form("txtDate").Trim) & "',"
        sql &= " rdgvalue = " & cC.BufStr(Request.Form("txtValue").Trim) & ","
        sql &= " Status = '" & cC.BufStr(Request.Form("selStatus").Trim) & "',"
        If CStr(Request.Form("txtFh")) = "" Then
            sql &= " failhrsperday = NULL, "
        Else
            If IsNumeric(Request.Form("txtFh")) Then
                sql &= " failhrsperday = " & cC.BufStr(Request.Form("txtFh").Trim) & ","
            End If
        End If
        sql &= " comments='" & cC.BufStr(Request.Form("txtRdgCmt").Trim) & "'"
        sql &= " where (meterrdgid = " & txtPicked.Value & ")"

        cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "AssetTracking\EditMeters.aspx.vb - updRdg()")

        txtPicked.Value = ""
        displayMeter(Request.QueryString("id"))
    End Sub

    'deletes the seleted mter reading
    Sub delRdg()

        sql = "delete from meterreadings where (meterrdgid = " & txtPicked.Value & ")"
        cC.executeNonQuery(sql, Session("SWMSDBConnection").ToString, Session("SWMSUID").ToString, "AssetTracking\EditMeters.aspx.vb - delRdg()")

        displayMeter(Request.QueryString("id"))
    End Sub

#End Region
End Class
