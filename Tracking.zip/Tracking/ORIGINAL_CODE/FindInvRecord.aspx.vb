﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Tracking_FindInvRecord
    Inherits System.Web.UI.Page

#Region "declarations"
    Dim sql As String = ""
#End Region

#Region "pageLoad"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        SwmsAccess.ValidateSession()

        If Not Page.IsPostBack Then
            loadDdl()
            checkForMemories()
        End If
    End Sub
#End Region

    Sub loadDdl()
        ddlInvType.Items.Clear()
        sql = "select '---' as SVD_Attribute union "
        sql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary  WHERE (SVD_Name = 'InventoryType') ORDER BY SVD_Attribute"
        SwmsUI.LoadDropDown(ddlInvType, sql, Nothing, False, "SVD_Attribute", "SVD_Attribute")
    End Sub

    Private Sub checkForMemories()

        '--- remember what was selected last time I was here

        If SwmsUI.MemoriesIn(New Control() {txtInvDAte, txtInvDesc, ddlInvType}) Then displayInv()


    End Sub

    Sub headerRow()
        Dim x1 As New TableRow

        x1.Cells.Add(SwmsUI.DataCell("Type", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Description", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Date", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Comments", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Id #", "center", , , , "LightSteelBlue"))
        x1.CssClass = "smBContent"
        assetsTab.Rows.Add(x1)
    End Sub

    Sub displayInv()
        headerRow()

        sql = " SELECT AssetInvId, isnull(InventoryType,'') as invType, isnull(InvDescription,'') as invDesc, "
        sql &= "    invDate, isnull(InvComments,'') as invComments "
        sql &= " FROM AssetInventory WHERE (AssetInvId IS NOT NULL) "
        If IsDate(txtInvDAte.Text) Then
            sql &= " AND (InvDate = @InventoryDate)"
        End If
        If txtInvDesc.Text <> "" Then
            sql &= " AND (InvDescription LIKE @InventoryDescription)"
        End If
        If ddlInvType.SelectedValue <> "---" Then
            sql &= " AND (InventoryType = @InventoryType)"
        End If
        sql &= "ORDER BY InvDate DESC"

        Dim rs As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, New SqlParameter() {
            New SqlParameter("@InventoryDate", Server.HtmlEncode(txtInvDAte.Text)),
            New SqlParameter("@InventoryDescription", Server.HtmlEncode(txtInvDesc.Text) & "%"),
            New SqlParameter("@InventoryType", ddlInvType.SelectedValue)
        })


        If rs.Rows.Count > 0 Then
            Dim altRow As Boolean = False
            Dim i As Integer
            For i = 0 To rs.Rows.Count - 1
                Dim x1 As New TableRow

                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("invType"), "center"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("invDesc"), "left"))
                If IsDate(rs.Rows(i)("invDate")) Then
                    If CStr(rs.Rows(i)("invDate")) <> "1/1/1900" Then
                        x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("invDate"), "center"))
                    Else
                        x1.Cells.Add(SwmsUI.DataCell("", "center"))
                    End If
                Else
                    x1.Cells.Add(SwmsUI.DataCell("", "center"))
                End If

                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("invComments"), "left"))

                Dim str As String = "<a href=""javascript:picMe(" & rs.Rows(i)("AssetInvId") & ");"">" & rs.Rows(i)("AssetInvId") & "</a>"
                x1.Cells.Add(SwmsUI.DataCell(str, "center"))

                assetsTab.Rows.Add(x1)
                If altRow = True Then
                    x1.BackColor = System.Drawing.Color.WhiteSmoke
                    altRow = False
                Else
                    altRow = True
                End If
                If rs.Rows(i)("AssetInvId") = Session("AssetInvId") Then
                    x1.BackColor = System.Drawing.Color.PaleGreen
                End If

                x1.Attributes.Add("cursor", "hand")
                x1.Attributes.Add("onClick", "picMe(" & rs.Rows(i)("AssetInvId") & ");")
            Next
        End If


    End Sub

    Protected Sub btnFind_Click(sender As Object, e As System.EventArgs) Handles btnFind.Click

        '--- clear existing memories
        SwmsUI.MemoriesOut(New Control() {txtInvDAte, txtInvDesc, ddlInvType})

        displayInv()
    End Sub

    Protected Sub btnNew_Click(sender As Object, e As System.EventArgs) Handles btnNew.Click
        Response.Redirect("RecordAssetInv.aspx")
    End Sub
End Class
