﻿Imports System.Data
Partial Class Tracking_EditAsset
    Inherits System.Web.UI.Page

#Region "declarations"
    Dim cC As New commonClass
    Dim sql As String = ""
    Dim str As String
#End Region

#Region "pageLoad"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
        If msg <> "" Then
            Response.Redirect(msg)
        End If

        If Request.QueryString("inv") <> "" Then
            lnkInv.Text = "Return to Inventory"
            lnkInv.NavigateUrl = "RecordAssetInv.aspx?id=" & Request.QueryString("inv")
            lnkInv.Visible = True
        Else
            lnkInv.Visible = False
        End If

        If CStr(Request.QueryString("id")) <> "" Then
            lnkRet.NavigateUrl = "FindAssets.aspx?id=" & Request.QueryString("id")
        Else
            lnkRet.NavigateUrl = "FindAssets.aspx"
        End If

        If Not Page.IsPostBack Then ' NEW Page
            fillDdls()
            If CStr(Request.QueryString("id")) <> "" Then ' an asset is selected for edit
                displayAsset(Request.QueryString("id"))
                btnUPd.Visible = True
                btnUpdAsset.Visible = True
                lblRecBy2.Visible = True
                lblRecDate2.Visible = True
                historyPanel.Visible = True
                showHideDeleteButton()
            Else ' form is blank for adding a new asst
                If Request.QueryString("sn") <> "" Then
                    txtSn.Text = Request.QueryString("sn")
                End If
                modFromPanel.Visible = False
                historyPanel.Visible = False
                btnDel.Visible = False
                btnHist.Visible = False
                btnUPd.Visible = False
                btnUpdAsset.Visible = False
                lblUpdBy2.Visible = False
                lblRecBy2.Visible = False
                lblRecDate2.Visible = False
            End If
        Else ' this is the postback routine
            If CStr(Request.QueryString("id")) <> "" Then
                historyPanel.Visible = True
            End If
            Select Case txtCommand.Value
                Case "add" ' adds new asset record
                    validLocations("add") 'addNew()
                Case "vnd" ' a new vendor was created
                    fillDdls()
                    If CStr(Request.QueryString("id")) <> "" Then
                        displayAsset(Request.QueryString("id"))
                    End If
                    selectNewVendor()
                Case "upd" ' the update button was clicked 
                    validLocations("upd") ' updAsset()
                Case "updAO"
                    updAssetOnly()
                Case "del" ' the delete button was clicked
                    deleteAsset()
                Case Else '
            End Select
            txtCommand.Value = ""
            showHideDeleteButton()
        End If

        If Request.QueryString("mtr") <> "" Then
            lnkMtr.Text = "Return to Meters"
            lnkMtr.NavigateUrl = "EditMeters.aspx?id=" & Request.QueryString("mtr") & "&aid=" & Request.QueryString("id")
            lnkMtr.NavigateUrl &= "&sn=" & Request.QueryString("sn") '& "&loc=" & txtLoc.Text
            lnkMtr.Visible = True
        Else
            lnkMtr.Visible = False
        End If

    End Sub
#End Region

#Region " fillDdls "
    Sub fillDdls()

        ' pin -------------------------------
        ddlPin.Items.Clear()
        Dim pinSql As String = "SELECT '---' as TPMCode union all "
        pinSql &= " select TPMCode from TPM where (TPMCode Is Not null) order by TPMCode"
        ddlPin.DataSource = cC.getAsDataTable(pinSql, Session("swmsDbConnection"))
        ddlPin.DataValueField = "TPMCode"
        ddlPin.DataTextField = "TPMCode"
        ddlPin.DataBind()

        ' condition code --------------------------------------------
        ddlCc.Items.Clear()
        Dim ccSql As String = " Select '-' as SVD_Attribute UNION ALL "
        ccSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        ccSql &= " WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute"
        ddlCc.DataSource = cC.getAsDataTable(ccSql, Session("swmsDbConnection"))
        ddlCc.DataValueField = "SVD_Attribute"
        ddlCc.DataTextField = "SVD_Attribute"
        ddlCc.DataBind()

        'procurement code -------------------------------------
        ddlPc.Items.Clear()
        Dim pcSql As String = "SELECT '0' as ProcCd, '---' as descr UNION ALL "
        pcSql &= " SELECT ProcCd, ProcCd + ' - ' + isnull(ProcDesc,'') as descr "
        pcSql &= " FROM ProcMakeBuyCodes ORDER BY ProcCd"
        ddlPc.DataSource = cC.getAsDataTable(pcSql, Session("swmsDbConnection"))
        ddlPc.DataValueField = "ProcCd"
        ddlPc.DataTextField = "descr"
        ddlPc.DataBind()

        'ilsmis controlling number -------------------------------------
        ddlIlsCont.Items.Clear()
        Dim iSql As String = " Select '-' as SVD_Attribute UNION ALL "
        iSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        iSql &= " WHERE (SVD_Name = 'ILSMIS_Control') ORDER BY SVD_Attribute"
        ddlIlsCont.DataSource = cC.getAsDataTable(iSql, Session("swmsDbConnection"))
        ddlIlsCont.DataValueField = "SVD_Attribute"
        ddlIlsCont.DataTextField = "SVD_Attribute"
        ddlIlsCont.DataBind()

        ''reason -------------------------------------
        ddlReason.Items.Clear()
        Dim rSql As String = " Select '---' as SVD_Attribute UNION ALL "
        rSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        rSql &= " WHERE (SVD_Name = 'AssetReason') ORDER BY SVD_Attribute"
        ddlReason.DataSource = cC.getAsDataTable(rSql, Session("swmsDbConnection"))
        ddlReason.DataValueField = "SVD_Attribute"
        ddlReason.DataTextField = "SVD_Attribute"
        ddlReason.DataBind()

        'intended use -------------------------------------
        ddlIntUse.Items.Clear()
        Dim intSql As String = " Select '---' as SVD_Attribute UNION ALL "
        intSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        intSql &= " WHERE (SVD_Name = 'IntendedUse') ORDER BY SVD_Attribute"
        ddlIntUse.DataSource = cC.getAsDataTable(intSql, Session("swmsDbConnection"))
        ddlIntUse.DataValueField = "SVD_Attribute"
        ddlIntUse.DataTextField = "SVD_Attribute"
        ddlIntUse.DataBind()

        'asset stauts -------------------------------------
        ddlStatus.Items.Clear()
        Dim stSql As String = " Select '---' as SVD_Attribute UNION ALL "
        stSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        stSql &= " WHERE (SVD_Name = 'AssetHistoryStatus') ORDER BY SVD_Attribute"
        ddlStatus.DataSource = cC.getAsDataTable(stSql, Session("swmsDbConnection"))
        ddlStatus.DataValueField = "SVD_Attribute"
        ddlStatus.DataTextField = "SVD_Attribute"
        ddlStatus.DataBind()

        'vendor code -------------------------------------
        ddlVnd.Items.Clear()
        Dim vSql As String = "SELECT 0 as VendorId, '---' as [Name] UNION ALL"
        vSql &= " select VendorId, [Name] from vendors order by [Name]"
        ddlVnd.DataSource = cC.getAsDataTable(vSql, Session("swmsDbConnection"))
        ddlVnd.DataValueField = "VendorId"
        ddlVnd.DataTextField = "Name"
        ddlVnd.DataBind()

    End Sub
#End Region 'fill the dropdown lists (except for locations)

#Region " displayAsset "
    Sub displayAsset(ByVal AId As String)
        Session("AId") = AId

        If CStr(AId) = "" Then
            Response.Redirect("FindAssets.aspx")
        Else
            sql = "SELECT AssetId, ats.PID, BSSId, isnull(pm.PartNumber,'') as pn, "
            sql &= "    isnull(pm.Nomenclature,'') as nomen, isnull(IntendedUse,'') as intUse, "
            sql &= "    isnull(pm2.Partnumber,'') as modFromPn, isnull(pm2.Niin,'') as modFromNiin,"
            sql &= "    isnull(ats.ModelNumber,'') as model, isnull(pm.NIIN,'') as niin, isnull(SerialNumber,'') as sn, "
            sql &= "    AcceptanceDate as accDate, WarrantyBeginDate as warDate, isnull(ats.VendorId,0) as vendorId,"
            sql &= "    isnull(Manufacturer,'') as manu,  isnull(InILSMIS,0) as inIls, isnull(ats.pin,'') as pin, "
            sql &= "    DateRecorded as recDate,  isnull(Modified, DateRecorded) as modDate, "
            sql &= "    isnull(pp2.LastName, '') + ', ' + isnull(pp2.FirstName,'') as recBy "
            sql &= " FROM Assets ats inner join partsmaster pm on ats.pid = pm.pid "
            sql &= "    LEFT OUTER JOIN People pp2 on ats.RecordedBy = pp2.PeopleId"
            sql &= "    LEFT OUTER JOIN partsmaster pm2 on ats.modfrompid = pm2.pid"
            sql &= " WHERE (AssetId = " & AId & ")"

            Dim rs As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
            If rs.Rows.Count > 0 Then

                lblpn.Text = rs.Rows(0)("pn")
                lblAId.Text = rs.Rows(0)("AssetId")
                lblNomen.Text = rs.Rows(0)("nomen")
                lblNiin.Text = rs.Rows(0)("niin")
                lblRecBy.Text = rs.Rows(0)("recBy")
                If Not IsDBNull(rs.Rows(0)("recDate")) Then
                    If CStr(rs.Rows(0)("recDate")) <> "1/1/1900" Then
                        lblRecDate.Text = FormatDateTime(rs.Rows(0)("recDate"), 2)
                    End If
                End If

                If Not IsDBNull(rs.Rows(0)("accDate")) Then
                    If CStr(rs.Rows(0)("accDate")) <> "1/1/1900" Then
                        txtAccDate.Text = rs.Rows(0)("accDate")
                    End If
                End If

                If Not IsDBNull(rs.Rows(0)("warDate")) Then
                    If CStr(rs.Rows(0)("warDate")) <> "1/1/1900" Then
                        txtWarDate.Text = FormatDateTime(rs.Rows(0)("warDate"), 2)
                    End If
                End If

                Try
                    ddlVnd.SelectedValue = rs.Rows(0)("vendorId") ' rdr("vendorId")
                Catch ex As Exception
                End Try
                If rs.Rows(0)("modFromPn") <> "" Then  ' rdr("modFromPn")
                    modFromPanel.Visible = True
                    lblModFromPn.Text = rs.Rows(0)("modFromPn") ' rdr("modFromPn")
                    lblModFromNiin.Text = rs.Rows(0)("modFromNiin") ' rdr("modFromNiin")
                Else
                    modFromPanel.Visible = False
                End If
                txtPid.Text = rs.Rows(0)("PID") ' rdr("PID")
                Try
                    ddlPin.SelectedValue = rs.Rows(0)("pin") ' rdr("pin")
                Catch ex As Exception
                End Try
                txtManu.Text = rs.Rows(0)("manu")  ' rdr("manu")
                txtPn.Visible = False
                btnPart.Visible = False
                btnAdd.Visible = False
                txtSn.Text = rs.Rows(0)("sn") ' rdr("sn")
                txtModel.Text = rs.Rows(0)("model") ' rdr("model")
                Try
                    ddlIntUse.SelectedValue = rs.Rows(0)("intUse") ' rdr("intUse")
                Catch ex As Exception
                End Try
                If CStr(rs.Rows(0)("inIls")) = "1" Then ' rdr("inIls")
                    chkIls.Checked = True
                Else
                    chkIls.Checked = False
                End If

            End If

            '**************************************************************
            '----- show hyplerinks to this assets' meters -------------
            lblMtrLnk.Text = ""
            Dim mSql As String = "SELECT MeterId FROM Meters WHERE (AssetId = " & AId & ")"
            Dim rm As DataTable = cC.getAsDataTable(mSql, Session("swmsDbConnection"))
            If rm.Rows.Count > 0 Then
                Dim i As Integer
                For i = 0 To rm.Rows.Count - 1
                    lblMtrLnk.Text &= "<a href=""EditMeters.aspx?id=" & rm.Rows(i)("MeterId") & """>" & rm.Rows(i)("MeterId") & "</a>&nbsp;"
                Next
            End If
            Select Case rm.Rows.Count
                Case 0
                    lblMeters.Visible = False
                Case 1
                    lblMeters.Visible = True
                Case Else
                    lblMeters.Visible = True
                    lblMeters.Text = "Meters:"
            End Select
            ' ----------- end meter stuff -------------------------
            '**************************************************************

            Dim locId As Integer = 0
            Dim hSql As String = "SELECT TOP (1) AssetHistoryId, isnull(ah.ConditionCode,'') as cc, "
            hSql &= "   isnull(ah.ProcurementCode,'') as pc, isnull(ah.PurposeCode,'') as purp, "
            hSql &= "   isnull(ah.Status,'') as stat, isnull(ah.ReworkNumber,'') as rwk, "
            hSql &= "   isnull(ah.LocationId,0) as loc, isnull(ah.ILSMISControlNumber,'') as ils, "
            hSql &= "   isnull(MaintDocNumber,'') as maintDoc, EffectiveDate as effDate,"
            hSql &= "   isnull(ah.DocumentNumber,'') as docNum, isnull(ah.Remarks,'') as remarks, "
            hSql &= "   isnull(ah.Reason,'') as reason, TransDate as transDate, "
            hSql &= "   isnull(pp.LastName, '') + ', ' + isnull(pp.FirstName,'') as modBy, "
            hSql &= "   isnull(loc1.LocationIdcode,' - ') + ' - ' + isnull(loc2.LocationIdcode,'') "
            hSql &= "       + ' - ' + isnull(loc3.LocationIdcode,'') + ' - ' + isnull(loc4.LocationIdcode,'') as locName"
            hSql &= " FROM AssetHistory ah"
            hSql &= "    LEFT OUTER JOIN People pp on ah.TransBy = pp.PeopleId"
            hSql &= "    left outer join locations loc1 on ah.LocationId = loc1.LocationId"
            hSql &= "    left outer join locations loc2 on ah.Location2 = loc2.LocationId"
            hSql &= "    left outer join locations loc3 on ah.Location3 = loc3.LocationId"
            hSql &= "    left outer join locations loc4 on ah.Location4 = loc4.LocationId"
            hSql &= " WHERE (ah.AssetId = " & AId & ") ORDER BY ah.TransDate DESC, assethistoryid desc"
            Dim rf As DataTable = cC.getAsDataTable(hSql, Session("swmsDbConnection"))

            If rf.Rows.Count > 0 Then

                lblLoc.Text = rf.Rows(0)("locName")
                lblCc.Text = rf.Rows(0)("cc")
                lblProcCd.Text = rf.Rows(0)("pc")
                lblPurpCd.Text = UCase(rf.Rows(0)("purp"))
                lblStatus.Text = rf.Rows(0)("stat")
                lblIlsCntrl.Text = rf.Rows(0)("ils")
                lblDocNum.Text = rf.Rows(0)("docNum")
                lblRemarks.Text = rf.Rows(0)("remarks")
                lblRwkNum.Text = rf.Rows(0)("rwk")
                txtPurp.Text = UCase(rf.Rows(0)("purp"))
                If Not IsDBNull(rf.Rows(0)("effDate")) Then
                    If CStr(rf.Rows(0)("effDate")) <> "1/1/1900" Then
                        lblEffDate.Text = rf.Rows(0)("effDate")
                    End If
                End If
                lblMaintDocNum.Text = rf.Rows(0)("maintDoc")
                txtAHId.Text = rf.Rows(0)("AssetHistoryId")
                lblReason.Text = rf.Rows(0)("reason")

                lblUpdBy2.Visible = True
                lblUpdby.Text = rf.Rows(0)("modBy")
                If Not IsDBNull(CStr(rf.Rows(0)("transDate"))) Then
                    If CStr(rf.Rows(0)("transDate")) <> "1/1/1900" Then
                        lblHistoryDate.Text = FormatDateTime(rf.Rows(0)("transDate"), 2)
                    End If
                End If

            Else
                txtAHId.Text = 0
                lblUpdBy2.Visible = False
            End If
            showShopOrders(AId)
        End If

    End Sub
#End Region  'displays the selected asset record

#Region " showHideDeleteButton "
    Sub showHideDeleteButton()

        sql = "select count(*) as allow from SWMSSecurity.dbo.PeopleFunctionClasses pfc  "
        sql &= " where  (functionclassid in (99,98)) and peopleid = " & Session("SWMSUId")

        Dim rp As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))

        If rp.Rows.Count > 0 Then
            btnDel.Visible = True
        Else
            btnDel.Visible = False
        End If

    End Sub
#End Region

#Region " validLocations "
    Sub validLocations(ByVal action As String)
        '---validate the locations
        UsrMsg.Value = ""

        Dim loc1 As Integer = 0, loc2 As Integer = 0
        Dim loc3 As Integer = 0, loc4 As Integer = 0

        '---1st level - super
        If CStr(Request.Form("txtLoc1").Trim) <> "" Then
            Dim sql1 As String = "select top 1 LocationId from locations"
            sql1 &= " where (locationlevel = 1)"
            sql1 &= " and (locationidcode = '" & cC.BufStr(txtLoc1.Text.Trim) & "')"
            sql1 &= " order by locationid"
            Dim rl1 As DataTable = cC.getAsDataTable(sql1, Session("swmsDbConnection"))
            If rl1.Rows.Count > 0 Then ' its a match
                loc1 = rl1.Rows(0)("locationid")
            Else
                UsrMsg.Value &= "Super location '" & cC.BufStr(txtLoc1.Text.Trim) & "' not found "
            End If
        End If

        '---2nd level - location
        If CStr(Request.Form("txtLoc2").Trim) <> "" Then
            Dim sql2 As String = "select top 1 locationid, "
            sql2 &= " parentlocationid from locations"
            sql2 &= " where (locationidcode = '" & cC.BufStr(txtLoc2.Text.Trim) & "')"
            sql2 &= " and (locationlevel = 2)"
            If loc1 <> 0 Then
                sql2 &= " and (parentlocationid = " & loc1 & ")" '--------------------
            End If
            sql2 &= " order by locationid"
            Dim rl2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
            If rl2.Rows.Count > 0 Then ' its a match
                loc2 = rl2.Rows(0)("locationid")
                loc1 = rl2.Rows(0)("parentlocationid")
            Else
                UsrMsg.Value &= "Location '" & cC.BufStr(txtLoc2.Text.Trim) & "' not found "
            End If
        End If

        '---3rd level - sub
        If CStr(Request.Form("txtLoc3").Trim) <> "" Then
            Dim sql3 As String = " select  top 1 locationid, parentlocationid, "
            sql3 &= " isnull((select parentlocationid from locations "
            sql3 &= "   where locationid = loc.parentlocationid),0) as grandLocationid "
            sql3 &= " from locations loc"
            sql3 &= " where (locationidcode = '" & cC.BufStr(txtLoc3.Text.Trim) & "')"
            sql3 &= " and (locationlevel = 3)"
            If loc2 <> 0 Then
                sql3 &= " and (parentlocationid = " & loc2 & ")" '--------------------
            End If
            sql3 &= " order by locationid"
            Dim rl3 As DataTable = cC.getAsDataTable(sql3, Session("swmsDbConnection"))
            If rl3.Rows.Count > 0 Then ' its a match
                loc3 = rl3.Rows(0)("locationid")
                loc2 = rl3.Rows(0)("parentlocationid")
                loc1 = rl3.Rows(0)("grandLocationid")
            Else
                UsrMsg.Value &= "Sub Location '" & cC.BufStr(txtLoc3.Text.Trim) & "' not found "
            End If
        End If

        '---4th level - micro
        If CStr(Request.Form("txtLoc4").Trim) <> "" Then
            Dim sql4 As String = " select top 1 locationid, parentlocationid, "
            sql4 &= " isnull((select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid),0) as grandLocationid, "
            sql4 &= " isnull((select parentlocationid from locations"
            sql4 &= "   where locationid = (select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid)),0) as greatlocationid"
            sql4 &= "  from locations loc"
            sql4 &= " where (locationidcode = '" & cC.BufStr(txtLoc4.Text.Trim) & "')"
            sql4 &= " and (locationlevel = 4)"
            If loc3 <> 0 Then
                sql4 &= " and (parentlocationid = " & loc3 & ")" '--------------------
            End If
            sql4 &= " order by locationid"
            Dim rl4 As DataTable = cC.getAsDataTable(sql4, Session("swmsDbConnection"))
            If rl4.Rows.Count > 0 Then ' its a match
                loc4 = rl4.Rows(0)("locationid")
                loc3 = rl4.Rows(0)("parentlocationid")
                loc2 = rl4.Rows(0)("grandlocationid")
                loc1 = rl4.Rows(0)("greatlocationid")
            Else
                UsrMsg.Value &= "Micro Location '" & cC.BufStr(txtLoc4.Text.Trim) & "' not found"
            End If
        End If

        If UsrMsg.Value = "" Then
            If action = "add" Then
                addNew(loc1, loc2, loc3, loc4)
            End If
            If action = "upd" Then
                updAsset(loc1, loc2, loc3, loc4)
            End If
        Else
        End If
    End Sub
#End Region

#Region " showShopOrders "
    Sub showShopOrders(ByVal AId As String)

        sql = "select sonum from shoporders where assetid = " & AId
        sql &= " union select shoporder from bssdata where assetid = " & AId
        sql &= " ORDER BY sonum DESC "

        Dim so As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))


        If so.Rows.Count > 0 Then

            lblShopOrders.Visible = True
            If so.Rows.Count = 1 Then
                lblShopOrders.Text = "Shop Order:"
            Else
                lblShopOrders.Text = "Shop Orders:"
            End If
            Dim i As Integer
            For i = 0 To so.Rows.Count - 1

                Dim x1 As New TableRow
                str = "<a href='javascript:ShoSO(" & so.Rows(i)("SONum") & ");' title='Click to View Shop Order.'>" & so.Rows(i)("SONum") & "</a>"
                x1.Cells.Add(cC.DataCell(Str, "center"))
                Table1.Rows.Add(x1)

            Next
        End If

    End Sub
#End Region

#Region " selectNewVendor "

    Sub selectNewVendor()
      
        sql = "select max(VendorId) as maxid from vendors "
        Dim rv As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
        If rv.Rows.Count > 0 Then
            Try
                ddlVnd.SelectedValue = rv.Rows(0)("maxid")
            Catch ex As Exception
            End Try
        End If

    End Sub
#End Region ' selects the newly added vendor from the drop down

#Region " updAssetOnly "
    Sub updAssetOnly()
        
        Dim luSql As String = "select assetid from assets where pid = " & txtPid.Text
        luSql &= " and (serialnumber = '" & cC.BufStr(txtSn.Text.Trim) & "') "
        luSql &= " and (assetid <> " & Request.QueryString("id") & ")"
        Dim ru As DataTable = cC.getAsDataTable(luSql, Session("swmsDbConnection"))
        If ru.Rows.Count > 0 Then
            UsrMsg.Value = "Serial # " & txtSn.Text & " for Part # " & txtPn.Text & " already exists in SWMS"
        End If

        If UsrMsg.Value = "" Then
            Dim commaFirst As String = ""
            'lookup up the asset to compare changes
            Dim aSql As String = "select isnull(serialnumber,'') as sn, isnull(modelnumber,'') as model, "
            aSql &= "   isnull(vendorid,0) as vndId, isnull(intendeduse,'') as intUse,  "
            aSql &= "   isnull(InILSMIS,0) as inIls,acceptancedate as accDate, "
            aSql &= "   isnull(Manufacturer,'') as manu, isnull(pin,'') as pin, "
            aSql &= "   warrantybegindate  as warDate"
            aSql &= " from assets where assetid = " & Request.QueryString("id")
            Dim ra As DataTable = cC.getAsDataTable(aSql, Session("swmsDbConnection"))
            If ra.Rows.Count > 0 Then
                Dim uSql As String = "UPDATE Assets SET"
                If ra.Rows(0)("sn") <> cC.BufStr(txtSn.Text.Trim) Then
                    uSql &= " SerialNumber = '" & cC.BufStr(txtSn.Text.Trim) & "'"
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If ra.Rows(0)("model") <> cC.BufStr(txtModel.Text.Trim) Then
                    uSql &= commaFirst & " ModelNumber = '" & cC.BufStr(txtModel.Text.Trim) & "'"
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If CStr(ra.Rows(0)("vndId")) <> CStr(Request.Form("ddlVnd")) Then ' ddlVnd.SelectedValue
                    uSql &= commaFirst & " VendorId = " & CStr(Request.Form("ddlVnd")) & " "
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If ra.Rows(0)("pin") <> CStr(Request.Form("ddlPin")) Then ' ddlPin.SelectedValue
                    uSql &= commaFirst & " PIN = '" & CStr(Request.Form("ddlPin")) & "' "
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If ra.Rows(0)("manu") <> cC.BufStr(txtManu.Text.Trim) Then
                    uSql &= commaFirst & " Manufacturer = '" & cC.BufStr(txtManu.Text.Trim) & "' "
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If ra.Rows(0)("intUse") <> CStr(Request.Form("ddlIntUse")) Then ' ddlIntUse.SelectedValue
                    uSql &= commaFirst & " intendeduse = '" & CStr(Request.Form("ddlIntUse")) & "'"
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                Dim inIls As String = "0"
                If chkIls.Checked = True Then
                    inIls = "1"
                End If
                If CStr(ra.Rows(0)("inIls")) <> inIls Then
                    uSql &= commaFirst & " InILSMIS = " & inIls & " "
                    commaFirst = ", "
                End If
                '-------------------------------------------------------
                If IsDate(txtAccDate.Text) Then
                    If IsDBNull(ra.Rows(0)("accDate")) Then
                        uSql &= commaFirst & " AcceptanceDate = '" & cC.BufStr(txtAccDate.Text.Trim) & "'"
                        commaFirst = ", "
                    Else
                        If CStr(ra.Rows(0)("accDate")) <> CStr(txtAccDate.Text.Trim) Then
                            uSql &= commaFirst & " AcceptanceDate = '" & cC.BufStr(txtAccDate.Text.Trim) & "'"
                            commaFirst = ", "
                        End If
                    End If
                End If

                '-------------------------------------------------------
                If IsDate(txtWarDate.Text) Then
                    If IsDBNull(ra.Rows(0)("warDate")) Then
                        uSql &= commaFirst & " warrantybegindate = '" & cC.BufStr(txtWarDate.Text.Trim) & "'"
                        commaFirst = ", "
                    Else
                        If CStr(ra.Rows(0)("warDate")) <> CStr(txtAccDate.Text.Trim) Then
                            uSql &= commaFirst & " warrantybegindate = '" & cC.BufStr(txtWarDate.Text.Trim) & "'"
                            commaFirst = ", "
                        End If
                    End If
                End If

                uSql &= " WHERE (AssetId = " & Request.QueryString("id") & ")"
                '-------------------------------------------------------
                If commaFirst <> "" Then
                    cC.executeNonQuery(uSql, Session("swmsDbConnection"))
                    cC.LogIt("assets", "Assets: part #: " & lblpn.Text & " S/N: " & txtSn.Text & " updated ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))
                End If
            End If

            If txtCommand.Value = "updAO" Then
                Dim newPage As String = "EditAsset.aspx?id=" & Request.QueryString("id")
                If Request.QueryString("inv") <> "" Then
                    newPage &= "&inv=" & Request.QueryString("inv")
                End If
                Response.Redirect(newPage)
            End If

        End If
    End Sub
#End Region

#Region " deleteAsset "
    Sub deleteAsset()
        
        If txtNewAssetId.Text = "" Then 'if new assetid was NOT entered,
            'delete
            sql = "DELETE FROM Assets where assetid = " & Request.QueryString("id")
            cC.executeNonQuery(sql, Session("swmsDbConnection"))

            sql = "DELETE FROM Assethistory where assetid = " & Request.QueryString("id")
            cC.executeNonQuery(sql, Session("swmsDbConnection"))

            Response.Redirect("FindAssets.aspx")
        Else
            If Not IsNumeric(txtNewAssetId.Text) Then
                UsrMsg.Value = "New AssetId must be numeric (" & txtNewAssetId.Text & ")"
            Else
                'insert assethistory record for what we are about to do
                '------------- per Glenda ------------------
                'When inserting “asset history moved” record, 
                'copy all asset history data elements (cc, purp, ect) 
                'from maximum assethistoryid record of the asset being moved to (new assetId)
                Dim sqli As String = "insert into assethistory "
                sqli &= " (assetid, assetinvid, conditioncode, transdate, transby, remarks,"
                sqli &= " reason, documentnumber, ilsmiscontrolnumber, locationid, "
                sqli &= " location2, location3, location4, status, purposecode, procurementcode,"
                sqli &= " MaintDocNumber, EffectiveDate )"

                sqli &= " select top 1 assetid, assetinvid, conditioncode, getdate(),"
                sqli &= Session("SWMSUId") & " as transby, "
                sqli &= " 'asset history moved to " & txtNewAssetId.Text & "' as remarks, "
                sqli &= " reason, documentnumber, ilsmiscontrolnumber,"
                sqli &= " locationid, location2, location3, location4, status, "
                sqli &= " purposecode, procurementcode, MaintDocNumber, EffectiveDate "
                sqli &= " from assethistory where(assetid = " & txtNewAssetId.Text & ")"
                sqli &= " ORDER BY transdate DESC "
                cC.executeNonQuery(sqli, Session("swmsDbConnection"))

                '-------------------- per Glenda ------------------------------
                'provide option to overwrite asset data elements from deleted asset to new asset
                If Request.Form("chkOvw") = "on" Then
                    Dim updSql As String = "UPDATE Assets SET"
                    If IsDate(txtAccDate.Text) Then
                        updSql &= " AcceptanceDate = '" & cC.BufStr(txtAccDate.Text.Trim) & "', "
                    End If
                    updSql &= " PIN = '" & Request.Form("ddlPin") & "', "
                    updSql &= " VendorId = " & Request.Form("ddlVnd") & ", "
                    If IsDate(txtWarDate.Text) Then
                        updSql &= " WarrantyBeginDate = '" & cC.BufStr(txtWarDate.Text.Trim) & "', "
                    End If
                    updSql &= " IntendedUse = '" & Request.Form("ddlIntUse") & "', "
                    updSql &= " Manufacturer = '" & cC.BufStr(txtManu.Text.Trim) & "', "
                    If chkIls.Checked = True Then
                        updSql &= " InILSMIS = 1 "
                    Else
                        updSql &= " InILSMIS = NULL "
                    End If
                    updSql &= " WHERE AssetId = " & txtNewAssetId.Text
                    cC.executeNonQuery(updSql, Session("swmsDbConnection"))
                End If

                'update oldassetid to aid to current assetid
                sql = "update assethistory set "
                sql &= " assetid = " & txtNewAssetId.Text & ","
                sql &= " oldassetid = " & Request.QueryString("id")
                sql &= " where (assetid = " & Request.QueryString("id") & ")"
                cC.executeNonQuery(sql, Session("swmsDbConnection"))

                'then delete asset
                sql = "DELETE FROM Assets where assetid = " & Request.QueryString("id")
                cC.executeNonQuery(sql, Session("swmsDbConnection"))

                'then redirect to new assetid
                Dim newPage As String = "EditAsset.aspx?id=" & txtNewAssetId.Text
                If Request.QueryString("inv") <> "" Then
                    newPage &= "&inv=" & Request.QueryString("inv")
                End If
                Response.Redirect(newPage)
            End If
        End If

    End Sub
#End Region

#Region " addNew "

    Sub addNew(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)
        UsrMsg.Value = ""

        'check for pid
        If CStr(txtPid.Text) = "" Then
            sql = " SELECT TOP 1 PId FROM PartsMaster WHERE (PartNumber = '" & cC.BufStr(txtPn.Text.Trim) & "') ORDER BY PId "
            Dim rp As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
            If rp.Rows.Count > 0 Then
                txtPid.Text = rp.Rows(0)("PId")
            Else
                UsrMsg.Value = "Part # " & txtPn.Text & " does not exist in SWMS" & Chr(13)
            End If
        End If

        'check fro serial
        If CStr(txtSn.Text) = "" Then
            UsrMsg.Value &= "Serial # Required" & Chr(13)
        End If

        If UsrMsg.Value <> "" Then
            'Response.Redirect(Request.ServerVariables("HTTP_REFERER"))
            'Response.Redirect(Request.RawUrl)
            'Response.Write("<script language=javascript> history.back(-1); </script>")
        Else
            If CStr(txtPid.Text) <> "" Then
                'check if asset already exists first!!!!
                sql = "SELECT AssetId from Assets  WHERE (pid = " & txtPid.Text & ") "
                sql &= " AND (serialnumber = '" & cC.BufStr(txtSn.Text.Trim) & "')"
                Dim rq As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
                If rq.Rows.Count > 0 Then
                    UsrMsg.Value &= "Part # " & txtPn.Text & Chr(13)
                    UsrMsg.Value &= "Serial # " & txtSn.Text & " already exists" & Chr(13)
                Else
                    'insert into assets --------------

                    Dim unifiedDate As Date = Date.Today
                    sql = "INSERT INTO Assets (Pid, SerialNumber, ModelNumber, AcceptanceDate, PIN, "
                    sql &= " WarrantyBeginDate, IntendedUse, VendorId, Manufacturer, InILSMIS, DateRecorded, RecordedBy)"
                    sql &= " Values (" & txtPid.Text & ", " '--Pid, "
                    sql &= " '" & cC.BufStr(txtSn.Text.Trim) & "', " '--SerialNumber, "
                    sql &= " '" & cC.BufStr(txtModel.Text.Trim) & "', " '--ModelNumber, "
                    If Not IsDate(txtAccDate.Text) Then
                        sql &= " NULL, " '--AcceptanceDate,"
                    Else
                        sql &= " '" & cC.BufStr(txtAccDate.Text.Trim) & "', " '--AcceptanceDate,"
                    End If
                    If Request.Form("ddlPin") = "---" Then
                        sql &= " NULL, " '--pin,"
                    Else
                        sql &= " '" & Request.Form("ddlPin") & "', " '--pin,"
                    End If
                    If Not IsDate(txtWarDate.Text) Then
                        sql &= " NULL, " '--WarrantyBeginDate, "
                    Else
                        sql &= " '" & cC.BufStr(txtWarDate.Text.Trim) & "', " '--WarrantyBeginDate, "
                    End If
                    sql &= " '" & Request.Form("ddlIntUse") & "', " '--IntendedUse, "
                    sql &= Request.Form("ddlVnd") & ", " ' --VendorId, "
                    sql &= " '" & cC.BufStr(txtManu.Text.Trim) & "', " '--Manufacturer, "
                    If chkIls.Checked = True Then
                        sql &= " 1, " ' --InILSMIS, "
                    Else
                        sql &= " 0, " ' --InILSMIS, "
                    End If
                    sql &= " '" & unifiedDate & "', " '  --DateRecorded,"
                    sql &= Session("SWMSUId") & ") " ' --RecordedBy)"
                    sql &= " SELECT SCOPE_IDENTITY() "

                    'get the new asset id --------------
                    Dim newId As Integer = 0
                    Dim dfId As DataTable = cC.getAsDataTable(sql, Session("SWMSDBConnection").ToString, , Session("SWMSUID"))
                    If dfId.Rows.Count > 0 Then
                        newId = dfId.Rows(0).Item(0)
                    End If
                    
                    ' insert into asset history --------------
                    Dim hSql As String = " INSERT INTO AssetHistory (AssetId, "
                    hSql &= " ConditionCode, ProcurementCode, Reason, ReworkNumber, "
                    If Request.QueryString("inv") <> "" Then
                        hSql &= " AssetInvId, "
                    End If
                    hSql &= " LocationId, Location2, Location3, Location4, "
                    hSql &= " PurposeCode, Status, ILSMISControlNumber, DocumentNumber,  "
                    hSql &= " MaintDocNumber, EffectiveDate, Remarks, TransDate, TransBy)"
                    hSql &= " VALUES (" & newId & ", " 'AssetId"
                    hSql &= " '" & Request.Form("ddlCc") & "', " 'ConditionCode"
                    hSql &= " '" & Request.Form("ddlPc") & "', " 'Procurementcode"
                    hSql &= " '" & Request.Form("ddlReason") & "', " 'reason"
                    hSql &= " '" & cC.BufStr(txtRwkNum.Text.Trim) & "', " ' rework number
                    If Request.QueryString("inv") <> "" Then
                        hSql &= Request.QueryString("inv") & ", " ' AssetInvId
                    End If
                    '*****************************************
                    If loc1 = 0 Then
                        hSql &= " NULL, " 'location 1"
                    Else
                        hSql &= loc1 & ", " 'location 1"
                    End If
                    If loc2 = 0 Then
                        hSql &= " NULL, " 'location 2"
                    Else
                        hSql &= loc2 & ", " 'location 2"
                    End If
                    If loc3 = 0 Then
                        hSql &= " NULL, " 'location 3"
                    Else
                        hSql &= loc3 & ", " 'location 3"
                    End If
                    If loc4 = 0 Then
                        hSql &= " NULL, " 'location 4"
                    Else
                        hSql &= loc4 & ", " 'location 4"
                    End If
                    '*****************************************
                    hSql &= " '" & UCase(cC.BufStr(txtPurp.Text).Trim) & "', " 'purposecode"
                    hSql &= " '" & Request.Form("ddlStatus") & "', " ' status"
                    hSql &= " '" & Request.Form("ddlIlscont") & "', " 'ilmis control"
                    hSql &= " '" & cC.BufStr(txtDocNum.Text.Trim) & "', " 'documentnumber"
                    hSql &= " '" & cC.BufStr(txtMaintDocNum.Text.Trim) & "', " 'MaintDocNumber"
                    If IsDate(cC.BufStr(txtEffDate.Text.Trim)) Then
                        hSql &= " '" & cC.BufStr(txtEffDate.Text.Trim) & "', " 'EffectiveDate"
                    Else
                        hSql &= " NULL, " 'EffectiveDate"
                    End If
                    hSql &= " '" & Left(cC.BufStr(txtRemarks.Text.Trim), 250) & "', " 'remarks"
                    hSql &= " '" & unifiedDate & "', " 'transdate"
                    hSql &= Session("SWMSUId") & ")" 'transby"

                    cC.executeNonQuery(hSql, Session("swmsDbConnection"))

                    'insert into eventlog --------------
                   cC.LogIt("assets", "Assets: part # " & txtPn.Text & " serial " & txtSn.Text & " added ", "", Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), Session("PQnum"), Session("swmsDbConnection"))
                    Dim newPage As String = "EditAsset.aspx?id=" & newId

                    If Request.QueryString("inv") <> "" Then
                        newPage &= "&inv=" & Request.QueryString("inv")
                    End If
                    If Request.QueryString("mtr") <> "" Then ' ???
                        newPage &= "&mtr=" & Request.QueryString("mtr")
                    End If
                    If Request.QueryString("loc") <> "" Then ' ???
                        newPage &= "&loc=" & Request.QueryString("loc")
                    End If
                    If Request.QueryString("sn") <> "" Then ' ???
                        newPage &= "&sn=" & Request.QueryString("sn")
                    End If
                    Response.Redirect(newPage)

                End If
            End If

        End If

    End Sub
#End Region 'adds a new asset to the assets table

#Region " updAsset "

    Sub updAsset(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)
        updAssetOnly()

        If UsrMsg.Value = "" Then

            Dim addNewHistoryRecord As Boolean = False ' do we do it?
            Dim rwkNum As String = ""
            If CStr(txtAHId.Text) = "0" Then ' theres no history record for it
                addNewHistoryRecord = True
            Else
                ' look up the asset history to compare changes
                Dim ahSql As String = "select isnull(conditioncode,'') as cc,"
                ahSql &= " isnull(procurementcode,'') as pc, isnull(ILSMISControlNumber,'') as ilsCnt, "
                ahSql &= " isnull(purposecode,'') as purpCd, "
                ahSql &= " isnull(locationid,0) as locId, isnull(Location2,0) as loc2, "
                ahSql &= " isnull(Location3,0) as loc3, isnull(Location4,0) as loc4, "
                ahSql &= " isnull(reason,'') as reason, isnull(Status,'') as stat, "
                ahSql &= " isnull(DocumentNumber,'') as docNum, "
                ahSql &= " isnull(MaintDocNumber,'') as maintDoc,"
                ahSql &= " EffectiveDate as effDate, isnull(ReworkNumber,'') as rwk, "
                ahSql &= " isnull(Remarks,'') as rmks from assethistory where AssetHistoryId = " & txtAHId.Text
                Dim rh As DataTable = cC.getAsDataTable(ahSql, Session("swmsDbConnection"))
                If rh.Rows.Count > 0 Then ' has anything changed?
                    Dim condCode As String = "-"
                    If rh.Rows(0)("cc") <> "" And rh.Rows(0)("cc") <> "-" Then
                        condCode = rh.Rows(0)("cc")
                    End If
                    If rh.Rows(0)("rwk") <> "" Then
                        rwkNum = rh.Rows(0)("rwk")
                    End If
                    If CStr(rh.Rows(0)("cc")) <> CStr(Request.Form("ddlCc")) Or _
                        CStr(rh.Rows(0)("locId")) <> CStr(loc1) Or _
                        CStr(rh.Rows(0)("loc2")) <> CStr(loc2) Or _
                        CStr(rh.Rows(0)("loc3")) <> CStr(loc3) Or _
                        CStr(rh.Rows(0)("loc4")) <> CStr(loc4) Or _
                        rh.Rows(0)("stat") <> CStr(Request.Form("ddlStatus")) Or _
                        rh.Rows(0)("pc") <> CStr(Request.Form("ddlPc")) Or _
                        rh.Rows(0)("rwk") <> cC.BufStr(txtRwkNum.Text.Trim) Or _
                        rh.Rows(0)("reason") <> CStr(Request.Form("ddlReason")) Or _
                        rh.Rows(0)("maintDoc") <> cC.BufStr(txtMaintDocNum.Text.Trim) Or _
                        rh.Rows(0)("ilsCnt") <> CStr(Request.Form("ddlIlsCont")) Or _
                        rh.Rows(0)("docNum") <> cC.BufStr(txtDocNum.Text.Trim) Or _
                        rh.Rows(0)("rmks") <> cC.BufStr(txtRemarks.Text.Trim) Or _
                        rh.Rows(0)("purpCd") <> cC.BufStr(txtPurp.Text.Trim) Then
                        addNewHistoryRecord = True
                    End If 'ahRdr("effDate") <> cC.BufStr(txtEffDate.Text.Trim) Or _
                End If
            End If ' If txtAHId.Text = 0 Then

            If addNewHistoryRecord = True Then
                Dim ihSql As String = "INSERT INTO AssetHistory "
                ihSql &= " (AssetId, ConditionCode, ProcurementCode, PurposeCode, Status, "
                ihSql &= " LocationId, Location2, Location3, Location4, "
                ihSql &= " ILSMISControlNumber, DocumentNumber, Remarks,"
                ihSql &= "  MaintDocNumber, EffectiveDate, ReworkNumber, " '---
                ihSql &= "  reason, TransDate, TransBy) VALUES ("
                ihSql &= Request.QueryString("id") & ", "   ' AssetId
                If CStr(Request.Form("ddlCc")) = "-" Then
                    ihSql &= "'', " ' ConditionCode
                Else
                    ihSql &= "'" & CStr(Request.Form("ddlCc")) & "', " ' ConditionCode
                End If
                If CStr(Request.Form("ddlPc")) = "0" Then
                    ihSql &= "'', " ' ProcurementCode
                Else
                    ihSql &= "'" & CStr(Request.Form("ddlPc")) & "', " ' ProcurementCode
                End If
                ihSql &= "'" & cC.BufStr(txtPurp.Text.Trim) & "', " ' PurposeCode
                ihSql &= "'" & CStr(Request.Form("ddlStatus")) & "', " ' Status
                If loc1 = 0 Then
                    ihSql &= " NULL, " 'location 1"
                Else
                    ihSql &= loc1 & ", " 'location 1"
                End If
                If loc2 = 0 Then
                    ihSql &= " NULL, " 'location 2"
                Else
                    ihSql &= loc2 & ", " 'location 2"
                End If
                If loc3 = 0 Then
                    ihSql &= " NULL, " 'location 3"
                Else
                    ihSql &= loc3 & ", " 'location 3"
                End If
                If loc4 = 0 Then
                    ihSql &= " NULL, " 'location 4"
                Else
                    ihSql &= loc4 & ", " 'location 4"
                End If
                If CStr(Request.Form("ddlIlsCont")) = "0" Then
                    ihSql &= "'', " ' ILSMISControlNumber
                Else
                    ihSql &= "'" & CStr(Request.Form("ddlIlsCont")) & "', " ' ILSMISControlNumber
                End If
                ihSql &= "'" & cC.BufStr(txtDocNum.Text.Trim) & "', " ' DocumentNumber
                ihSql &= "'" & cC.BufStr(txtRemarks.Text.Trim) & "', " ' Remarks
                ihSql &= "'" & cC.BufStr(txtMaintDocNum.Text.Trim) & "', " ' MaintDocNumber
                If IsDate(txtEffDate.Text) Then
                    ihSql &= "'" & cC.BufStr(txtEffDate.Text.Trim) & "', " ' EffectiveDate
                Else
                    ihSql &= "NULL, " ' EffectiveDate
                End If
                If CStr(txtRwkNum.Text) = "" And rwkNum <> "" Then
                    ihSql &= "'" & rwkNum & "', " ' reinstate old rework number
                Else
                    ihSql &= "'" & cC.BufStr(txtRwkNum.Text.Trim) & "', " ' rework number
                End If

                ihSql &= "'" & CStr(Request.Form("ddlReason")) & "', " ' reason
                ihSql &= "getdate(), " ' TransDate
                ihSql &= Session("SWMSUId") & ")" ' TransBy
                cC.executeNonQuery(ihSql, Session("swmsDBConnection"))

              cC.LogIt("Assets", "Asset history created for Part #: " & lblpn.Text & " S/N: " & txtSn.Text & " (AssetId: " & Request.QueryString("id") & ")", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))
            End If

            Dim newPage As String = "EditAsset.aspx?id=" & Request.QueryString("id")
            If Request.QueryString("inv") <> "" Then
                newPage &= "&inv=" & Request.QueryString("inv")
            End If
            Response.Redirect(newPage)

        End If
    End Sub
#End Region

End Class
