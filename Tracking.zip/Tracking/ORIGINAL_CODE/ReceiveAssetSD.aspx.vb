﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Partial Class Tracking_ReceiveAssetSD
    Inherits System.Web.UI.Page

    Dim cC As New commonClass
    Dim sql As String = ""
    'Dim highSeq As Integer = 0

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("SWMSlvl") < 10 Or Session("SWMSlvl") = Nothing) Then
            Response.Redirect("../Main/WalkAbout.aspx?d=Default.aspx&w=MNT")
        Else
            cC.HitCount(Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"))
        End If

        lnkInv.Visible = False
        ThisTime.Text = Today.ToShortDateString
        lblRowCount.Text = ""

        If Not Page.IsPostBack Then ' NEW Page
            'add required maxlength attribute to the textarea
            txtRemarks.Attributes.Add("maxlength", 500)

            fillDdls()
        Else
            If txtPid.Text = "" Then
                txtPid.Text = Request.Form("txtPid")
            End If
            If txtNomenclature.Text = "" Then
                txtNomenclature.Text = Request.Form("txtNomenclature")
            End If
            If txtModelNumber.Text = "" Then
                txtModelNumber.Text = Request.Form("txtModelNumber")
            End If
            If txtCAGE.Text = "" Then
                txtCAGE.Text = Request.Form("txtCAGE")
            End If
            If txtPIN.Text = "" Then
                txtPIN.Text = Request.Form("txtPIN")
            End If
            If txtCOG.Text = "" Then
                txtCOG.Text = Request.Form("txtCOG")
            End If
            '
            If txtPid.Text <> "" Then

                If txtCommand.Text = "prep" Then
                    ' GoGetIt()
                    Dim x As Boolean = validateICN()
                    validateAsset()
                    buildTable()
                    'End If
                End If
                'If txtCommand.Text = "GGI" Then
                '    ' GoGetIt()
                '    validateAsset()
                '    buildTable()
                'End If
                If txtCommand.Text = "reset" Then
                    AssetsTab.Controls.Clear()
                    resetTop()
                    btnSub.Disabled = False
                    btnSub.Visible = True
                End If
                If txtCommand.Text = "final" Then
                    validSerial()
                End If
                If txtCommand.Text = "clear" Then
                    Response.Redirect("./ReceiveAssetSD.aspx")
                End If
            Else
                If txtNIIN.Text.Trim <> "" Or txtPartNumber.Text.Trim <> "" Then
                    GoGetIt()
                    '   if only one choice treat as "prep"
                    If txtPid.Text <> "" Then
                        Dim y As Boolean = validateICN()
                        validateAsset()
                        buildTable()
                    End If
                Else
                    lblRowCount.Text = "No such asset defined in SWMS.  Use <a id='lnkRet1' class='SmContent' href='../Main/Walkabout.aspx?d=Library/PartsEdit.aspx?id=0&w=PLN'>Planning, Library, Parts</a> to define Asset."
                End If
            End If
        End If

    End Sub

    Sub fillDdls()

        ' SubGroup & Acct Code  -------------------------------
        ddlSubGroup.Items.Clear()
        Dim sgSql As String = "SELECT '-' AS ProgramName, '' AS ProgramType "
        sgSql &= " UNION ALL "
        sgSql &= " SELECT ProgramName, ProgramType "
        sgSql &= " FROM Programs "
        sgSql &= " ORDER BY ProgramName"

        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing

        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(sgSql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sgSql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/EditAssetSD.aspx")
            Throw ex
        Finally
            swmsDb.Close()
        End Try

        ddlSubGroup.DataSource = sqldt
        ddlSubGroup.DataValueField = "ProgramName"
        ddlSubGroup.DataTextField = "ProgramName"
        ddlSubGroup.DataBind()

        ddlAcctPIN.DataSource = sqldt
        ddlAcctPIN.DataValueField = "ProgramType"
        ddlAcctPIN.DataTextField = "ProgramName"
        ddlAcctPIN.DataBind()
        '
        ' condition code --------------------------------------------
        ddlCc.Items.Clear()
        Dim ccSql As String = " Select '-' as SVD_Attribute UNION ALL "
        ccSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        ccSql &= " WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute"
        ddlCc.DataSource = cC.getAsDataTable(ccSql, Session("swmsDbConnection"))
        ddlCc.DataValueField = "SVD_Attribute"
        ddlCc.DataTextField = "SVD_Attribute"
        ddlCc.DataBind()
        '
        ' procurement code -----------------------------------------
        'ddlProcCd.Items.Clear()
        'Dim pcSql As String = "SELECT '-' AS ProcCd, '-' AS ProcDesc"
        'pcSql &= " UNION ALL"
        'pcSql &= " SELECT ProcCd, ProcDesc"
        'pcSql &= " FROM ProcMakeBuyCodes "
        'pcSql &= " WHERE MakeBuy = 'M' "
        'pcSql &= " ORDER BY ProcCd"
        'ddlProcCd.DataSource = cC.getAsDataTable(pcSql, Session("swmsDbConnection"))
        'ddlProcCd.DataValueField = "ProcCd"
        'ddlProcCd.DataTextField = "ProcCd"
        'ddlProcCd.DataBind()

        ' reason -------------------------------------
        ddlReason.Items.Clear()
        Dim rSql As String = "SELECT '-' as SVD_Attribute UNION ALL "
        rSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        rSql &= " WHERE (SVD_Name = 'AssetReason') "
        rSql &= " AND ((SVD_Attribute LIKE 'RCV%') or (SVD_Attribute LIKE 'A/6%')) "
        rSql &= " ORDER BY SVD_Attribute"
        ddlReason.DataSource = cC.getAsDataTable(rSql, Session("swmsDbConnection"))
        ddlReason.DataValueField = "SVD_Attribute"
        ddlReason.DataTextField = "SVD_Attribute"
        ddlReason.DataBind()

    End Sub

    Function validateICN() As Boolean
        'validate unique ICN??
        'highSeq = 0
        txtICN.BackColor = Drawing.Color.White
        Dim rtn As Boolean = True
        If txtICN.Text.Trim <> "" Then
            Dim Isql As String
            Isql = "SELECT ICNnum FROM Assets "
            Isql &= " WHERE (ICNnum = '" & txtICN.Text & "')"
            Isql &= " GROUP BY ICNnum"

            '"SELECT ICNnum, CASE WHEN HiSeq > Cnt THEN HiSeq ELSE Cnt END AS HighSeq"
            'Isql &= " FROM ("
            'Isql &= " 	SELECT ICNnum, ISNULL(MAX(ICNseq), 0) AS HiSeq, COUNT(*) AS Cnt"
            'Isql &= " 	FROM Assets "
            'Isql &= " 	WHERE (ICNnum = '" & txtICN.Text & "')"
            'Isql &= " 	GROUP BY ICNnum"
            'Isql &= " ) x1"

            Dim swmsDb As New SqlConnection
            Dim Isqldt As DataTable = Nothing
            Try
                swmsDb.ConnectionString = Session("swmsDbConnection")
                swmsDb.Open()
                Dim SqlCmd As New SqlCommand(Isql, swmsDb)
                Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
                Isqldt = New DataTable("Results")
                sqlDA.Fill(Isqldt)
            Catch ex As Exception
                cC.sendExEmail("AST/Tracking/EditAssetSD.aspx", Isql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "getAsDataTable()")
                Throw ex
            Finally
                swmsDb.Close()
            End Try

            If Isqldt.Rows.Count >= 1 Then
                'highSeq = CInt(Isqldt.Rows(0)("HighSeq"))
                txtICN.BackColor = Drawing.Color.LightYellow
                UsrMsg.Value = "This ICN has been used before."
                rtn = False
            End If

        End If
        Return rtn
    End Function

    Sub validateAsset()
        '
        If txtPid.Text = "" Then
            If txtNIIN.Text.Trim <> "" Or txtPartNumber.Text.Trim <> "" Then
                'validate niin partnumber = pid
                'use niin partnumber to find single pid or popup choice if multiples found   
                sql = "SELECT Pid, NIIN, ISNULL(PrimaryPart, '0') AS PrimaryPart,"
                sql &= " (SELECT COUNT(*) AS Cnt FROM PartsMaster WHERE NIIN = '" & txtNIIN.Text.Trim & "') AS ppCnt,"
                sql &= " PartNumber, ISNULL(COG, '') AS COG,"
                sql &= " ISNULL(ModelNumber, '') AS ModelNumber, ISNULL(Nomenclature, '') AS Nomenclature,"
                sql &= " ISNULL(ProcurementCode, '') AS ProcurementCode, ISNULL(CAGE, '') AS CAGE"
                sql &= " FROM PartsMaster"
                sql &= " WHERE (Pid IS NOT NULL)"
                If txtNIIN.Text.Trim <> "" Then
                    sql &= " AND (NIIN LIKE '" & txtNIIN.Text.Trim & "')"
                End If
                If txtPartNumber.Text.Trim <> "" Then
                    sql &= " AND (PartNumber LIKE '" & txtPartNumber.Text.Trim & "')"
                End If

                Dim swmsDb As New SqlConnection
                Dim sqldt As DataTable = Nothing
                Try
                    swmsDb.ConnectionString = Session("swmsDbConnection")
                    swmsDb.Open()
                    Dim SqlCmd As New SqlCommand(sql, swmsDb)
                    Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
                    sqldt = New DataTable("Results")
                    sqlDA.Fill(sqldt)
                Catch ex As Exception
                    cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/ReceiveAssetSD.aspx")
                    Throw ex
                Finally
                    swmsDb.Close()
                End Try

                If sqldt.Rows.Count = 1 Then
                    SelTab.Visible = False
                    AssetsTab.Visible = True
                    'txtPid.Text = sqldt.Rows(0)("Pid")
                    txtPid.Text = sqldt.Rows(0)("Pid")
                    txtNIIN.Text = sqldt.Rows(0)("NIIN")
                    txtPartNumber.Text = sqldt.Rows(0)("PartNumber")
                    txtNomenclature.Text = sqldt.Rows(0)("Nomenclature")
                    txtModelNumber.Text = sqldt.Rows(0)("ModelNumber")
                    txtCAGE.Text = sqldt.Rows(0)("CAGE")
                    txtCOG.Text = sqldt.Rows(0)("COG")
                    '
                End If

                If sqldt.Rows.Count < 1 Then
                    'show error message - no Asset exists (no partsmaster record found).
                    Dim hr1 As New TableRow
                    hr1.BackColor = Drawing.Color.FromArgb(153, 204, 255)
                    '
                    Dim hd1 As New TableCell
                    hd1.CssClass = "smBContent"
                    hd1.HorizontalAlign = HorizontalAlign.Center
                    hd1.Text = "No such Asset exists in SWMS. Use <a id='lnkRet' class='SmContent' href='../Main/Walkabout.aspx?d=Library/PartsEdit.aspx?id=0&w=PLN'>Planning, Library, Parts</a> to create new Asset Master Record, or try again."
                    hr1.Cells.Add(hd1)
                    '
                    SelTab.Rows.Add(hr1)
                    '
                    SelTab.Visible = True
                    AssetsTab.Visible = False
                    txtPid.Text = ""
                    btnSub.Disabled = False
                    btnSub.Visible = True
                End If

                If sqldt.Rows.Count > 1 Then
                    ' show selection div to indicate which part is to be used
                    Dim hr1 As New TableRow
                    hr1.BackColor = Drawing.Color.FromArgb(153, 204, 255)
                    '
                    Dim hd1 As New TableCell
                    hd1.ColumnSpan = 7
                    hd1.CssClass = "smBContent"
                    hd1.HorizontalAlign = HorizontalAlign.Center
                    hd1.Text = "Verify Assets For Receipt"
                    hr1.Cells.Add(hd1)
                    '
                    SelTab.Rows.Add(hr1)
                    '
                    Dim hr2 As New TableRow
                    hr2.BackColor = Drawing.Color.FromArgb(153, 204, 255)

                    Dim td1 As New TableCell
                    td1.Text = "NIIN"
                    td1.HorizontalAlign = HorizontalAlign.Center
                    hr2.Cells.Add(td1)
                    '
                    Dim td1p As New TableCell
                    td1p.Text = "PP"
                    td1p.HorizontalAlign = HorizontalAlign.Center
                    hr2.Cells.Add(td1p)
                    '
                    Dim td2 As New TableCell
                    td2.Text = "Part Number"
                    td2.HorizontalAlign = HorizontalAlign.Center
                    hr2.Cells.Add(td2)
                    '
                    Dim td3 As New TableCell
                    td3.Text = "Model Number"
                    td3.HorizontalAlign = HorizontalAlign.Center
                    hr2.Cells.Add(td3)
                    '
                    Dim td4 As New TableCell
                    td4.Text = "Nomenclature"
                    td4.HorizontalAlign = HorizontalAlign.Center
                    hr2.Cells.Add(td4)
                    '
                    Dim td5 As New TableCell
                    td5.Text = "Manufacturer"
                    td5.HorizontalAlign = HorizontalAlign.Center
                    hr2.Cells.Add(td5)
                    '
                    Dim td6 As New TableCell
                    td6.Text = "Proc. Code"
                    td6.HorizontalAlign = HorizontalAlign.Center
                    hr2.Cells.Add(td6)
                    '
                    SelTab.Rows.Add(hr2)
                    '
                    Dim i As Integer = 0
                    Do While i <= sqldt.Rows.Count - 1
                        Dim trx As New TableRow
                        Dim tx1 As New TableCell
                        tx1.Text = sqldt.Rows(i)("NIIN")
                        tx1.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                        tx1.Style.Add("cursor", "hand")
                        trx.Cells.Add(tx1)
                        '
                        Dim tx1p As New TableCell
                        If sqldt.Rows(i)("ppCnt") = 1 Or sqldt.Rows(i)("PrimaryPart") = "1" Then
                            tx1p.Text = "*"
                            tx1p.HorizontalAlign = HorizontalAlign.Center
                            tx1p.ToolTip = "* Pick Me!"
                        Else
                            tx1p.Text = " "
                        End If
                        tx1p.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                        tx1p.Style.Add("cursor", "hand")
                        trx.Cells.Add(tx1p)
                        '
                        Dim tx2 As New TableCell
                        tx2.Text = sqldt.Rows(i)("PartNumber")
                        tx2.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                        tx2.Style.Add("cursor", "hand")
                        trx.Cells.Add(tx2)
                        '
                        Dim tx3 As New TableCell
                        tx3.Text = sqldt.Rows(i)("ModelNumber")
                        tx3.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                        tx3.Style.Add("cursor", "hand")
                        trx.Cells.Add(tx3)
                        '
                        Dim tx4 As New TableCell
                        tx4.Text = sqldt.Rows(i)("Nomenclature")
                        tx4.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                        tx4.Style.Add("cursor", "hand")
                        trx.Cells.Add(tx4)
                        '
                        Dim tx5 As New TableCell
                        tx5.Text = sqldt.Rows(i)("CAGE")
                        tx5.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                        tx5.Style.Add("cursor", "hand")
                        trx.Cells.Add(tx5)
                        '
                        Dim tx6 As New TableCell
                        tx6.Text = sqldt.Rows(i)("ProcurementCode")
                        tx6.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                        tx6.Style.Add("cursor", "hand")
                        trx.Cells.Add(tx6)
                        '
                        If sqldt.Rows(i)("Pid").ToString = txtPid.Text Then
                            trx.BackColor = System.Drawing.Color.FromArgb(13434828)     '#CCFFCC
                        End If
                        '
                        SelTab.Rows.Add(trx)
                        i += 1
                    Loop
                    SelTab.Visible = True
                    'AssetsTab.Visible = False
                    lblRowCount.Text = ""
                End If
            Else
                UsrMsg.Value = "Please use NIIN and/or Part Number to find Assets."
            End If
        End If

    End Sub

    Sub buildTable()
        If txtPid.Text <> "" Then
            '   ensure that correct data is populated for the type asset chosen
            sql = "SELECT ISNULL(PM.PrimaryPart, '0') AS PrimaryPart, PP.ppCnt,"
            sql &= " PM.PartNumber, PM.NIIN, PM.Nomenclature, ISNULL(PM.ModelNumber, '') AS ModelNumber, "
            sql &= "ISNULL(PM.CAGE, '') AS CAGE, ISNULL(PM.COG, '') AS COG"
            sql &= " FROM PartsMaster PM"
            sql &= " INNER JOIN ("
            sql &= " 	SELECT NIIN, COUNT(*) AS ppCnt FROM PartsMaster"
            sql &= " 	WHERE NIIN = (SELECT NIIN FROM PartsMaster WHERE Pid = " & txtPid.Text & ") GROUP BY NIIN"
            sql &= " ) PP ON PM.NIIN = PP.NIIN"
            sql &= " WHERE (PM.Pid = " & txtPid.Text & ");"

            Dim swmsDb As New SqlConnection
            Dim sqldt As DataTable = Nothing
            Try
                swmsDb.ConnectionString = Session("swmsDbConnection")
                swmsDb.Open()
                Dim SqlCmd As New SqlCommand(sql, swmsDb)
                Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
                sqldt = New DataTable("AssetList")
                sqlDA.Fill(sqldt)
            Catch ex As Exception
                cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/IssueAssets.aspx")
                Throw ex
            Finally
                swmsDb.Close()
            End Try
            swmsDb.Dispose()

            lblRowCount.ForeColor = Drawing.Color.Black

            If sqldt.Rows.Count > 0 Then
                txtNIIN.Text = sqldt.Rows(0)("NIIN")
                txtPartNumber.Text = sqldt.Rows(0)("PartNumber")
                txtNomenclature.Text = sqldt.Rows(0)("Nomenclature")
                txtModelNumber.Text = sqldt.Rows(0)("ModelNumber")
                txtCAGE.Text = sqldt.Rows(0)("CAGE")
                txtCOG.Text = sqldt.Rows(0)("COG")
                'Test for NOT Primary Part
                If sqldt.Rows(0)("ppCnt") > 1 And sqldt.Rows(0)("PrimaryPart") = "0" Then
                    lblRowCount.Text = "<b>==>>> This is NOT the primary part for this NIIN! <<<==</b>"
                    lblRowCount.ForeColor = Drawing.Color.Red
                End If
            End If
            '
            If IsNumeric(txtQuantity.Text.Trim) Then
                btnPart.Disabled = True
                btnSub.Disabled = True
                btnSub.Visible = False
                freezeTop()
                '
                AssetsTab.Controls.Clear()

                Dim hr1 As New TableRow
                hr1.BackColor = Drawing.Color.FromArgb(153, 204, 255)
                Dim hc As New TableCell
                hc.ColumnSpan = 8
                hc.CssClass = "smBContent"
                hc.HorizontalAlign = HorizontalAlign.Center
                hc.Text = "Verify Individual Items For Receipt"
                hr1.Cells.Add(hc)
                AssetsTab.Rows.Add(hr1)

                Dim hr2 As New TableRow
                hr2.BackColor = Drawing.Color.FromArgb(153, 204, 255)
                Dim td1 As New TableCell
                td1.Text = "ICN"
                td1.HorizontalAlign = HorizontalAlign.Center
                hr2.Cells.Add(td1)

                Dim td4 As New TableCell
                td4.Text = "Serial"
                td4.HorizontalAlign = HorizontalAlign.Center
                hr2.Cells.Add(td4)

                Dim td6 As New TableCell
                td6.Text = "Condition"
                td6.HorizontalAlign = HorizontalAlign.Center
                hr2.Cells.Add(td6)

                Dim td8 As New TableCell
                td8.Text = "History Remarks"
                td8.HorizontalAlign = HorizontalAlign.Center
                hr2.Cells.Add(td8)
                AssetsTab.Rows.Add(hr2)

                Dim i As Integer = 1
                Do While i <= CInt(txtQuantity.Text.Trim)

                    Dim tr As New TableRow

                    Dim td2 As New TableCell
                    td2.HorizontalAlign = HorizontalAlign.Center
                    Dim tdxICN As New Label
                    tdxICN.CssClass = "SmContent"
                    tdxICN.Text = txtICN.Text.Trim
                    'tdxICN.Width = Unit.Pixel(76)
                    td2.Controls.Add(tdxICN)
                    Dim tdxSeq As New TextBox
                    tdxSeq.ID = "tdxSeq" & CStr(i)
                    tdxSeq.Attributes.Add("name", "tdxSeq" & CStr(i))
                    tdxSeq.CssClass = "SmContent"
                    tdxSeq.Text = ""    'Right("0000" & CStr(i + highSeq), 4)
                    If txtICN.Text.Trim = "" Or ddlSubGroup.SelectedValue <> "CICPOVHL" Then
                        tdxSeq.Width = Unit.Pixel(0)
                        tdxSeq.Height = Unit.Pixel(0)
                        tdxSeq.BorderWidth = Unit.Pixel(0)
                        tdxSeq.TabIndex = -1
                    Else
                        tdxSeq.Width = Unit.Pixel(36)
                        tdxSeq.Attributes.Add("onblur", "javascript:chkSeq('tdxSeq" & CStr(i) & "', this.value);")
                    End If

                    tdxSeq.MaxLength = 4
                    td2.Controls.Add(tdxSeq)
                    tr.Cells.Add(td2)

                    Dim td5 As New TableCell
                    td5.HorizontalAlign = HorizontalAlign.Center
                    Dim tdxSer As New TextBox
                    tdxSer.ID = "tdxSer" & CStr(i)
                    tdxSer.Attributes.Add("onblur", "javascript:chkSn('tdxSer" & CStr(i) & "', this.value, 'sp" & CStr(i) & "');")
                    tdxSer.CssClass = "SmContent"
                    tdxSer.Width = Unit.Pixel(120)
                    tdxSer.Text = ""
                    tdxSer.MaxLength = 50
                    td5.Controls.Add(tdxSer)
                    Dim spn As New Label
                    spn.ID = "sp" & CStr(i)
                    spn.Attributes.Add("Style", "FONT-WEIGHT:bold; FONT-SIZE:8pt; COLOR:red; FONT-FAMILY:Verdana")
                    If ddlSubGroup.SelectedValue <> "CICPOVHL" Then
                        spn.Text = "*"
                    End If
                    td5.Controls.Add(spn)
                    tr.Cells.Add(td5)

                    Dim td7 As New TableCell
                    td7.HorizontalAlign = HorizontalAlign.Center
                    Dim tdxCC As New TextBox
                    tdxCC.ID = "tdxCC" & CStr(i)
                    tdxCC.CssClass = "SmContent"
                    tdxCC.Text = ddlCc.SelectedValue
                    tdxCC.Width = Unit.Pixel(14)
                    tdxCC.MaxLength = 1
                    td7.Controls.Add(tdxCC)
                    tr.Cells.Add(td7)

                    Dim td9 As New TableCell
                    td9.HorizontalAlign = HorizontalAlign.Center
                    Dim tdxRem As New TextBox
                    tdxRem.ID = "tdxRem" & CStr(i)
                    tdxRem.CssClass = "SmContent"
                    tdxRem.Text = txtRemarks.Text
                    tdxRem.MaxLength = 500
                    tdxRem.Width = Unit.Pixel(250)
                    td9.Controls.Add(tdxRem)
                    tr.Cells.Add(td9)

                    AssetsTab.Rows.Add(tr)
                    i = i + 1
                Loop
                '
                Dim trailer1 As New TableRow
                Dim tl1 As New TableCell
                tl1.HorizontalAlign = HorizontalAlign.Center
                tl1.ColumnSpan = 8
                tl1.Text = "<hr style=""color:#99CCFF; width:70%; line-height: 1px;""/>"
                trailer1.Cells.Add(tl1)
                AssetsTab.Rows.Add(trailer1)

                Dim trailer2 As New TableRow
                Dim tl2 As New TableCell
                tl2.HorizontalAlign = HorizontalAlign.Center
                tl2.ColumnSpan = 8
                tl2.Text = "<input class='SmContent' id='btnFinal' onclick='javascript:final();' type='button' value='Submit' name='btnFinal' runat='server' />"
                tl2.Text &= "&nbsp;&nbsp;&nbsp;&nbsp;"
                tl2.Text &= "<input class='SmContent' id='btnReset' onclick='javascript:backup();' type='button' value='Reset' name='btnReset' runat='server' />"
                trailer2.Cells.Add(tl2)
                AssetsTab.Rows.Add(trailer2)
            Else
                UsrMsg.Value = "How many are being received?"
            End If
        End If
    End Sub

    Sub freezeTop()
        ' block changes
        txtNIIN.ReadOnly = True
        txtPartNumber.ReadOnly = True
        txtQuantity.ReadOnly = True
        ddlSubGroup.Enabled = False
        txtNomenclature.ReadOnly = True
        txtModelNumber.ReadOnly = True
        txtCAGE.ReadOnly = True
        txtCOG.ReadOnly = True
        txtICN.ReadOnly = True
        txtDocument.ReadOnly = True
        ddlReason.Enabled = False
        txtReceivedFrom.ReadOnly = True
        ddlCc.Enabled = False
        txtRemarks.ReadOnly = True
        txtDate.ReadOnly = True
        '
    End Sub

    Sub resetTop()
        ' allow changes
        txtPid.Text = ""
        txtNIIN.ReadOnly = False
        txtPartNumber.ReadOnly = False
        txtQuantity.ReadOnly = False
        ddlSubGroup.Enabled = True
        txtNomenclature.ReadOnly = False
        txtModelNumber.ReadOnly = False
        'txtCAGE.ReadOnly = False
        'txtCOG.ReadOnly = False
        txtICN.ReadOnly = False
        txtDocument.ReadOnly = False
        ddlReason.Enabled = True
        txtReceivedFrom.ReadOnly = False
        ddlCc.Enabled = True
        txtRemarks.ReadOnly = False
        txtDate.ReadOnly = False
        btnPart.Disabled = False
        '
        btnSub.Disabled = False
        btnSub.Visible = True
        '
    End Sub

    Sub validSerial()
        ' There must be a serial number, unique for this NIIN.  
        '   The only exception is for subgroup CICPOVHL, 
        '   which may use ICNnum-ICNseq As Serial
        ' condition code muse be valid

        Dim errMsg As String = ""
        Dim i As Integer = 0
        Dim j As Integer = 0

        If Not IsNumeric(txtQuantity.Text.Trim) Then
            errMsg &= "Invalid Quantity." & Chr(13)
            txtQuantity.BackColor = Drawing.Color.MistyRose
        Else
            j = CInt(txtQuantity.Text.Trim)
        End If

        i = 1
        Dim ccMatch As Boolean = False
        Do While i <= j
            If Request.Form("tdxSer" & CStr(i)) = "" Or Request.Form("tdxSer" & CStr(i)) = Nothing Then
                If ddlSubGroup.SelectedValue = "CICPOVHL" Then
                    ' exception if ICN & Seq filled in.
                Else
                    errMsg &= "Line " & CStr(i) & ": Serial number required." & Chr(13)
                End If
            End If
            '
            If ddlSubGroup.SelectedValue = "CICPOVHL" Then
                If Request.Form("txtICN") = "" Or Request.Form("txtICN") = Nothing Then
                    errMsg &= "Line " & CStr(i) & ": ICN required for CICPOVHL." & Chr(13)      ' when Serial Number is not available.
                End If
                If Request.Form("tdxSeq" & CStr(i)) = "" Or Request.Form("tdxSeq" & CStr(i)) = Nothing Then
                    errMsg &= "Line " & CStr(i) & ": Sequence required for CICPOVHL." & Chr(13)
                End If
            End If
            '
            ccMatch = False
            If Request.Form("tdxCC" & CStr(i)) = "" Or Request.Form("tdxCC" & CStr(i)) = Nothing Then
                errMsg &= "Line " & CStr(i) & ": CC required." & Chr(13)
            Else
                For idx As Integer = 0 To ddlCc.Items.Count - 1 Step 1
                    If Request.Form("tdxCC" & CStr(i)) = ddlCc.Items(idx).Value Then
                        ccMatch = True
                        idx = ddlCc.Items.Count
                    End If
                Next
                If ccMatch = False Then
                    errMsg &= "Line " & CStr(i) & ": CC not valid." & Chr(13)
                End If
            End If
            i += 1
        Loop

        'If you already have errors, no need for more testing...
        '   besides you need the clean data for the next test.
        If errMsg = "" Then
            ' a bit more testing
            Dim MyDS As New DataSet
            Dim wrkRow As DataRow
            Dim wrkTbl As New DataTable("RecvAssets") '   create the schema for the table
            With wrkTbl.Columns
                .Add(New DataColumn("AssetId", System.Type.GetType("System.String")))
                .Add(New DataColumn("Pid", System.Type.GetType("System.String")))
                .Add(New DataColumn("CurrentStatus", System.Type.GetType("System.String")))
                .Add(New DataColumn("CurrentLocation", System.Type.GetType("System.String")))
                .Add(New DataColumn("ICNseq", System.Type.GetType("System.String")))
                .Add(New DataColumn("Serial", System.Type.GetType("System.String")))
                .Add(New DataColumn("CC", System.Type.GetType("System.String")))
                .Add(New DataColumn("Remarks", System.Type.GetType("System.String")))
            End With
            MyDS.Tables.Add(wrkTbl) ' Add the new DataTable to the DataSet.
            '
            Dim swmsDb As New SqlConnection
            swmsDb.ConnectionString = Session("swmsDbConnection")

            i = 1
            Do While i <= j
                sql = "SELECT A1.AssetId, A1.Pid, ISNULL(L1.LocationIdCode, 'ISSUED') AS CurrentStatus,"
                sql &= " ISNULL(L2.LocationIdCode, '') + '/' + ISNULL(L3.LocationIdCode, '')"
                sql &= " 	+ '/' + ISNULL(L4.LocationIdCode, '') AS CurrentLocation "
                sql &= " FROM Assets A1"
                sql &= " LEFT OUTER JOIN Locations L1 ON L1.LocationId = A1.LocationId"
                sql &= " LEFT OUTER JOIN Locations L2 ON L2.LocationId = A1.Location2"
                sql &= " LEFT OUTER JOIN Locations L3 ON L3.LocationId = A1.Location3"
                sql &= " LEFT OUTER JOIN Locations L4 ON L4.LocationId = A1.Location4"
                sql &= " WHERE (A1.Pid = " & txtPid.Text & ")"
                If Request.Form("tdxSer" & CStr(i)) = "" Or Request.Form("tdxSer" & CStr(i)) = Nothing Then
                    sql &= " AND ((A1.SerialNumber = '" & cC.BufStr(Request.Form("txtICN")) & "-" & Request.Form("tdxSeq" & CStr(i)) & "')"     'Right("000" & CStr(i), 4)
                Else
                    sql &= " AND ((A1.SerialNumber = '" & cC.BufStr(Request.Form("tdxSer" & CStr(i))) & "')"
                End If
                If ddlSubGroup.SelectedValue = "CICPOVHL" Then  '/* do not allow duplicate ICN Serial Numbers */
                    sql &= " OR ((A1.ICNnum = '" & cC.BufStr(Request.Form("txtICN")) & "') AND (A1.ICNseq = " & Request.Form("tdxSeq" & CStr(i)) & "))"
                End If
                sql &= ")"
                'Response.Write(sql)
                'Response.Flush()
                swmsDb.Open()

                Dim cmdRte As New SqlCommand(sql, swmsDb)
                Dim drRte As SqlDataReader
                drRte = cmdRte.ExecuteReader()

                wrkRow = wrkTbl.NewRow()
                If drRte.Read() Then
                    wrkRow("AssetId") = drRte("AssetId")
                    wrkRow("Pid") = drRte("Pid")
                    wrkRow("CurrentStatus") = drRte("CurrentStatus")
                    wrkRow("CurrentLocation") = drRte("CurrentLocation")
                Else
                    wrkRow("AssetId") = ""
                    wrkRow("Pid") = txtPid.Text
                    wrkRow("CurrentStatus") = "NEW"
                    wrkRow("CurrentLocation") = ""
                End If
                If ddlSubGroup.SelectedValue = "CICPOVHL" Then
                    wrkRow("ICNseq") = Request.Form("tdxSeq" & CStr(i))
                Else
                    wrkRow("ICNseq") = "0"      '???
                End If
                If Request.Form("tdxSer" & CStr(i)) = "" Or Request.Form("tdxSer" & CStr(i)) = Nothing Then
                    wrkRow("Serial") = cC.BufStr(Request.Form("txtICN")).ToUpper & "-" & Right("000" & Request.Form("tdxSeq" & CStr(i)), 4)
                Else
                    wrkRow("Serial") = cC.BufStr(Request.Form("tdxSer" & CStr(i))).ToUpper
                End If
                wrkRow("CC") = Request.Form("tdxCC" & CStr(i))
                wrkRow("Remarks") = Request.Form("tdxRem" & CStr(i))

                wrkTbl.Rows.Add(wrkRow)

                drRte.Close()
                swmsDb.Close()
                '
                drRte = Nothing
                i += 1
            Loop
            swmsDb.Dispose()
            '=======================================================================
            
            For idx As Integer = 0 To MyDS.Tables("RecvAssets").Rows.Count - 1
                ' If this Serial Number is in the list more than once
                For jdx As Integer = idx + 1 To MyDS.Tables("RecvAssets").Rows.Count - 1
                    If MyDS.Tables("RecvAssets").Rows(idx)("Serial") = MyDS.Tables("RecvAssets").Rows(jdx)("Serial") Then
                        If i = j Then
                            'ignore
                        Else
                            errMsg &= "Duplicate Serial Number " & MyDS.Tables("RecvAssets").Rows(idx)("Serial") & ", found in Receipt List" & Chr(13)
                        End If
                    End If
                Next
            Next
            '=======================================================================

            If ddlSubGroup.SelectedValue = "CICPOVHL" Then
                For idx As Integer = 0 To MyDS.Tables("RecvAssets").Rows.Count - 1
                    ' If this ICN Ssequence Number is in the list more than once
                    For jdx As Integer = idx + 1 To MyDS.Tables("RecvAssets").Rows.Count - 1
                        If MyDS.Tables("RecvAssets").Rows(idx)("ICNseq") = MyDS.Tables("RecvAssets").Rows(jdx)("ICNseq") Then
                            If i = j Then
                                'ignore
                            Else
                                errMsg &= "Duplicate ICN Sequence Number " & MyDS.Tables("RecvAssets").Rows(idx)("ICNseq") & ", found in Receipt List" & Chr(13)
                            End If
                        End If
                    Next
                Next
            End If
            '=======================================================================

            i = 0
            Do While i <= MyDS.Tables("RecvAssets").Rows.Count - 1
                ' If this is a currently ACTIVE Asset stop
                If MyDS.Tables("RecvAssets").Rows(i)("CurrentStatus") = "ACTIVE" Then
                    errMsg &= "ACTIVE Asset with Serial# " & MyDS.Tables("RecvAssets").Rows(i)("Serial")
                    If MyDS.Tables("RecvAssets").Rows(i)("Serial") <> Request.Form("tdxSer" & CStr(i)) Then
                        errMsg &= ", ICN " & Request.Form("txtICN") & "-" & MyDS.Tables("RecvAssets").Rows(i)("ICNseq")
                    End If
                    errMsg &= " is currently at " & MyDS.Tables("RecvAssets").Rows(i)("CurrentLocation") & Chr(13)
                End If
                i += 1
            Loop


            ' stop if Active Assets have been found.
            If errMsg = "" Then
                Dim HistRemark As String = ""
                i = 0
                Do While i <= MyDS.Tables("RecvAssets").Rows.Count - 1
                    Dim UT As DateTime = Date.Now
                    '
                    ' If this Asset has not been seen before, create a new Asset else update the status
                    If MyDS.Tables("RecvAssets").Rows(i)("CurrentStatus") = "NEW" Then
                        sql = "INSERT INTO Assets ("
                        sql &= " PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber,"
                        sql &= " ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition,"
                        sql &= " LocationId, Location2, Location3, Location4, Remarks,"
                        sql &= " SubGroup, DocumentNumber, Reason, ReceivedFrom, IssuedTo,"
                        sql &= " A_Cond_Date, PackingStatus, MarkFor, ShipWeight, ShipLength, ShipWidth, ShipHeight, "
                        sql &= " EffectiveDate, LastMoved, LastTrans, LastTransDate, LastTransBy,"
                        sql &= " DateRecorded, PIN, AcceptanceDate"
                        'sql &= ") VALUES ("
                        sql &= ") SELECT "
                        'sql &= txtPid.Text.Trim & ", "      'PID,*
                        'sql &= "'" & txtPartNumber.Text.Trim & "', "        'PartNumber,*
                        'sql &= " NULL, "        'Revision,*
                        'sql &= "'" & txtNIIN.Text.Trim & "', "      'NIIN,*
                        'sql &= "'" & txtNomenclature.Text.Trim & "', "      'Nomenclature,*
                        sql &= " Pid, PartNumber, Revision, NIIN, Nomenclature, "
                        sql &= "'" & cC.BufStr(MyDS.Tables("RecvAssets").Rows(i)("Serial")).ToUpper & "', "        'SerialNumber,
                        'sql &= "'" & txtModelNumber.Text.Trim & "', "       'ModelNumber,*
                        'sql &= "'" & txtCAGE.Text.Trim & "', "       'Manufacturer,*
                        sql &= " ModelNumber, CAGE, "
                        sql &= "'" & cC.BufStr(txtICN.Text.Trim) & "', "       'ICNnum,
                        If ddlSubGroup.SelectedValue = "CICPOVHL" Then
                            If txtICN.Text.Trim <> "" Then
                                sql &= MyDS.Tables("RecvAssets").Rows(i)("ICNseq") & ", "       'ICNseq,
                            Else
                                sql &= " NULL, "         'ICNseq,
                            End If
                        Else
                            sql &= " NULL, "         'ICNseq,
                        End If
                        sql &= "'" & MyDS.Tables("RecvAssets").Rows(i)("CC") & "', "       'CurrentCondition,
                        ' " LocationId, Location2, Location3, Location4, "     'ACTIVE, WHSE, T11, .RECEIVING   
                        sql &= " 1, 5, 11, 20, "
                        'sql &= "'" & Left(cC.BufStr(txtRemarks.Text.Trim), 500) & "', "       'Remarks,
                        sql &= " NULL, "       'Remarks,
                        sql &= "'" & ddlSubGroup.SelectedValue & "', "      'SubGroup,
                        sql &= "'" & cC.BufStr(txtDocument.Text.Trim) & "', "      'DocumentNumber,
                        sql &= "'" & ddlReason.SelectedValue & "', "        'Reason,
                        sql &= "'" & cC.BufStr(txtReceivedFrom.Text.Trim) & "', "       'ReceivedFrom,
                        sql &= " NULL, "        'IssuedTo,
                        sql &= " NULL, NULL, NULL, "        'A_Cond_Date, PackingStatus, MarkFor, 
                        sql &= " NULL, NULL, NULL, NULL, "     'ShipWeight, ShipLength, ShipWidth, ShipHeight,     'start out empty
                        If IsDate(txtDate.Text) Then
                            sql &= " '" & txtDate.Text & "', '" & txtDate.Text & "', "
                        Else
                            sql &= "'" & UT.ToString & "', "      'EffectiveDate,
                            sql &= "'" & UT.ToString & "', "      'LastMoved, 
                        End If
                        sql &= " 'RECEIVED NEW ASSET', "      'LastTrans,
                        sql &= "'" & UT.ToString & "', "      'LastTransDate,
                        sql &= Session("SWMSUId") & ", "        'LastTransBy,
                        sql &= "'" & UT.ToString & "', "      'DateRecorded,
                        sql &= "'" & cC.BufStr(txtPIN.Text.Trim) & "', "       'PIN,
                        sql &= " NULL "     'AcceptanceDate
                        'sql &= ")"
                        sql &= " FROM PartsMaster WHERE Pid = " & txtPid.Text.Trim & "; "
                        sql &= " SELECT SCOPE_IDENTITY(); "

                        'Response.Write(sql)
                        'Response.Flush()
                        'get the new asset id --------------
                        Dim newId As Integer = 0
                        Dim dfId As DataTable = cC.getAsDataTable(sql, Session("SWMSDBConnection").ToString, , Session("SWMSUID"))
                        If dfId.Rows.Count > 0 Then
                            newId = dfId.Rows(0).Item(0)
                            MyDS.Tables("RecvAssets").Rows(i)("AssetId") = CStr(newId)
                        End If
                        cC.LogIt("assets", "Assets: niin:" & txtNIIN.Text & " part: " & txtPartNumber.Text & " S/N:" & MyDS.Tables("RecvAssets").Rows(i)("Serial") & " Received New ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))
                        'Response.Write("<br><br>" & sql)
                    Else
                        sql = "UPDATE Assets SET"
                        sql &= " ICNnum = '" & cC.BufStr(txtICN.Text.Trim) & "', "       'ICNnum,
                        If ddlSubGroup.SelectedValue = "CICPOVHL" Then
                            If txtICN.Text.Trim <> "" Then
                                sql &= " ICNseq = '" & MyDS.Tables("RecvAssets").Rows(i)("ICNseq") & "', "       'ICNseq,
                            Else
                                sql &= " ICNseq = NULL, "         'ICNseq,
                            End If
                        Else
                            sql &= " ICNseq = NULL, "         'ICNseq,
                        End If
                        sql &= " CurrentCondition = '" & MyDS.Tables("RecvAssets").Rows(i)("CC") & "', "       'CurrentCondition,
                        sql &= " LocationId = 1, Location2 = 5, Location3 = 11, Location4 = 20, "     'ACTIVE, WHSE, T11, Receiving
                        sql &= " Remarks = NULL, "              '" & Left(cC.BufStr(txtRemarks.Text.Trim), 500) & "', "       'Remarks,
                        sql &= " SubGroup = '" & ddlSubGroup.SelectedValue & "', "      'SubGroup,
                        sql &= " DocumentNumber = '" & cC.BufStr(txtDocument.Text.Trim) & "', "      'DocumentNumber,
                        If ddlReason.SelectedValue = "-" Then
                            sql &= " Reason = NULL, "
                        Else
                            sql &= " Reason = '" & ddlReason.SelectedValue & "', "        'Reason,
                        End If
                        sql &= " ReceivedFrom = '" & cC.BufStr(txtReceivedFrom.Text.Trim) & "', "       'ReceivedFrom,
                        sql &= " IssuedTo = NULL,"        'IssuedTo,
                        sql &= " A_Cond_Date = NULL, "        'A_Cond_Date
                        sql &= " PackingStatus = NULL, "        'PackingStatus
                        sql &= " MarkFor = NULL, "        'MarkFor
                        sql &= " ShipWeight = NULL, "       'ShipWeight start out empty
                        sql &= " ShipLength = NULL, "       'ShipLength start out empty
                        sql &= " ShipWidth = NULL, "        'ShipWidth start out empty
                        sql &= " ShipHeight = NULL, "       'ShipHeight start out empty
                        If IsDate(txtDate.Text) Then
                            sql &= " EffectiveDate = '" & txtDate.Text & "', "      'EffectiveDate,
                            sql &= " LastMoved = '" & txtDate.Text & "', "          'LastMoved,
                        Else
                            sql &= " EffectiveDate = '" & UT.ToString & "', "
                            sql &= " LastMoved = '" & UT.ToString & "', "
                        End If
                        sql &= " LastTrans = 'Received Asset',"
                        sql &= " LastTransDate = '" & UT.ToString & "', "
                        sql &= " LastTransBy = " & Session("SWMSUId") & ", "        'LastTransBy,
                        sql &= " DateRecorded = '" & UT.ToString & "', "      'DateRecorded,
                        sql &= " PIN = '" & cC.BufStr(txtPIN.Text.Trim) & "', "       'PIN,
                        sql &= " AcceptanceDate = NULL "              'AcceptanceDate
                        sql &= " FROM Assets "      'A "
                        'sql &= " INNER JOIN PartsMaster PM ON A.Pid = PM.Pid "
                        sql &= " WHERE (AssetId = " & MyDS.Tables("RecvAssets").Rows(i)("AssetId") & ")"
                        'Response.Write(sql)
                        'Response.Flush()

                        cC.executeNonQuery(sql, Session("swmsDbConnection"))
                        cC.LogIt("assets", "Assets: niin:" & txtNIIN.Text & " part: " & txtPartNumber.Text & " S/N:" & MyDS.Tables("RecvAssets").Rows(i)("Serial") & " Received ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))

                    End If

                    '/* Add Asset History Record */
                    sql = "INSERT INTO AssetHistory ("
                    sql &= " AssetId, ConditionCode,"
                    sql &= " TransType, TransDate, TransBy,"
                    sql &= " Remarks, Reason, DocumentNumber,"
                    sql &= " LocationId, Location2, Location3, Location4,"
                    sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
                    sql &= " EffectiveDate, oldAssetId, oldId,"
                    sql &= " ICNnum, ICNSeq, SubGroup, ReceivedFrom,"
                    sql &= " IssuedTo, PIN"
                    sql &= " ) VALUES ("
                    sql &= MyDS.Tables("RecvAssets").Rows(i)("AssetId") & ", "                'AssetId, int
                    sql &= "'" & MyDS.Tables("RecvAssets").Rows(i)("CC") & "', "           'ConditionCode, varchar(1)
                    sql &= "'Received Asset', "     'TransType, varchar(50)
                    sql &= "'" & UT.ToString & "', "      'TransDate, datetime
                    sql &= Session("SWMSUId") & ", "        'TransBy, int
                    'HistRemark = "RECIEVED: " & txtNIIN.Text.Trim & ", SN: " & cC.BufStr(MyDS.Tables("RecvAssets").Rows(i)("Serial")).ToUpper & ", "
                    ' & Left(cC.BufStr(txtRemarks.Text.Trim), 500) & "', "       'Remarks, varchar(500)
                    sql &= "'" & Left(cC.BufStr(MyDS.Tables("RecvAssets").Rows(i)("Remarks")).ToUpper.Trim, 500) & "', "       'Remarks, varchar(500)
                    If ddlReason.SelectedValue = "-" Then
                        sql &= " NULL, "
                    Else
                        sql &= "'" & ddlReason.SelectedValue & "', "        'Reason, varchar(50)
                    End If
                    sql &= "'" & cC.BufStr(txtDocument.Text.Trim) & "', "      'DocumentNumber, varchar(50)
                    ' " LocationId, Location2, Location3, Location4, "     'ACTIVE, WHSE, T11, .RECEIVING   
                    sql &= " 1, 5, 11, 20, "
                    sql &= " 'ACTIVE', 'WHSE', 'T11', '.RECEIVING', "
                    If txtDate.Text.Trim <> "" Then
                        If CDate(txtDate.Text.Trim) < CDate(Today) Then
                            sql &= "'" & txtDate.Text.Trim & "', "      'EffectiveDate,
                        Else
                            sql &= "'" & UT.ToString & "', "     'EffectiveDate,
                        End If
                    Else
                        sql &= "'" & UT.ToString & "', "     'EffectiveDate,
                    End If
                    sql &= " NULL, "        'oldAssetId, int
                    sql &= " NULL, "        'oldId, int
                    sql &= "'" & txtICN.Text.Trim & "', "       'ICNnum, varchar(8)
                    If ddlSubGroup.SelectedValue = "CICPOVHL" Then
                        If txtICN.Text.Trim <> "" Then
                            sql &= MyDS.Tables("RecvAssets").Rows(i)("ICNseq") & ", "       'ICNseq,
                        Else
                            sql &= "NULL, "         'ICNseq,
                        End If
                    Else
                        sql &= "NULL, "         'ICNseq,
                    End If
                    sql &= "'" & ddlSubGroup.SelectedValue & "', "      'SubGroup, varchar(20)
                    sql &= "'" & cC.BufStr(txtReceivedFrom.Text.Trim) & "', "       'ReceivedFrom, varchar(50)
                    sql &= " NULL, "        'IssuedTo, varchar(50)
                    sql &= "'" & cC.BufStr(txtPIN.Text.Trim) & "'"       'PIN, varchar(5)
                    sql &= " )"
                    '
                    cC.executeNonQuery(sql, Session("swmsDbConnection"))
                    'Response.Write("<br><br>" & sql)

                    '
                    '/* Add new row to inventory */
                    sql = "INSERT INTO InventoryLocation ("
                    sql &= " Pid, AssetId, PartNumber, NIIN, Condition_Code, Serial, ExpirationDate, LotNum,"
                    sql &= " WCN, OCN, JON, NWH, Activity, Factory, WareHouse, Bin, Quantity, ReceivedDate,"
                    sql &= " SupplierId, Supplier, Order_Number, CostValue, CreateDate, Reserved_For_ShopOrder,"
                    sql &= " ProgramID, SubProgID"
                    sql &= " ) VALUES ("
                    sql &= txtPid.Text & ", "                                           'Pid, 
                    sql &= MyDS.Tables("RecvAssets").Rows(i)("AssetId") & ", "          'AssetId
                    sql &= " '" & txtPartNumber.Text & "', "                            'PartNumber, "
                    sql &= " '" & txtNIIN.Text & "', "                                  'NIIN, "
                    sql &= "'" & MyDS.Tables("RecvAssets").Rows(i)("CC") & "', "        'Condition_Code, "
                    sql &= "'" & MyDS.Tables("RecvAssets").Rows(i)("Serial").ToUpper & "', "    'Serial, "
                    sql &= "NULL, "                                                     'ExpirationDate, "
                    If txtICN.Text.Trim <> "" Then
                        sql &= "'" & txtICN.Text.Trim & "', "       'LotNum = ICNnum,  (no ICNseq)
                    Else
                        sql &= "NULL, "         'LotNum,
                    End If
                    sql &= "NULL, NULL, NULL, NULL, NULL, "         'WCN, OCN, JON, NWH, Activity, " 
                    sql &= " '43140', "     ' Factory, "
                    sql &= " 'T11', "     'WareHouse, "
                    sql &= " 'RECEIVING', "     'Bin, "
                    sql &= " 1, "       'Quantity, "
                    If txtDate.Text.Trim <> "" Then
                        If CDate(txtDate.Text.Trim) < CDate(Today) Then
                            sql &= "'" & txtDate.Text.Trim & "', "      'ReceivedDate = EffectiveDate,
                        Else
                            sql &= "'" & UT.ToString & "', "                  'ReceivedDate = EffectiveDate,
                        End If
                    Else
                        sql &= "'" & UT.ToString & "', "                      'ReceivedDate = EffectiveDate,
                    End If
                    sql &= " NULL, "                                'SupplierId, 
                    sql &= " NULL, "                                'Supplier, 
                    sql &= "'" & txtDocument.Text.Trim & "', "      'Order_Number, 
                    sql &= " NULL, "                                'CostValue, 
                    sql &= "'" & UT.ToString & "', "                'CreateDate, 
                    sql &= " NULL, "                                'Reserved_For_ShopOrder,
                    sql &= " NULL, "                                'ProgramID, 
                    sql &= " NULL "                                 'SubProgID
                    sql &= " )"
                    '
                    cC.executeNonQuery(sql, Session("swmsDbConnection"))
                    'Response.Write("<br><br>" & sql)

                    i += 1
                Loop

                '/* Ensure that the Warehouse is syncronized with Inventory */
                '-- the assumption is that the user entered the data correctly 
                sql = "INSERT INTO Warehouses"
                sql &= " (Factory, WareHouse, Bin, MatlJON, MtlNwa, Pid, MinWipQty, MaxWipQty)"
                sql &= " SELECT IL.Factory, IL.WareHouse, IL.Bin, IL.JON, IL.NWH + IL.Activity AS MtlNwa, IL.Pid,"
                sql &= " PM.MinWipQty, PM.MaxWipQty"
                sql &= " FROM InventoryLocation IL"
                sql &= " INNER JOIN PartsMaster PM ON IL.Pid = PM.Pid"
                sql &= " LEFT OUTER JOIN Warehouses WH ON (WH.Factory = IL.Factory)"
                sql &= " AND (WH.Warehouse = IL.Warehouse)"
                sql &= " AND (WH.Bin = IL.Bin)"
                sql &= " AND (WH.MatlJON = IL.JON)"
                sql &= " AND (WH.MtlNwa = IL.NWH + IL.Activity)"
                sql &= " AND (WH.Pid = IL.Pid)"
                sql &= " WHERE (IL.Pid = " & txtPid.Text.Trim & ")	"
                sql &= " AND (WH.WHId IS NULL)"
                '
                cC.executeNonQuery(sql, Session("swmsDbConnection"))
                'Response.Write("<br><br>" & sql)

                UsrMsg.Value &= i.ToString & " Assets Received." & Chr(13)
            Else
                errMsg &= Chr(13) & "No Assets Received."
                UsrMsg.Value = errMsg
            End If
        Else
            errMsg &= Chr(13) & "No Assets Received."
            UsrMsg.Value = errMsg
        End If

        resetTop()

    End Sub

    Sub GoGetIt()
        'find the filter information to search for Assets to Issue
        sql = "SELECT Pid, NIIN, ISNULL(PrimaryPart, '0') AS PrimaryPart,"
        sql &= " (SELECT COUNT(*) AS Cnt FROM PartsMaster WHERE NIIN = '" & txtNIIN.Text.Trim & "') AS ppCnt,"
        sql &= " PartNumber, ISNULL(COG, '') AS COG,"
        sql &= " ISNULL(ModelNumber, '') AS ModelNumber, ISNULL(Nomenclature, '') AS Nomenclature,"
        sql &= " ISNULL(ProcurementCode, '') AS ProcurementCode, ISNULL(CAGE, '') AS CAGE"
        sql &= " FROM PartsMaster"
        sql &= " WHERE (Pid IS NOT NULL)"
        If txtNIIN.Text.Trim <> "" Then
            sql &= " AND (NIIN LIKE '" & txtNIIN.Text.Trim & "')"
        End If
        If txtPartNumber.Text.Trim <> "" Then
            sql &= " AND (PartNumber LIKE '" & txtPartNumber.Text.Trim & "')"
        End If

        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing
        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(sql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/TransferAssets.aspx")
            Throw ex
        Finally
            swmsDb.Close()
        End Try
        swmsDb.Dispose()
        '
        If sqldt.Rows.Count < 1 Then
            lblRowCount.Text = "Part record not found in SWMS.  Please use Find Assets."
        End If
        '
        If sqldt.Rows.Count = 1 Then
            SelTab.Visible = False
            AssetsTab.Visible = True
            '           Div1.Visible = True
            txtPid.Text = sqldt.Rows(0)("Pid")
        End If
        '
        If sqldt.Rows.Count > 1 Then
            ' show selection div to indicate which part is to be used
            Dim hr1 As New TableRow
            hr1.BackColor = Drawing.Color.FromArgb(153, 204, 255)
            '
            Dim hd1 As New TableCell
            hd1.ColumnSpan = 8
            hd1.CssClass = "smBContent"
            hd1.HorizontalAlign = HorizontalAlign.Center
            hd1.Text = "Verify Assets For Receipt *"
            hr1.Cells.Add(hd1)
            '
            SelTab.Rows.Add(hr1)
            '
            Dim hr2 As New TableRow
            hr2.BackColor = Drawing.Color.FromArgb(153, 204, 255)

            Dim td0 As New TableCell
            td0.Text = "COG"
            td0.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td0)
            '
            Dim td1 As New TableCell
            td1.Text = "NIIN"
            td1.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td1)
            '
            Dim td1p As New TableCell
            td1p.Text = "PP"
            td1p.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td1p)
            '
            Dim td2 As New TableCell
            td2.Text = "Part Number"
            td2.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td2)
            '
            Dim td3 As New TableCell
            td3.Text = "Model Number"
            td3.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td3)
            '
            Dim td4 As New TableCell
            td4.Text = "Nomenclature"
            td4.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td4)
            '
            Dim td5 As New TableCell
            td5.Text = "Manufacturer"
            td5.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td5)
            '
            Dim td6 As New TableCell
            td6.Text = "Proc. Code"
            td6.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td6)
            '
            SelTab.Rows.Add(hr2)
            '
            Dim i As Integer = 0
            Do While i <= sqldt.Rows.Count - 1

                Dim trx As New TableRow
                Dim tx0 As New TableCell
                tx0.Text = sqldt.Rows(i)("COG")
                tx0.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx0.Style.Add("cursor", "hand")
                trx.Cells.Add(tx0)
                '
                Dim tx1 As New TableCell
                tx1.Text = sqldt.Rows(i)("NIIN")
                tx1.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx1.Style.Add("cursor", "hand")
                trx.Cells.Add(tx1)
                '
                Dim tx1p As New TableCell
                If sqldt.Rows(i)("ppCnt") = 1 Or sqldt.Rows(i)("PrimaryPart") = "1" Then
                    tx1p.Text = "*"
                    tx1p.HorizontalAlign = HorizontalAlign.Center
                    tx1p.ToolTip = "* Pick Me!"
                Else
                    tx1p.Text = " "
                End If
                tx1p.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx1p.Style.Add("cursor", "hand")
                trx.Cells.Add(tx1p)
                '
                Dim tx2 As New TableCell
                tx2.Text = sqldt.Rows(i)("PartNumber")
                tx2.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx2.Style.Add("cursor", "hand")
                trx.Cells.Add(tx2)
                '
                Dim tx3 As New TableCell
                tx3.Text = sqldt.Rows(i)("ModelNumber")
                tx3.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx3.Style.Add("cursor", "hand")
                trx.Cells.Add(tx3)
                '
                Dim tx4 As New TableCell
                tx4.Text = sqldt.Rows(i)("Nomenclature")
                tx4.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx4.Style.Add("cursor", "hand")
                trx.Cells.Add(tx4)
                '
                Dim tx5 As New TableCell
                tx5.Text = sqldt.Rows(i)("CAGE")
                tx5.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx5.Style.Add("cursor", "hand")
                trx.Cells.Add(tx5)
                '
                Dim tx6 As New TableCell
                tx6.Text = sqldt.Rows(i)("ProcurementCode")
                tx6.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx6.Style.Add("cursor", "hand")
                trx.Cells.Add(tx6)
                '
                If txtPid.Text <> "" Then
                    If sqldt.Rows(i)("Pid") = txtPid.Text Then
                        trx.BackColor = System.Drawing.Color.PaleGreen
                    End If
                End If
                If sqldt.Rows(i)("PrimaryPart") = "1" Then
                    trx.BackColor = System.Drawing.Color.FromArgb(13434828)     '#CCFFCC
                    trx.ToolTip = "* This is the Primary Part for this NIIN."
                End If
                '
                SelTab.Rows.Add(trx)
                i += 1
            Loop
            SelTab.Visible = True

        End If

    End Sub

End Class
