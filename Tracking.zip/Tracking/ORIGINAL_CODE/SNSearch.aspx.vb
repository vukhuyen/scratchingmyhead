﻿Imports System.Data
Partial Class Tracking_SNSearch
    Inherits System.Web.UI.Page

#Region "declarations"
    Dim cC As New commonClass
    Dim sql As String

#End Region

#Region "Page_Load"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "jfa")
        If msg <> "" Then
            Response.Redirect(msg)
        End If

        If Not Page.IsPostBack Then
            If CStr(Request.QueryString("sn")) <> "" Then
                txtSn.Text = cC.BufStr(Request.QueryString("sn"))
                runRpt()
            End If
        End If

    End Sub 'Page_Load
#End Region

    Private Sub btnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click
        runRpt()
    End Sub

    Sub headerRow()
        Dim x1 As New TableRow

        x1.Cells.Add(cC.DataCell("Serial #", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("Part #", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(cC.DataCell("NIIN", "center", , , , "LightSteelBlue"))

        x1.CssClass = "smBContent"
        tab1.Rows.Add(x1)
    End Sub

    Sub runRpt()
        tab1.Rows.Clear()
        headerRow()

        sql = "SELECT ass.AssetId, isnull(ass.SerialNumber,'') as sn, "
        sql &= " isnull(pm.PartNumber,'') as pn, isnull(pm.NIIN,'') as niin,"
        sql &= " isnull(pm.ConditionCode,'') as cc, isnull(pm.ProcurementCode,'') as pc, "
        sql &= " isnull(locAh1.locationIdCode,'') as loc1,  "
        sql &= " isnull(locAh2.locationIdCode,'') as loc2, "
        sql &= " isnull(locAh3.locationIdCode,'') as loc3,  "
        sql &= " isnull(locAh4.locationIdCode,'') as loc4 "
        sql &= " FROM Assets AS ass "
        sql &= "    INNER JOIN PartsMaster AS pm ON ass.PID = pm.Pid "
        sql &= "    left outer join ( "
        sql &= "        select assetid, max(assethistoryid) as maxid from assethistory group by assetid "
        sql &= "    ) mah on ass.assetid = mah.assetid"
        sql &= "    left outer join assethistory ah on mah.maxid = ah.assethistoryid"
        sql &= "    left outer join locations locAh1 on ah.locationid = locAh1.locationid  "
        sql &= "    left outer join locations locAh2 on ah.location2 = locAh2.locationid  "
        sql &= "    left outer join locations locAh3 on ah.location3 = locAh3.locationid  "
        sql &= "    left outer join locations locAh4 on ah.location4 = locAh4.locationid"
        sql &= " WHERE (ass.AssetId IS NOT NULL) "
        If CStr(txtPn.Text) <> "" Then
            sql &= " AND (pm.PartNumber LIKE '" & CC.BufStr(txtPn.Text) & "%')"
        End If
        If CStr(txtSn.Text) <> "" Then
            sql &= " AND (ass.SerialNumber LIKE '" & CC.BufStr(txtSn.Text) & "%')"
        End If
        If CStr(txtNiin.Text) <> "" Then
            sql &= " AND (pm.NIIN LIKE '" & CC.BufStr(txtNiin.Text) & "%')"
        End If
        sql &= " order by serialnumber"

        Dim rt As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"), , Session("SWMSUID").ToString, "Tracking\SNSearch.aspx.vb - runRpt()")
        If rt.Rows.Count > 0 Then
            Dim i As Integer
            For i = 0 To rt.Rows.Count - 1
                Dim x1 As New TableRow

                x1.Cells.Add(cC.DataCell(rt.Rows(i)("sn"), "center"))
                x1.Cells.Add(cC.DataCell(rt.Rows(i)("pn") & "/" & rt.Rows(i)("pc") & "/" & rt.Rows(i)("pc"), "center"))
                x1.Cells.Add(cC.DataCell(rt.Rows(i)("niin"), "center"))

                x1.Attributes.Add("onmouseover", "javascript:this.className='SmContentOver';")
                x1.Attributes.Add("onmouseout", "javascript:this.className='SmContent';")
                x1.Style.Add("Cursor", "Hand")
                x1.Attributes.Add("onclick", "javascript:pickMe('" & rt.Rows(i)("AssetId") & "','" & rt.Rows(i)("sn") & "','" & rt.Rows(i)("loc1") & "','" & rt.Rows(i)("loc2") & "','" & rt.Rows(i)("loc3") & "','" & rt.Rows(i)("loc4") & "');")
                tab1.Rows.Add(x1)

            Next
        Else
            Dim x1 As New TableRow
            x1.Cells.Add(cC.DataCell("No assets found", "center", 4))
            tab1.Rows.Add(x1)
        End If


        Dim searchCriteria As String = txtPn.Text
        If searchCriteria = "" Then
            searchCriteria = "0"
        End If

    End Sub
End Class
