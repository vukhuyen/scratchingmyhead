﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Partial Class Tracking_TransferAssetsSD
    Inherits System.Web.UI.Page

    Dim sql As String = ""
    

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load

        SwmsAccess.ValidateSession()

        '- Only QA users should be able to set condition code to A (reason QA completed) auto fill A COND DATE for changes "to"  A cond. 
        sql = "SELECT TOP (1) PeopleId, FunctionClassId "
        sql &= "FROM SWMSSecurity.dbo.PeopleFunctionClasses "
        sql &= " WHERE (PeopleId = @PeopleId)"
        sql &= " AND (FunctionClassID IN (43, 47, 55, 98))"     ', 99
        ' 43-QA Inspector,  47-QA Manager, 55-Inventory/Scheduler(Specialist), 98-Database Admin

        Dim QAUser As New DataTable
        QAUser = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
            new SqlParameter("@PeopleId", Session("SWMSUId"))
        })
        '
        If QAUser.Rows.Count > 0 Then
            ddlnewCC.Enabled = True
        Else
            ddlnewCC.Enabled = False
        End If

        '     Logic needed to stop human error…
        '- For Subgroup Changes … Make History Remarks Required (authority for change needs to be recorded in History)
        '- For any condition other than A condition ... the A COND DATE should be blank 
        '- This ICN field is "volatile" and cannot be used for calculating units received, units completed for an ICN in other portion of the database.

        If Session("UserMsg") <> "" And Session("UserMsg") <> Nothing Then
            UsrMsg.Value = Session("UserMsg")
            Session("UserMsg") = ""
        End If
        lnkInv.Visible = False
 
        If Not Page.IsPostBack Then ' NEW Page
            'add required maxlength attribute to the textarea
            txtRemarks.Attributes.Add("maxlength", 500)
            txtHistRemarks.Attributes.Add("maxlength", 400)
            '
            fillLocations()
            fillddls()
            '
        Else
            If txtNomenclature.Text = "" Then
                txtNomenclature.Text = Request.Form("txtNomenclature")
            End If
            If txtModelNumber.Text = "" Then
                txtModelNumber.Text = Request.Form("txtModelNumber")
            End If
            If txtCAGE.Text = "" Then
                txtCAGE.Text = Request.Form("txtCAGE")
            End If
            '
            'If txtUpdWeight.Text = "" Then
            '    txtUpdWeight.Text = Request.Form("txtUpdWeight")
            'End If
            'If txtUpdLength.Text = "" Then
            '    txtUpdLength.Text = Request.Form("txtUpdLength")
            'End If
            'If txtUpdWidth.Text = "" Then
            '    txtUpdWidth.Text = Request.Form("txtUpdWidth")
            'End If
            'If txtUpdHeight.Text = "" Then
            '    txtUpdHeight.Text = Request.Form("txtUpdHeight")
            'End If
            '
            Dim l2Sql As String = "SELECT 0 AS LocationId, '--' AS LocationIdCode UNION SELECT LocationId, LocationIdCode FROM Locations WHERE ParentLocationId = 1"
            
            SwmsUI.LoadDropDown(ddlFilterL2, l2Sql, Nothing, False, 
            "LocationIdCode", "LocationId", ddlFilterL2.Items.IndexOf(ddlFilterL2.Items.FindByValue(Request.Form("ddlFilterL2"))))
            '
            ddlFilterL3.Items.Clear()
            ddlFilterL3.Items.Add(New ListItem("--", "0"))
            '
            Dim sel As String = Request.Form("ddlFilterL2")
            Dim idx As Integer = 0
            For idx = 0 To ddlSavLvl3.Items.Count - 1
                If ddlSavLvl3.Items(idx).Value = sel Then
                    'Split string based on @
                    Dim strArray As String() = ddlSavLvl3.Items(idx).Text.Split(New Char() {"@"c})
                    Dim lix As New ListItem(strArray(1), strArray(0))
                    ddlFilterL3.Items.Add(lix)
                End If
            Next
            ddlFilterL3.SelectedIndex = ddlFilterL3.Items.IndexOf(ddlFilterL3.Items.FindByValue(Request.Form("ddlFilterL3")))     '= "0"
            '
            ddlFilterL4.Items.Clear()
            ddlFilterL4.Items.Add(New ListItem("--", "0"))
            sel = Request.Form("ddlFilterL3")
            idx = 0
            For idx = 0 To ddlSavLvl4.Items.Count - 1
                If ddlSavLvl4.Items(idx).Value = sel Then
                    'Split string based on @
                    Dim strArray As String() = ddlSavLvl4.Items(idx).Text.Split(New Char() {"@"c})
                    Dim lix As New ListItem(strArray(1), strArray(0))
                    ddlFilterL4.Items.Add(lix)
                End If
            Next
            ddlFilterL4.SelectedIndex = ddlFilterL4.Items.IndexOf(ddlFilterL4.Items.FindByValue(Request.Form("ddlFilterL4")))     '= "0"
            '
            If txtPid.Text <> "" Then
                '
                getDimensions(txtPid.Text)
                '
                '
                If txtCommand.Text = "Trans" Then
                    LastValidation()
                    If UsrMsg.Value = "" Then
                        ' ++++++++++++++++++++++++++++++++++++++++++++++++
                        If Request.Form("ddlLocLvl4") = "- Not in List -" And txtBin.Text.Trim <> "" Then
                            ' Create new bin on the fly
                            newBin()
                        End If
                        ' ++++++++++++++++++++++++++++++++++++++++++++++++
                        TransferWhat()
                    End If
                    txtCommand.Text = ""
                    showstuff()
                End If
            Else
                If txtNIIN.Text.Trim <> "" Or txtPartNumber.Text.Trim <> "" Then
                    GoGetIt()
                End If
            End If
        End If
    End Sub

    Sub newBin()
        'Does this bin already exist?
        Dim oldId As Integer = 0
        Dim oldTxt As String = ""
        Dim ckSql As String = "SELECT LocationId FROM Locations "
        ckSql &= " WHERE (LocationIdCode = @txtBin) "
        ckSql &= " AND (ParentLocationId = @ddlLocLvl3)"

        Dim ckLoc As DataTable = SwmsAccess.ExecuteQueryToDataTable(ckSql, new SqlParameter(){
            new SqlParameter("@txtBin", Server.HtmlEncode(txtBin.Text.Trim)),
            new SqlParameter("@ddlLocLvl3", Request.Form("ddlLocLvl3"))
        })

        If ckLoc.Rows.Count > 0 Then
            'if it's there, use it.
            oldId = ckLoc.Rows(0).Item(0)
            'ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(oldId))
            ' --- CR 105 --- capture id if user enters bin that is already in list ---
            txtBin.ToolTip = oldId
            '-------------------------------------------------------------------------
        Else
            'create a new one
            Dim loSql As String = "INSERT INTO Locations "
            loSql &= "(ParentLocationID, LocationIdCode, LocationName, RecordedBy, LocationLevel)"
            loSql &= " VALUES "
            loSql &= "(@ddlLocLvl3, "
            loSql &= " @txtBin, "
            ' --- CR 105 date added truncated ---
            loSql &= "'@txtBin NEW ' + CAST(GETDATE() AS VARCHAR(11)) " & ", "
            'loSql &= "@txtBin NEW CAST(GETDATE() AS VARCHAR(11)) , "
            '-------------------------------------
            loSql &= "@PeopleId, 4) "
            loSql &= " SELECT SCOPE_IDENTITY() "

            'get the new LocationId --------------
            Dim newId As Integer = 0
            Dim dfId As DataTable = SwmsAccess.ExecuteQueryToDataTable(loSql, new SqlParameter(){
                new SqlParameter("@txtBin", Server.HtmlEncode(txtBin.Text.Trim.ToUpper)),
                new SqlParameter("@ddlLocLvl3", Request.Form("ddlLocLvl3")),
                new SqlParameter("@PeopleId", Session("SWMSUId"))
            })
            If dfId.Rows.Count > 0 Then
                newId = dfId.Rows(0).Item(0)
                txtBin.ToolTip = CStr(newId)
            End If
            ''add it to the selection lists
            'Dim tli4 As New ListItem
            'tli4.Text = txtBin.Text.Trim.ToUpper
            'tli4.Value = txtBin.ToolTip
            'ddlSavLvl4.Items.Add(tli4)
            'ddlLocLvl4.Items.Add(tli4)
            ''select it
            'ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(oldId))
        End If

    End Sub

    Sub fillddls()
        ' condition code --------------------------------------------
        ddlCc.Items.Clear()
        Dim ccSql As String = " Select '-' as SVD_Attribute UNION ALL "
        ccSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        ccSql &= " WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute"
        SwmsUI.LoadDropDown(ddlCc, ccSql, Nothing, False, "SVD_Attribute", "SVD_Attribute", "-")
        '

        SwmsUI.LoadDropDown(ddlnewCC, ccSql, Nothing, False, "SVD_Attribute", "SVD_Attribute", "-")
        '
        ' reason -------------------------------------
        'ddlReason.Items.Clear()
        Dim rSql As String = "SELECT '-' as SVD_Attribute UNION ALL "
        rSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        rSql &= " WHERE (SVD_Name = 'AssetReason') "
        rSql &= " AND (SVD_Attribute LIKE 'MOV%') "
        rSql &= " ORDER BY SVD_Attribute"

        SwmsUI.LoadDropDown(ddlReason, rSql, Nothing, False, "SVD_Attribute", "SVD_Attribute")
        '
        ' SubGroup  -------------------------------
        'ddlSubGroup.Items.Clear()
        Dim sgSql As String = "SELECT '-' AS ProgramName, '' AS ProgramType "
        sgSql &= " UNION ALL "
        sgSql &= " SELECT ProgramName, ProgramType "
        sgSql &= " FROM Programs "
        sgSql &= " ORDER BY ProgramName"
        
        SwmsUI.LoadDropDown(ddlSubGroup, sgSql, Nothing, False, "ProgramName", "ProgramName")


        SwmsUI.LoadDropDown(ddlUpdSubGroup, sgSql, Nothing, False, "ProgramName", "ProgramName")
        '
        ' Acct. Code  -------------------------------
        ddlAcctCode.Items.Clear()
        Dim sSql As String = "SELECT '-' AS ProgramType "
        sSql &= " UNION ALL "
        sSql &= " SELECT ProgramType "
        sSql &= " FROM Programs "
        sSql &= " GROUP BY ProgramType"
        sSql &= " ORDER BY ProgramType"

        SwmsUI.LoadDropDown(ddlAcctCode, sSql, Nothing, False, "ProgramType", "ProgramType")
        

        If Request.Form("ddlAcctCode") = "" Or Request.Form("ddlAcctCode") = Nothing Then
            ddlAcctCode.SelectedValue = "-"  'use - as default
        Else
            ddlAcctCode.SelectedIndex = ddlAcctCode.Items.IndexOf(ddlAcctCode.Items.FindByValue(Request.Form("ddlAcctCode")))
        End If
        '
        ' packing status -------------------------------------
        ddlPackingStatus.Items.Clear()
        Dim pSql As String = "SELECT SVD_Attribute FROM System_Validation_Dictionary "
        pSql &= " WHERE (SVD_Name = 'PackStatus') ORDER BY SVD_Attribute"

        SwmsUI.LoadDropDown(ddlPackingStatus, pSql, Nothing, False, "SVD_Attribute", "SVD_Attribute")
        ddlPackingStatus.Items.Insert(0, New ListItem("UNKNOWN blank", "UNKNOWN blank"))
        ddlPackingStatus.Items.Insert(0, New ListItem("-", "-"))
        '
        ' filter by locations
        '
        ddlFilterL2.Items.Clear()

        Dim l2Sql As String = "SELECT 0 AS LocationId, '--' AS LocationIdCode UNION SELECT LocationId, LocationIdCode FROM Locations WHERE ParentLocationId = 1"
        SwmsUI.LoadDropDown(ddlFilterL2, l2Sql, Nothing, False, "LocationIdCode", "LocationId", ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByText("--")))
        '
        '
        Dim j As Integer = 0
        ddlFilterL3.Items.Clear()
        Dim tli3 As New ListItem("--", "0")
        ddlFilterL3.Items.Add(tli3)
        '
        '
        ddlFilterL4.Items.Clear()
        Dim tli4 As New ListItem("--", "0")
        ddlFilterL4.Items.Add(tli4)

    End Sub

    Sub fillLocations()
        '
        '' location2 ----------------------------------
        ddlLocLvl2.Items.Clear()
        Dim l2Sql As String = "SELECT LocationId, LocationIdCode FROM Locations WHERE ParentLocationId = 1"
        ddlLocLvl2.DataSource = SwmsAccess.ExecuteQueryToDataTable(l2Sql, Nothing)
        ddlLocLvl2.DataValueField = "LocationId"
        ddlLocLvl2.DataTextField = "LocationIdCode"
        ddlLocLvl2.DataBind()
        '
        ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByText("WHSE"))


        ' ddlLocLvl2.Items.Clear()
        ' Dim l2Sql As String = "SELECT LocationId, LocationIdCode FROM Locations WHERE ParentLocationId = 1"
        
        ' SwmsUI.LoadDropDown(ddlLocLvl2, l2Sql, Nothing, False, "LocationIdCode", "LocationId")
        ' ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByText("WHSE"))


        ' Sub -------------- "Building" -------------------
        ddlSavLvl3.Items.Clear()
        Dim sql3 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql3 &= " WHERE (LocationLevel = 3)"
        sql3 &= " ORDER BY LocationIdCode"
        Dim rtn3 As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql3, Nothing)
        ddlSavLvl3.DataSource = rtn3
        ddlSavLvl3.DataValueField = "ParentLocationID"
        ddlSavLvl3.DataTextField = "Code"
        ddlSavLvl3.DataBind()
        '
        Dim j As Integer = 0
        ddlLocLvl3.Items.Clear()
        Dim tli3 As New ListItem
        tli3.Text = "--"
        tli3.Value = "0"
        ddlLocLvl3.Items.Add(tli3)
        ' Populate the control after the data record has been read
        For i As Integer = 0 To rtn3.Rows.Count - 1
            If rtn3.Rows(i)("ParentLocationID") = ddlLocLvl2.SelectedValue Then
                j = InStr(rtn3.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn3.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn3.Rows(i)("Code"), j + 1)
                ddlLocLvl3.Items.Add(litm)
            End If
        Next
        '
        ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByText("T11"))


        ' Micro -------------- "Bin" -------------------
        ddlSavLvl4.Items.Clear()
        Dim sql4 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql4 &= " WHERE (LocationLevel = 4)"
        sql4 &= " ORDER BY LocationIdCode"
        Dim rtn4 As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql4, Nothing)
        ddlSavLvl4.DataSource = rtn4
        ddlSavLvl4.DataValueField = "ParentLocationID"
        ddlSavLvl4.DataTextField = "Code"
        ddlSavLvl4.DataBind()
        '
        j = 0
        ddlLocLvl4.Items.Clear()
        Dim tli4 As New ListItem
        tli4.Text = "--"
        tli4.Value = "0"
        ddlLocLvl4.Items.Add(tli4)
        ' Populate the control after the data record has been read
        For i As Integer = 0 To rtn4.Rows.Count - 1
            If rtn4.Rows(i)("ParentLocationID") = ddlLocLvl3.SelectedValue Then
                j = InStr(rtn4.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn4.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn4.Rows(i)("Code"), j + 1)
                ddlLocLvl4.Items.Add(litm)
            End If
        Next
        ddlLocLvl4.Items.Add(New ListItem("- Not in List -"))
        '
        ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByText("--"))

'


    End Sub

    Sub getDimensions(ByVal pid As String)
        If txtUpdWeight.Text = "" Then
            Dim getdim As String
            getdim = "SELECT"
            getdim &= " ISNULL(PM.ShipWeight, 0.00) AS MasterWeight,"
            getdim &= " ISNULL(PM.ShipLength, 0.00) AS MasterLength,"
            getdim &= " ISNULL(PM.ShipWidth, 0.00) AS MasterWidth,"
            getdim &= " ISNULL(PM.ShipHeight, 0.00) AS MasterHeight"
            getdim &= " FROM PartsMaster PM"
            getdim &= " WHERE(PM.Pid = @Pid)"
            
            Dim sqldt As DataTable = SwmsAccess.ExecuteQueryToDataTable(getdim, new SqlParameter(){
                new SqlParameter("@Pid", txtPid.Text)
            })


            If sqldt.Rows.Count > 0 Then
                lblWeight.ToolTip = FormatNumber(UCase(sqldt.Rows(0)("MasterWeight")), 0, , , False)
                lblLength.ToolTip = FormatNumber(UCase(sqldt.Rows(0)("MasterLength")), 0, , , False)
                lblWidth.ToolTip = FormatNumber(UCase(sqldt.Rows(0)("MasterWidth")), 0, , , False)
                lblHeight.ToolTip = FormatNumber(UCase(sqldt.Rows(0)("MasterHeight")), 0, , , False)
            End If
            '
        End If
    End Sub

    Sub GoGetIt()
        'find the filter information to search for Assets to Issue
        sql = "SELECT Pid, NIIN, PartNumber, ISNULL(COG, '') AS COG, "
        sql &= " ISNULL(ModelNumber, '') AS ModelNumber, ISNULL(Nomenclature, '') AS Nomenclature, "
        sql &= " ISNULL(ProcurementCode, '') AS ProcurementCode, ISNULL(CAGE, '') AS CAGE "
        sql &= " FROM PartsMaster "
        sql &= " WHERE (Pid IS NOT NULL) "
        If txtNIIN.Text.Trim <> "" Then
            sql &= " AND (NIIN LIKE @NIIN) "
        End If
        If txtPartNumber.Text.Trim <> "" Then
            sql &= " AND (PartNumber LIKE @PartNumber) "
        End If

        
        Dim sqldt As DataTable = Nothing
        Try
            sqldt = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
                new SqlParameter("@NIIN", txtNIIN.text.Trim),
                new SqlParameter("@PartNumber", txtPartNumber.text.Trim)
            })
        Catch ex as Exception
            throw ex
        End Try
        '
        If sqldt.Rows.Count = 1 Then
            SelTab.Visible = False
            AssetsTab.Visible = True
            '           Div1.Visible = True
            txtPid.Text = sqldt.Rows(0)("Pid")
            getDimensions(txtPid.Text)
        End If
        '
        If sqldt.Rows.Count > 1 Then
            ' show selection div to indicate which part is to be used
            Dim hr1 As New TableRow
            hr1.BackColor = Drawing.Color.FromArgb(153, 204, 255)
            '
            Dim hd1 As New TableCell
            hd1.ColumnSpan = 7
            hd1.CssClass = "smBContent"
            hd1.HorizontalAlign = HorizontalAlign.Center
            hd1.Text = "Verify Assets For Transfer"
            hr1.Cells.Add(hd1)
            '
            SelTab.Rows.Add(hr1)
            '
            Dim hr2 As New TableRow
            hr2.BackColor = Drawing.Color.FromArgb(153, 204, 255)

            Dim td0 As New TableCell
            td0.Text = "COG"
            td0.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td0)
            '
            Dim td1 As New TableCell
            td1.Text = "NIIN"
            td1.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td1)
            '
            Dim td2 As New TableCell
            td2.Text = "Part Number"
            td2.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td2)
            '
            Dim td3 As New TableCell
            td3.Text = "Model Number"
            td3.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td3)
            '
            Dim td4 As New TableCell
            td4.Text = "Nomenclature"
            td4.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td4)
            '
            Dim td5 As New TableCell
            td5.Text = "Manufacturer"
            td5.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td5)
            '
            Dim td6 As New TableCell
            td6.Text = "Proc. Code"
            td6.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td6)
            '
            SelTab.Rows.Add(hr2)
            '
            Dim i As Integer = 0
            Do While i <= sqldt.Rows.Count - 1

                Dim trx As New TableRow
                Dim tx0 As New TableCell
                tx0.Text = sqldt.Rows(i)("COG")
                tx0.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx0.Style.Add("cursor", "hand")
                trx.Cells.Add(tx0)
                '
                Dim tx1 As New TableCell
                tx1.Text = sqldt.Rows(i)("NIIN").ToString()
                tx1.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx1.Style.Add("cursor", "hand")
                trx.Cells.Add(tx1)
                '
                Dim tx2 As New TableCell
                tx2.Text = sqldt.Rows(i)("PartNumber")
                tx2.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx2.Style.Add("cursor", "hand")
                trx.Cells.Add(tx2)
                '
                Dim tx3 As New TableCell
                tx3.Text = sqldt.Rows(i)("ModelNumber")
                tx3.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx3.Style.Add("cursor", "hand")
                trx.Cells.Add(tx3)
                '
                Dim tx4 As New TableCell
                tx4.Text = sqldt.Rows(i)("Nomenclature")
                tx4.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx4.Style.Add("cursor", "hand")
                trx.Cells.Add(tx4)
                '
                Dim tx5 As New TableCell
                tx5.Text = sqldt.Rows(i)("CAGE")
                tx5.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx5.Style.Add("cursor", "hand")
                trx.Cells.Add(tx5)
                '
                Dim tx6 As New TableCell
                tx6.Text = sqldt.Rows(i)("ProcurementCode")
                tx6.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx6.Style.Add("cursor", "hand")
                trx.Cells.Add(tx6)
                '
                If txtPid.Text <> "" Then
                    If sqldt.Rows(i)("Pid") = txtPid.Text Then
                        trx.BackColor = System.Drawing.Color.PaleGreen
                    End If
                End If
                '
                SelTab.Rows.Add(trx)
                i += 1
            Loop
            SelTab.Visible = True

        End If

    End Sub

    Protected Sub btnSho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSho.Click
        Showstuff()
    End Sub

    Sub showstuff()
        If txtPid.Text <> "" Then
            '
            sql = "SELECT  "
            sql &= " A.AssetId, A.Pid, A.PartNumber, A.NIIN, A.Nomenclature, ISNULL(A.ModelNumber, '') AS ModelNumber, ISNULL(A.Manufacturer, '') AS CAGE, ISNULL(PM.COG, '') AS COG, "
            sql &= " ISNULL(L2.LocationIdCode, '') AS Locality, ISNULL(L3.LocationIdCode, '') AS Bldg, ISNULL(L4.LocationIdCode , '') AS Bin,"
            sql &= " ISNULL(A.SerialNumber, '') AS SerialNumber, ISNULL(A.ICNnum, '') AS ICNnum,  ISNULL(A.ICNseq, 0) AS ICNseq, "
            sql &= " ISNULL(A.CurrentCondition, '') AS CurrentCondition, ISNULL(A.SubGroup, '') AS SubGroup, ISNULL(A.PIN, '') AS Acct, "
            'sql &= " ISNULL(A.DocumentNumber, '') AS DocumentNumber, "
            sql &= " ISNULL(A.MarkFor, '') AS MarkFor,"
            sql &= " ISNULL(A.PackingStatus, '') AS PackingStatus,"
            sql &= " ISNULL(A.ShipWeight, 0.00) AS ShipWeight,"
            sql &= " ISNULL(A.ShipLength, 0.00) AS ShipLength,"
            sql &= " ISNULL(A.ShipWidth, 0.00) AS ShipWidth,"
            sql &= " ISNULL(A.ShipHeight, 0.00) AS ShipHeight,"
            sql &= " ISNULL(PM.ShipWeight, 0.00) AS MasterWeight,"
            sql &= " ISNULL(PM.ShipLength, 0.00) AS MasterLength,"
            sql &= " ISNULL(PM.ShipWidth, 0.00) AS MasterWidth,"
            sql &= " ISNULL(PM.ShipHeight, 0.00) AS MasterHeight,"
            sql &= " ISNULL(A.Remarks, '') AS AssetNotes,"

            sql &= " ISNULL(A.LocationId, '') AS LocationId, ISNULL(A.Location2, '') AS Location2, "
            sql &= " ISNULL(A.Location3, '') AS Location3, ISNULL(A.Location4, '') AS Location4 "
            sql &= " FROM Assets A "
            sql &= " INNER JOIN PartsMaster PM ON A.Pid = PM.Pid "
            sql &= " INNER JOIN Locations L2 ON A.Location2 = L2.LocationId	"   '/* warehouse/shop */"
            sql &= " INNER JOIN Locations L3 ON A.Location3 = L3.LocationId	"   '/* bldg/code */"
            sql &= " INNER JOIN Locations L4 ON A.Location4 = L4.LocationId	"   '/* bin */"
            sql &= " WHERE (A.LocationId = 1) AND (A.Pid = @Pid) "

            If txtSerial.Text <> "" Then
                sql &= " AND (A.SerialNumber LIKE @SerialNumber) "
            End If
            If txtICN.Text <> "" Then
                sql &= " AND (A.ICNnum LIKE @txtICN) "
            End If
            If ddlCc.SelectedValue <> "-" Then
                sql &= " AND (A.CurrentCondition = @ddlCc) "
            End If
            If ddlSubGroup.SelectedItem.Text <> "-" Then
                sql &= " AND (A.SubGroup = @ddlSubGroup) "
            End If
            If Request.Form("ddlAcctCode") <> "-" Then
                sql &= " AND (A.PIN = @ddlAcctCode) "
            End If
            If Request.Form("ddlFilterL2") <> "0" Then
                sql &= " AND (A.Location2 = @ddlFilterL2) "
                If Request.Form("ddlFilterL3") <> "0" Then
                    sql &= " AND (A.Location3 = @ddlFilterL3) "
                    If Request.Form("ddlFilterL4") <> "0" Then
                        sql &= " AND (A.Location4 = @ddlFilterL4) "
                    End If
                End If
            End If
            sql &= " ORDER BY A.SerialNumber"


            Dim swmsDb As New SqlConnection
            Dim sqldt As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
                new SqlParameter("@Pid", txtPid.text),
                new SqlParameter("@SerialNumber", txtSerial.text),
                new SqlParameter("@txtICN", txtICN.text),
                new SqlParameter("@ddlCc", ddlCc.SelectedValue),
                new SqlParameter("@ddlSubGroup", ddlSubGroup.SelectedItem.Text),
                new SqlParameter("@ddlAcctCode", Request.Form("ddlAcctCode")),
                new SqlParameter("@ddlFilterL2", Request.Form("ddlFilterL2")),
                new SqlParameter("@ddlFilterL3", Request.Form("ddlFilterL3")),
                new SqlParameter("@ddlFilterL4", Request.Form("ddlFilterL4"))
            })
            

            If sqldt.Rows.Count > 0 Then
                lblRowCount.Text = sqldt.Rows.Count.ToString & " Assets found.  Use checkbox to transfer asset."
                '
                txtNIIN.Text = sqldt.Rows(0)("NIIN")
                txtPartNumber.Text = sqldt.Rows(0)("PartNumber")
                txtNomenclature.Text = sqldt.Rows(0)("Nomenclature")
                txtModelNumber.Text = sqldt.Rows(0)("ModelNumber")
                txtCAGE.Text = sqldt.Rows(0)("CAGE")
                txtCOG.Text = sqldt.Rows(0)("COG")

                Dim hdr As New TableRow
                Dim hc0 As New TableCell
                hc0.Text = "Transfer"
                hdr.Cells.Add(hc0)
                '  
                Dim hc4 As New TableCell
                hc4.Text = "Serial Number"
                hdr.Cells.Add(hc4)
                '
                Dim hc5 As New TableCell
                hc5.Text = "ICN"
                hdr.Cells.Add(hc5)
                '
                Dim hc6 As New TableCell
                hc6.Text = "CC"
                hdr.Cells.Add(hc6)
                '
                Dim hc7 As New TableCell
                hc7.Text = "SubGroup"
                hdr.Cells.Add(hc7)
                '
                Dim hc8 As New TableCell
                hc8.Text = "Mark For"
                hdr.Cells.Add(hc8)
                '
                Dim hc9 As New TableCell
                hc9.Text = "Packing Status"
                hdr.Cells.Add(hc9)
                '
                Dim hcA As New TableCell
                hcA.Text = "Dimensions"
                hdr.Cells.Add(hcA)
                '
                'Dim hcB As New TableCell
                'hcB.Text = "Length"
                'hdr.Cells.Add(hcB)
                ''
                'Dim hcC As New TableCell
                'hcC.Text = "Width"
                'hdr.Cells.Add(hcC)
                ''
                'Dim hcD As New TableCell
                'hcD.Text = "Height"
                'hdr.Cells.Add(hcD)
                '
                Dim hcE As New TableCell
                hcE.Text = "Asset Notes"
                hdr.Cells.Add(hcE)
                '
                Dim hc1 As New TableCell
                hc1.Text = "Location"
                hdr.Cells.Add(hc1)
                '
                Dim hc2 As New TableCell
                hc2.Text = "Bldg"
                hdr.Cells.Add(hc2)
                '
                Dim hc3 As New TableCell
                hc3.Text = "Bin"
                hdr.Cells.Add(hc3)
                '
                hdr.BackColor = Drawing.Color.FromArgb(255, 153, 204, 255) 'Hex={99,CC,FF}
                AssetsTab.Rows.Add(hdr)
                '
                Dim altRow As Boolean = False
                Dim idx As Integer = 0
                Do While idx <= sqldt.Rows.Count - 1

                    Dim trx As New TableRow
                    trx.ID = "trx" & sqldt.Rows(idx)("AssetId")

                    Dim tc0 As New TableCell
                    tc0.Text = "<input type='checkbox' name='checked' id='cbx" & sqldt.Rows(idx)("AssetId") & "'"
                    tc0.Text &= " value='cbx" & sqldt.Rows(idx)("AssetId") & "' title='" & sqldt.Rows(idx)("AssetId") & "'"
                    If sqldt.Rows.Count > 1 Then
                        tc0.Text &= " onclick='javascript:howManyChecked(form1.checked); lightRow(this);' "
                    End If
                    tc0.Text &= "/>"
                    tc0.Style.Add("cursor", "hand")
                    trx.Cells.Add(tc0)
                    '
                    Dim tc4 As New TableCell
                    tc4.Text = sqldt.Rows(idx)("SerialNumber")
                    trx.Cells.Add(tc4)
                    '
                    Dim tc5 As New TableCell
                    If sqldt.Rows(idx)("SubGroup") = "CICPOVHL" And sqldt.Rows(idx)("ICNnum") <> "0" Then
                        tc5.Text = sqldt.Rows(idx)("ICNnum") & "-" & Right("0000" & CStr(sqldt.Rows(idx)("ICNseq")), 4)
                    Else
                        tc5.Text = sqldt.Rows(idx)("ICNnum")
                    End If
                    trx.Cells.Add(tc5)
                    '
                    Dim tc6 As New TableCell
                    tc6.Text = sqldt.Rows(idx)("CurrentCondition")
                    trx.Cells.Add(tc6)
                    '
                    Dim tc7 As New TableCell
                    tc7.Text = sqldt.Rows(idx)("SubGroup")
                    trx.Cells.Add(tc7)
                    '
                    Dim tc8 As New TableCell
                    tc8.Text = sqldt.Rows(idx)("MarkFor")
                    trx.Cells.Add(tc8)
                    '
                    Dim tc9 As New TableCell
                    tc9.Text = sqldt.Rows(idx)("PackingStatus")
                    trx.Cells.Add(tc9)
                    '
                    Dim tcA As New TableCell
                    tcA.Text = FormatNumber(UCase(sqldt.Rows(idx)("ShipWeight")), 0, , , False) & "lbs, "
                    tcA.Text &= FormatNumber(UCase(sqldt.Rows(idx)("ShipLength")), 0, , , False) & "x"
                    tcA.Text &= FormatNumber(UCase(sqldt.Rows(idx)("ShipWidth")), 0, , , False) & "x"
                    tcA.Text &= FormatNumber(UCase(sqldt.Rows(idx)("ShipHeight")), 0, , , False)
                    trx.Cells.Add(tcA)
                    '
                    Dim tcE As New TableCell
                    tcE.Text = sqldt.Rows(idx)("AssetNotes")
                    trx.Cells.Add(tcE)
                    '
                    Dim tc1 As New TableCell
                    tc1.Text = sqldt.Rows(idx)("Locality")
                    trx.Cells.Add(tc1)
                    '
                    Dim tc2 As New TableCell
                    tc2.Text = sqldt.Rows(idx)("Bldg")
                    trx.Cells.Add(tc2)
                    '
                    Dim tc3 As New TableCell
                    tc3.Text = sqldt.Rows(idx)("Bin")
                    trx.Cells.Add(tc3)

                    'If altRow = True Then      this interfers with the checkbox row highlight function
                    '    trx.BackColor = System.Drawing.Color.WhiteSmoke
                    '    altRow = False
                    'Else
                    '    altRow = True
                    'End If
                    If TxtAid.Text = CStr(sqldt.Rows(idx)("AssetId")) Then
                        trx.BackColor = Drawing.Color.LightSteelBlue
                    End If
                    AssetsTab.Rows.Add(trx)

                    idx += 1
                Loop
                '
                Dim db2 As New TableRow
                Dim bspn As New TableCell
                bspn.ColumnSpan = 3
                If sqldt.Rows.Count > 1 Then
                    Dim btnCka As New HtmlButton
                    btnCka.InnerText = "Check All"
                    btnCka.Attributes.Add("class", "SmContent")
                    btnCka.Attributes.Add("onClick", "checkAll(form1.checked)")
                    btnCka.ID = "btnCheckAll" '& FormatDateTime(savStartDate, DateFormat.ShortDate)
                    bspn.Controls.Add(btnCka)
                    Dim btnUnCka As New HtmlButton
                    btnUnCka.InnerText = "UnCheck All"
                    btnUnCka.Attributes.Add("class", "SmContent")
                    btnUnCka.Attributes.Add("onClick", "uncheckAll(form1.checked)")
                    btnUnCka.ID = "btnUnCheckAll" '& FormatDateTime(savStartDate, DateFormat.ShortDate)
                    bspn.Controls.Add(btnUnCka)
                Else
                    bspn.Text = "&nbsp;"
                End If
                db2.Cells.Add(bspn)

                Dim fspn As New TableCell
                fspn.ColumnSpan = 12
                Dim btnSubmit As New HtmlButton
                btnSubmit.ID = "btnSub"
                btnSubmit.InnerText = "Submit List"
                btnSubmit.Attributes.Add("class", "SmContent")
                btnSubmit.Attributes.Add("onclick", "javascript:validateMe();")
                fspn.Controls.Add(btnSubmit)
                'fspn.Text = "&nbsp;"
                db2.Cells.Add(fspn)
                db2.BorderColor = Drawing.Color.SteelBlue

                AssetsTab.Rows.Add(db2)

                DataTable.Visible = True
                AssetsTab.Visible = True
                '
                'list available Asset Locations 
                fillLocations()

            Else
                lblRowCount.Text = "0 Assets found."
                
            End If
        Else
            UsrMsg.Value = "Please use filters above to select an Asset."
            Dim msql As String
            msql = "DELETE Memories WHERE (Page = 'Msg') AND (UserId = @PeopleId);"
            msql &= " INSERT INTO Memories ("
            msql &= " UserId, Page, FieldName, [Value]) VALUES (@PeopleId, 'Msg','UsrMsg', @UsrMsg);"
            msql &= " INSERT INTO Memories ("
            msql &= " UserId, Page, FieldName, [Value]) VALUES (@PeopleId, 'Msg', 'class', 'error');"

            SwmsAccess.ExecuteNonQuery(msql, new SqlParameter(){
                new SqlParameter("@PeopleId", Session("SWMSUId")),
                new SqlParameter("@UsrMsg", UsrMsg.Value)
            })
        End If
        TxtAid.Text = ""
    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect("./TransferAssetsSD.aspx")
    End Sub

    Sub LastValidation()
        ' start off clean
        ddlLocLvl3.BackColor = Drawing.Color.White
        ddlLocLvl4.BackColor = Drawing.Color.White
        ddlReason.BackColor = Drawing.Color.White
        txtICN.BackColor = Drawing.Color.White
        txtMarkFor.BackColor = Drawing.Color.White
        ddlPackingStatus.BackColor = Drawing.Color.White
        txtUpdWeight.BackColor = Drawing.Color.White
        txtUpdLength.BackColor = Drawing.Color.White
        txtUpdWeight.BackColor = Drawing.Color.White
        txtUpdHeight.BackColor = Drawing.Color.White
        txtDate.BackColor = Drawing.Color.White
        ddlUpdSubGroup.BackColor = Drawing.Color.White
        txtRemarks.BackColor = Drawing.Color.White
        txtHistRemarks.BackColor = Drawing.Color.White
        '
        Dim errMsg As String = ""

        'Location   always something
        'If ddlLocLvl2.SelectedIndex <= 0 Then
        '    errMsg &= "Location To is required." & Chr(13)
        '    ddlLocLvl2.BackColor = Drawing.Color.MistyRose
        'End If
        'Bldg
        'If ddlLocLvl3.SelectedIndex <= 0 Then
        '    errMsg &= "Building To is required." & Chr(13)
        '    ddlLocLvl3.BackColor = Drawing.Color.MistyRose
        'End If
        ''Bin
        'If ddlLocLvl4.SelectedIndex <= 0 Then
        '    If txtBin.Text.Trim = "" Then
        '        errMsg &= "Bin To is required." & Chr(13)
        '        ddlLocLvl4.BackColor = Drawing.Color.MistyRose
        '    End If
        'End If

        'Remarks are optional... the page will supply some remarks
        'If txtRemarks.Text.Trim = "" Then
        '    errMsg &= "Remarks are required." & Chr(13)
        '    txtRemarks.BackColor = Drawing.Color.MistyRose
        'End If

        'Reason ?
        If ddlReason.SelectedIndex <= 0 Then
            errMsg &= "Please select a reason." & Chr(13)
            ddlReason.BackColor = Drawing.Color.MistyRose
        End If
        'possible date
        If txtDate.Text.Trim <> "" Then
            If Not IsDate(txtDate.Text) Then
                errMsg &= "Please use date format mm/dd/yyyy." & Chr(13)
                txtDate.BackColor = Drawing.Color.MistyRose
            End If
        End If
        '     Logic needed to stop human error…
        '- For Subgroup Changes … Make History Remarks Required (authority for change needs to be recorded in History)
        If ddlUpdSubGroup.SelectedValue <> "-" Then
            If txtHistRemarks.Text.Trim.Length < 1 Then
                errMsg &= "Authority for change of SubGroup needs to be recorded in History Remarks." & Chr(13)
                txtHistRemarks.BackColor = Drawing.Color.MistyRose
            End If
        End If
        '
        If errMsg <> "" Then
            UsrMsg.Value &= errMsg
            Dim msql As String
            msql = "DELETE Memories WHERE (Page = 'Msg') AND (UserId = @PeopleId);"
            msql &= " INSERT INTO Memories ("
            msql &= " UserId, Page, FieldName, [Value]) VALUES (@PeopleId, 'Msg', 'UsrMsg', '@UserMsg');"
            msql &= " INSERT INTO Memories ("
            msql &= " UserId, Page, FieldName, [Value]) VALUES (@PeopleId, 'Msg', 'class', 'error');"

            SwmsAccess.ExecuteNonQuery(msql, new SqlParameter(){
                new SqlParameter("@PeopleId", Session("SWMSUId")),
                new SqlParameter("@UserMsg", Left(UsrMsg.Value, 100))
            })
        End If
    End Sub

    Sub TransferWhat()
        Dim Selected As Boolean = False
        Dim i, j, k As Integer
        Dim s, ss As String
        Dim arr1(), arr2() As String        ', arr3()
        Dim coll As Collections.Specialized.NameValueCollection

        k = 0
        coll = Request.Form '// Load Form collection into NameValueCollection object.
        arr1 = coll.AllKeys   '// Put names of all keys into a string array.
        For i = 0 To arr1.Length - 1
            If arr1(i) = "checked" Then 'name of CheckBox Group
                arr2 = coll.GetValues(i)    '// Get all values under this key.
                For j = 0 To arr2.Length - 1
                    s = arr2(j)
                    ss = s.Substring(3)
                    buildTrans(ss)
                    k += 1
                Next
            End If
        Next
        '
        If k = 0 Then
            UsrMsg.Value &= "No Assets Transfered."
        ElseIf k = 1 Then
            UsrMsg.Value &= "1 Asset Transfered."
        Else
            UsrMsg.Value &= k.ToString & " Assets Transfered."
        End If
        '
        Dim msql As String
        msql = "DELETE Memories WHERE (Page = 'Msg') AND (UserId = @PeopleId);"
        msql &= " INSERT INTO Memories ("
        msql &= " UserId, Page, FieldName, [Value]) VALUES (@PeopleId, 'Msg', 'UsrMsg', @UserMsg);"
        msql &= " INSERT INTO Memories ("
        If k > 0 Then
            msql &= " UserId, Page, FieldName, [Value]) VALUES (@PeopleId, 'Msg', 'class', 'normal');"
        Else
            msql &= " UserId, Page, FieldName, [Value]) VALUES (@PeopleId, 'Msg', 'class', 'special');"
        End If

        SwmsAccess.ExecuteNonQuery(msql, new SqlParameter(){
                new SqlParameter("@PeopleId", Session("SWMSUId")),
                new SqlParameter("@UserMsg", UsrMsg.Value)
        })
        '
        'Reset fields...    clear out the updateable fields to prevent "tag-alongs"
        ddlnewCC.SelectedValue = "-"
        fillLocations()
        'ddlLocLvl2.SelectedValue = "WHSE"
        'ddlLocLvl3.SelectedValue = "--"
        'ddlLocLvl4.SelectedValue = "--"
        ddlReason.SelectedValue = "-"
        txtACondition.Text = ""
        txtUpdICN.Text = ""
        txtMarkFor.Text = ""
        ddlPackingStatus.SelectedValue = "-"
        txtUpdWeight.Text = ""
        txtUpdLength.Text = ""
        txtUpdWidth.Text = ""
        txtUpdHeight.Text = ""
        txtDate.Text = ""
        ddlUpdSubGroup.SelectedValue = "-"
        txtHistRemarks.Text = ""
        txtRemarks.Text = ""
        '
    End Sub

    Sub buildTrans(ByVal ThisId As String)
        Dim Loc1Text As String = ""
        Dim Loc2Text As String = ""
        Dim Loc3Text As String = ""
        Dim Loc4Text As String = ""
        Dim lSql As String = "SELECT MAX(L1) AS L1, MAX(L2) AS L2, MAX(L3) AS L3, MAX(L4) AS L4 FROM ("
        lSql &= " SELECT ISNULL(LocationIdCode, '') AS L1, NULL AS L2, NULL AS L3, NULL AS L4 FROM Locations WHERE LocationIdCode = 'ACTIVE'"
        lSql &= " UNION"
        lSql &= " SELECT NULL AS L1, ISNULL(LocationIdCode, '') AS L2, NULL AS L3, NULL AS L4 FROM Locations WHERE LocationId = @ddlLocLvl2"
        lSql &= " UNION"
        lSql &= " SELECT NULL AS L1, NULL AS L2, ISNULL(LocationIdCode, '') AS L3, NULL AS L4 FROM Locations WHERE LocationId = @ddlLocLvl3 "
        lSql &= " UNION"

        If Request.Form("ddlLocLvl4") = "- Not in List -" Or Request.Form("ddlLocLvl4") = Nothing Then
            If txtBin.Text.Trim <> "" Then
                lSql &= " SELECT NULL AS L1, NULL AS L2, NULL AS L3, @txtBin AS L4 "
            Else
                lSql &= " SELECT NULL AS L1, NULL AS L2, NULL AS L3, 'UNKNOWN' AS L4 "
            End If
        Else
            lSql &= " SELECT NULL AS L1, NULL AS L2, NULL AS L3, ISNULL(LocationIdCode, '') AS L4 FROM Locations WHERE (LocationId = @ddlLocLvl4)"
        End If
        lSql &= " ) A1"
        Dim dtLoc As DataTable = SwmsAccess.ExecuteQueryToDataTable(lSql, new SqlParameter(){
                new SqlParameter("@ddlLocLvl2", Request.Form("ddlLocLvl2")),
                new SqlParameter("@ddlLocLvl3", Request.Form("ddlLocLvl3")),
                new SqlParameter("@ddlLocLvl4", Request.Form("ddlLocLvl4")),
                new SqlParameter("@txtBin", Server.HtmlEncode(txtBin.Text))
        })

        If dtLoc.Rows.Count > 0 Then
            Loc1Text = dtLoc.Rows(0).Item("L1")
            Loc2Text = dtLoc.Rows(0).Item("L2")
            Loc3Text = dtLoc.Rows(0).Item("L3")
            Loc4Text = dtLoc.Rows(0).Item("L4")
        End If

        ' get serial number for log 
        Dim sSql As String = "SELECT A.AssetId, A.SerialNumber, "
        sSql &= " ISNULL(A.CurrentCondition, '') AS CurrentCondition, A_Cond_Date, "
        sSql &= " ISNULL(SubGroup, '') AS SubGroup, "
        sSql &= " ISNULL(PIN, '') AS PIN, "
        sSql &= " ISNULL(PackingStatus, '') AS PackingStatus, "
        sSql &= " ISNULL(ICNnum, '') AS ICNnum, "
        sSql &= " ISNULL(ICNseq, 0) AS ICNseq, "
        sSql &= " ISNULL(MarkFor, '') AS MarkFor, "
        sSql &= " ISNULL(Remarks, '') AS Remarks, "
        sSql &= " ISNULL(ShipWeight, 0) AS ShipWeight, "
        sSql &= " ISNULL(ShipLength, 0) AS ShipLength, "
        sSql &= " ISNULL(ShipWidth, 0) AS ShipWidth, "
        sSql &= " ISNULL(ShipHeight, 0) AS ShipHeight, "
        sSql &= " ISNULL(L2.LocationIdCode, '') AS Location, "
        sSql &= " ISNULL(L3.LocationIdCode, '') AS Warehouse, ISNULL(L4.LocationIdCode, '') AS Bin"
        sSql &= " FROM Assets A"
        sSql &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationId"
        sSql &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationId"
        sSql &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationId"
        sSql &= " WHERE  (AssetId = @ThisId); "

        
        Dim sqldt As DataTable = SwmsAccess.ExecuteQueryToDataTable(sSql, new SqlParameter(){
            new SqlParameter("@ThisId", ThisId)
        })

        Dim mSql As String = ""     'Transfer / Move Transaction
        Dim cSql As String = ""     'Change Condition Code Transaction
        Dim uSql As String = ""     'Update Other Transaction
        ' update Asset
        sql = "DECLARE @RightNow as datetime; "
        sql &= "SELECT @RightNow = Getdate(); "



        mSql = " UPDATE Assets SET "
        mSql &= " LocationId = 1,"   '-- ACTIVE
        mSql &= " Location2 = @ddlLocLvl2, "  'Location
        mSql &= " Location3 = @ddlLocLvl3, "  'Building
        If Request.Form("ddlLocLvl4") = "- Not in List -" Then
            If txtBin.ToolTip = "" Then
                mSql &= " Location4 = 0, "  'Bin
            Else
                mSql &= " Location4 = @txtBinToolTip, "  'Bin
            End If
        Else
            mSql &= " Location4 = @ddlLocLvl4, "  'Bin
        End If
        mSql &= " Reason = @ddlReason, "
        If txtRemarks.Text.Trim <> "" Then
            If txtRemarks.Text.Trim = "-" Then
                mSql &= " Remarks = NULL, "                      'Asset Notes
            Else
                mSql &= " Remarks = " & Left("@txtRemarks", 500) & ", "
            End If
        End If
        If IsDate(txtDate.Text) Then
            mSql &= " EffectiveDate = @txtDate, "
            mSql &= " LastMoved = @txtDate, "
        Else
            mSql &= " EffectiveDate = @RightNow, "
            mSql &= " LastMoved = @RightNow, "
        End If
        mSql &= " LastTrans = 'TRANSFER', "
        mSql &= " LastTransDate = @RightNow, "
        mSql &= " LastTransBy = @PeopleId"
        mSql &= " WHERE (AssetId = @ThisId); "

        ' move InventoryLocation
        mSql &= "UPDATE InventoryLocation SET "
        mSql &= " WareHouse = @Loc3Text, "
        mSql &= " Bin = @Loc4Text"
        mSql &= " WHERE (AssetId = @ThisId); "



        '
        '
        '
        Dim CCUpdate As Boolean = False
        If ddlnewCC.SelectedValue <> "-" Then    ' change of condition code?
            If ddlnewCC.SelectedValue <> sqldt.Rows(0)("CurrentCondition") Then
                CCUpdate = True
                cSql = " UPDATE Assets SET "
                cSql &= " CurrentCondition = @ddlnewCC, "     ' change of condition code
                If ddlnewCC.SelectedValue = "A" Then
                    If IsDate(txtDate.Text) Then
                        cSql &= " A_Cond_Date = @txtDate "
                    Else
                        cSql &= " A_Cond_Date = @RightNow "
                    End If
                Else
                    cSql &= " A_Cond_Date = NULL "
                End If
                cSql &= " WHERE (AssetId = @ThisId); "

            End If
        End If
        '
        '
        '
        'test for other changes
        Dim otherUpdate As Boolean = False
        Dim ttype As String = "UPDATE ASSET"
        '''''''uSql = "UPDATE Assets SET "
        Dim notes As String = ""        'save notes for history
        If ddlUpdSubGroup.SelectedValue <> "-" Then     ' change of Sub Group (and Acct/PIN)
            ttype = "UPDATE PROGRAM"
            uSql &= " SubGroup = @ddlUpdSubGroup, "
            uSql &= " PIN = (SELECT TOP 1 ProgramType FROM Programs WHERE (ProgramName = @ddlUpdSubGroup)), "
            notes &= " SubGroup/Acct from @SubGroup/ "
            'notes &= "(SELECT ProgramType FROM Programs WHERE (ProgramName = '" & sqldt.Rows(0)("SubGroup") & "')) + '"
            notes &= "(SELECT ProgramType FROM Programs WHERE (ProgramName = @SubGroup) "
            notes &= " to @ddlUpdSubGroup/ "
            notes &= "(SELECT ProgramType FROM Programs WHERE (ProgramName = @ddlUpdSubGroup)), "
            otherUpdate = True
        End If

        If ddlPackingStatus.SelectedValue <> "-" Then   ' change of Packing Status
            If Request.Form("ddlPackingStatus") = "UNKNOWN blank" Then
                uSql &= " PackingStatus = NULL, "
                notes &= " PackingStatus From @PackingStatusRow to (), "
            Else
                uSql &= " PackingStatus = @ddlPackingStatusForm, "
                notes &= " PackingStatus from @PackingStatusRow to @ddlPackingStatusForm, "
            End If
            otherUpdate = True
        End If
        If txtUpdICN.Text <> "" Then    ' change of ICN (and hidden sequence)   
            If sqldt.Rows(0)("SubGroup") = "CICPOVHL" Or ddlUpdSubGroup.SelectedValue = "CICPOVHL" Then
                'change of ICN not allowed (from this page) for CICPOVHL SubGroup
            Else
                If txtUpdICN.Text.Trim = "-" Then
                    uSql &= " ICNnum = NULL, ICNseq = NULL, "
                    notes &= " ICN from @ICNnum to (), "
                Else
                    uSql &= " ICNnum = @txtUpdICN, "
                    ' no seq unless subgroup of CICPOVHL, If subgroup of CICPOVHL ICN not updateable from here...
                    'uSql &= " ICNseq = (SELECT ISNULL(MAX(ISNULL(ICNSeq, 0)) + 1, 1) AS NextSeq "
                    'uSql &= "FROM Assets WHERE (ICNnum = '" & Server.HtmlEncode(txtUpdICN.Text.Trim.ToUpper) & "')), "
                    notes &= " ICN from @ICNnum to @txtUpdICN, "
                End If
                otherUpdate = True
            End If
        End If
        If txtMarkFor.Text <> "" Then   ' change of Mark For
            If txtMarkFor.Text = "-" Then
                uSql &= " MarkFor = NULL, "
            Else
                uSql &= " MarkFor = @txtMarkFor, "
            End If
            notes &= " Mark For from " & Left("@MarkFor", 50) & " to @txtMarkFor, "
            otherUpdate = True
        End If

        If txtUpdWeight.Text <> "" Then  ' change in Weight 
            If IsNumeric(txtUpdWeight.Text) Then
                If CDec(txtUpdWeight.Text) > CDec("0.00") Then
                    'uSql &= " ShipWeight = " & CDec(txtUpdWeight.Text) & ", "
                    uSql &= " ShipWeight = @txtUpdWeight, "
                    notes &= " Weight from " & FormatNumber(sqldt.Rows(0)("ShipWeight"), 0, , , 0) & " to " & FormatNumber(txtUpdWeight.Text.Trim, 0, , , 0) & ", "
                Else
                    uSql &= " ShipWeight = NULL, "
                    notes &= " Weight from " & FormatNumber(sqldt.Rows(0)("ShipWeight"), 0, , , 0) & " to 0, "
                End If
                otherUpdate = True
            End If
        End If


        If txtUpdLength.Text <> "" Or txtUpdWidth.Text <> "" Or txtUpdHeight.Text <> "" Then  ' change in Dimentions
            Dim fl As String = FormatNumber(sqldt.Rows(0)("ShipLength"), 0, , , 0)
            Dim fw As String = FormatNumber(sqldt.Rows(0)("ShipWidth"), 0, , , 0)
            Dim fh As String = FormatNumber(sqldt.Rows(0)("ShipHeight"), 0, , , 0)
            Dim tl As String = "0"
            Dim tw As String = "0"
            Dim th As String = "0"

            If IsNumeric(txtUpdLength.Text) Then
                If CDec(txtUpdLength.Text) > CDec("0.00") Then
                    'uSql &= " ShipLength = " & CDec(txtUpdLength.Text) & ", "
                    uSql &= " ShipLength = @txtUpdLength, "
                    'notes &= " Shipping Length from " & FormatNumber(sqldt.Rows(0)("ShipLength"), 0, , , 0) & " to " & FormatNumber(txtUpdLength.Text.Trim, 0, , , 0) & ", "
                    tl = FormatNumber(txtUpdLength.Text.Trim, 0, , , 0)
                Else
                    uSql &= " ShipLength = NULL, "
                    'notes &= " Shipping Length from " & FormatNumber(sqldt.Rows(0)("ShipLength"), 0, , , 0) & " to 0, "
                    tl = "0"
                End If
            End If

            If IsNumeric(txtUpdWidth.Text) Then
                If CDec(txtUpdWidth.Text) > CDec("0.00") Then
                    uSql &= " ShipWidth = @txtUpdWidth, "
                    tw = FormatNumber(txtUpdWidth.Text.Trim, 0, , , 0)
                Else
                    uSql &= " ShipWidth = NULL, "
                    tw = "0"
                End If
            End If

            If IsNumeric(txtUpdHeight.Text) Then
                If CDec(txtUpdHeight.Text) > CDec("0.00") Then
                    uSql &= " ShipHeight = @txtUpdHeight, "
                    th = FormatNumber(txtUpdHeight.Text.Trim, 0, , , 0)
                Else
                    uSql &= " ShipHeight = NULL, "
                    th = "0"
                End If
            End If
            notes &= " Dimensions from @flx@fwx@fh to @tlx@twx@th"
            otherUpdate = True
        End If

        '
        If otherUpdate Then
            uSql = Left(uSql, Len(uSql) - 2)    'get rid of the last ", "
            uSql &= " WHERE (AssetId = @ThisId); "
        End If
        '
        ' string all the updates together
        sql &= mSql
        If mSql <> "" Then
            sql &= cSql
        End If
        If uSql <> "" Then
            sql &= " UPDATE Assets SET " & uSql
        End If
        ' then format all the history

        If mSql <> "" Then
            ' insert History for transfer / move
            sql &= " INSERT INTO AssetHistory ("
            sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
            sql &= " LocationId, Location2, Location3, Location4,"
            sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
            sql &= " Status,"
            sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
            '
            sql &= " SELECT AssetId, "
            sql &= " CurrentCondition AS ConditionCode, "
            sql &= " 'TRANSFER ASSET' AS TransType, "
            sql &= " @RightNow AS TransDate, "
            sql &= " @PeopleId AS TransBy, "
            sql &= " 'TRANSFER FROM' + @WareHouse + '/' + @Bin + 'TO ' + @Loc3Text + '/' + @Loc4Text "
            If txtRemarks.Text <> "" Then   ' change of Asset Notes
                sql &= " + ', Asset Notes Updated,' "
            End If
            If cSql = "" And uSql = "" Then
                If txtHistRemarks.Text.Trim <> "" Then  ' include extra History Remarks on the move transaction history.
                    'sql &= ", " & Left("@txtHistRemarks", 400)
                    sql &= "+ ', " & Left("@txtHistRemarks", 400) & "' "
                End If
            End If
            'sql &= "' AS Remarks, "
            sql &= " AS Remarks, "
            sql &= " @ddlReason AS Reason, "
            sql &= " NULL AS DocumentNumber, "
 
            sql &= " 1 AS LocationId, "   '-- ACTIVE
            sql &= " @ddlLocLvl2 AS Location2, "  'Location
            sql &= " @ddlLocLvl3 AS Location3, "  'Building
            If Request.Form("ddlLocLvl4") = "- Not in List -" Then
                If txtBin.ToolTip <> "" Then
                    sql &= "@txtBinToolTip AS Location4, "  'Bin
                Else
                    sql &= "0 AS Location4, "  'Bin
                End If
            Else
                sql &= "@ddlLocLvl4 AS Location4, "  'Bin
            End If
            sql &= " 'ACTIVE' AS Location1Text, "
            sql &= " @Loc2Text AS Location2Text, "
            sql &= " @Loc3Text AS Location3Text, "
            sql &= " @Loc4Text AS Location4Text, "
            sql &= " 'ACTIVE' AS Status, "
            If IsDate(txtDate.Text) Then
                sql &= " @txtDate AS EffectiveDate, "
            Else
                sql &= " @RightNow AS EffectiveDate, "
            End If
            sql &= " ICNnum, "
            sql &= " ICNSeq, "
            sql &= " SubGroup, "
            sql &= " ReceivedFrom, "
            sql &= " IssuedTo, "
            sql &= " PIN"
            sql &= " FROM Assets"
            sql &= " WHERE (AssetId = @ThisId); "
        End If
        If cSql <> "" Then
            ' insert History for Change Condition Code
            sql &= " INSERT INTO AssetHistory ("
            sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
            sql &= " LocationId, Location2, Location3, Location4,"
            sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
            sql &= " Status,"
            sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"

            sql &= " SELECT A.AssetId, A.CurrentCondition AS ConditionCode, "
            sql &= " 'CHANGE CONDITION' AS TransType, "
            sql &= " @RightNow AS TransDate, "
            sql &= " @PeopleId AS TransBy, "
            sql &= " 'CONDITION CODE CHANGE FROM @CurrentCondition TO "
            sql &= " @ddlnewCC"
            If uSql <> "" Then
                ' save the remarks for the other updates
            Else
                If txtHistRemarks.Text.Trim <> "" Then  ' include extra History Remarks on the move transaction history.
                    sql &= ", " & Left("@txtHistRemarks", 400)
                End If
            End If
            sql &= "' AS Remarks, "

            sql &= " @ddlReason AS Reason, "
            sql &= " NULL AS DocumentNumber, "
            sql &= " A.LocationId, A.Location2, A.Location3, A.Location4,"
            sql &= " L1.LocationIdCode AS Location1Text, L2.LocationIdCode AS Location2Text, "
            sql &= " L3.LocationIdCode AS Location3Text, L4.LocationIdCode AS Location4Text,"
            sql &= " 'ACTIVE' AS Status, "
            If IsDate(txtDate.Text) Then
                sql &= " @txtDate AS EffectiveDate, "
            Else
                sql &= " @RightNow AS EffectiveDate, "
            End If
            sql &= " A.ICNnum, A.ICNSeq, A.SubGroup, A.ReceivedFrom, A.IssuedTo, A.PIN "
            sql &= " FROM Assets A "
            sql &= " INNER JOIN Locations L1 ON A.LocationId = L1.LocationId "
            sql &= " INNER JOIN Locations L2 ON A.Location2 = L2.LocationId "
            sql &= " INNER JOIN Locations L3 ON A.Location3 = L3.LocationId "
            sql &= " INNER JOIN Locations L4 ON A.Location4 = L4.LocationId "
            sql &= " WHERE (A.AssetId = @ThisId); "
        End If
        If uSql <> "" Then
            ' insert one more History row
            sql &= " INSERT INTO AssetHistory ("
            sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
            sql &= " LocationId, Location2, Location3, Location4,"
            sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
            sql &= " Status,"
            sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"

            sql &= " SELECT A.AssetId, A.CurrentCondition AS ConditionCode, "
            sql &= " @ttype AS TransType, "
            sql &= " @RightNow AS TransDate, "
            sql &= " @PeopleId AS TransBy, "
            If txtHistRemarks.Text.Trim <> "" Then  ' include extra History Remarks on the move transaction history.
                sql &= " '" & Left("@notes" + ", " + "@txtHistRemarks", 500) & "' AS Remarks, "
            Else
                sql &= " '" & Left("@notes", 500) & "' AS Remarks, "
            End If

            sql &= " @ddlReason AS Reason, "
            sql &= " NULL AS DocumentNumber, "
            sql &= " A.LocationId, A.Location2, A.Location3, A.Location4,"
            sql &= " L1.LocationIdCode AS Location1Text, L2.LocationIdCode AS Location2Text, "
            sql &= " L3.LocationIdCode AS Location3Text, L4.LocationIdCode AS Location4Text,"
            sql &= " 'ACTIVE' AS Status, "
            If IsDate(txtDate.Text) Then
                sql &= " @txtDate AS EffectiveDate, "
            Else
                sql &= " @RightNow AS EffectiveDate, "
            End If
            sql &= " A.ICNnum, A.ICNSeq, A.SubGroup, A.ReceivedFrom, A.IssuedTo, A.PIN "
            sql &= " FROM Assets A "
            sql &= " INNER JOIN Locations L1 ON A.LocationId = L1.LocationId "
            sql &= " INNER JOIN Locations L2 ON A.Location2 = L2.LocationId "
            sql &= " INNER JOIN Locations L3 ON A.Location3 = L3.LocationId "
            sql &= " INNER JOIN Locations L4 ON A.Location4 = L4.LocationId "
            sql &= " WHERE (A.AssetId = @ThisId); "

        End If

        'Response.Write("<br>" & sql)
        'Response.Flush()
        ' doit

        SwmsAccess.ExecuteNonQuery(sql, new SqlParameter(){                       
            new SqlParameter("@ICNnum", Server.HtmlEncode(sqldt.Rows(0)("ICNnum"))),
            new SqlParameter("@txtUpdICN", Server.HtmlEncode(txtUpdICN.Text.Trim.ToUpper)),
            new SqlParameter("@ddlPackingStatusRow", sqldt.Rows(0)("PackingStatus")),
            new SqlParameter("@ddlPackingStatusForm", Request.Form("ddlPackingStatus")),
            new SqlParameter("@MarkFor", Server.HtmlEncode(sqldt.Rows(0)("MarkFor"))),
            new SqlParameter("@txtMarkFor", Server.HtmlEncode(txtMarkFor.Text.Trim.ToUpper)),
            new SqlParameter("@ddlUpdSubGroup", ddlUpdSubGroup.SelectedValue),
            new SqlParameter("@txtUpdWidth", txtUpdWidth.Text.Trim),
            new SqlParameter("@txtUpdHeight", txtUpdHeight.text.Trim), 
            new SqlParameter("@txtUpdWeight", txtUpdWeight.text.Trim), 
            new SqlParameter("@txtUpdLength", txtUpdLength.text.Trim),
            new SqlParameter("@ShipWeight ", sqldt.Rows(0)("ShipWeight")),
            new SqlParameter("@Bin", Server.HtmlEncode(sqldt.Rows(0)("Bin"))),
            new SqlParameter("@WareHouse", Server.HtmlEncode(sqldt.Rows(0)("Warehouse"))),
            new SqlParameter("@ddlLocLvl2", Request.Form("ddlLocLvl2")),
            new SqlParameter("@ddlLocLvl3", Request.Form("ddlLocLvl3")),
            new SqlParameter("@ddlLocLvl4", Request.Form("ddlLocLvl4") ),            
            new SqlParameter("@txtBinToolTip", txtBin.ToolTip),
            new SqlParameter("@txtRemarks", Server.HtmlEncode(txtRemarks.Text) ),
            new SqlParameter("@Loc2Text", Server.HtmlEncode(Loc2Text) ),
            new SqlParameter("@Loc3Text", Server.HtmlEncode(Loc3Text) ),
            new SqlParameter("@Loc4Text", Server.HtmlEncode(Loc4Text) ),
            new SqlParameter("@CurrentCondition", sqldt.Rows(0)("CurrentCondition")),
            new SqlParameter("@ddlnewCC", ddlnewCC.SelectedValue),            
            new SqlParameter("@PeopleId", Session("SWMSUId") ),
            new SqlParameter("@ttype", ttype ),
            new SqlParameter("@notes", notes ),
            new SqlParameter("@txtHistRemarks", Server.HtmlEncode(txtHistRemarks.Text)),
            new SqlParameter("@ddlReason", ddlReason.SelectedItem.Text ),
            new SqlParameter("@txtDate", txtDate.Text ),
            new SqlParameter("@ThisId", ThisId )
        })

        ' logit
        SwmsLogger.LogEvent("assets", 
        "Assets: niin:" & txtNIIN.Text & " part: " & txtPartNumber.Text & " S/N:" & sqldt.Rows(0)("SerialNumber") & " Transfered ")
        If ddlnewCC.SelectedValue <> "-" Then    ' change of condition code
            SwmsLogger.LogEvent("assets", "Assets: niin:" & txtNIIN.Text & " part: " & txtPartNumber.Text & " S/N:" & sqldt.Rows(0)("SerialNumber") & " Changed CC ")
        End If
        If ddlUpdSubGroup.SelectedValue <> "-" Then    ' change of SubGroup & Program
            SwmsLogger.LogEvent("assets", "Assets: niin:" & txtNIIN.Text & " part: " & txtPartNumber.Text & " S/N:" & sqldt.Rows(0)("SerialNumber") & " Changed SubGroup ")
        Else
            If uSql <> "" Then      ' other change
                SwmsLogger.LogEvent("assets", 
                "Assets: niin:" & txtNIIN.Text & " part: " & txtPartNumber.Text & " S/N:" & sqldt.Rows(0)("SerialNumber") & " Other Change ")
            End If
        End If
        '
    End Sub
 
End Class
