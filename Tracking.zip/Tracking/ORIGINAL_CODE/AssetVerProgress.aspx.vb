﻿Imports System.Web.UI.WebControls.Expressions

Partial Class Tracking_AssetVerProgress
    Inherits System.Web.UI.Page

    Dim cC As New commonClass

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
        If msg <> "" Then
            Response.Redirect(msg)
        End If


        lblTitle.Text = "Asset Inventory " & UCase(Session("InventoryName")) & " Monthly Progress "

        runReport()
        populateNotFoundList()
    End Sub

    Protected Sub LinqDataSource1_ContextCreating(sender As Object, e As LinqDataSourceContextEventArgs) Handles LinqDataSource1.ContextCreating
        e.ObjectInstance = New AssetVerifyDataContext(Session("swmsDBConnection").ToString)
    End Sub

    Protected Sub FilterStatus(ByVal sender As Object, ByVal e As CustomExpressionEventArgs)
        e.Query = From row In e.Query.Cast(Of AssetVerifyProgressView)() Where (row.InventoryName.Equals(Session("InventoryName")))
    End Sub

    Sub runReport()
        monthlyProgress.DataSource = LinqDataSource1
        monthlyProgress.DataBind()
    End Sub

    Protected Sub LinqDataSource2_ContextCreating(sender As Object, e As LinqDataSourceContextEventArgs) Handles LinqDataSource2.ContextCreating
        e.ObjectInstance = New AssetVerifyDataContext(Session("swmsDBConnection").ToString)
    End Sub

    Protected Sub FilterStatus2(ByVal sender As Object, ByVal e As CustomExpressionEventArgs)
        e.Query = From row In e.Query.Cast(Of AssetVerifyNotFoundView)() Where (row.InventoryName.Equals(Session("InventoryName")))
    End Sub

    Sub populateNotFoundList()
        notFoundList.DataSource = LinqDataSource2
        notFoundList.DataBind()
    End Sub
End Class
