﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class Tracking_FindMeters
    Inherits System.Web.UI.Page

#Region "declarations"

    Dim sql As String = ""
#End Region

#Region "pageLoad"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
        ' If msg <> "" Then
        '     Response.Redirect(msg)
        ' End If

        SwmsAccess.ValidateSession()

        If Not Page.IsPostBack Then
            populateDdl()
            checkForMemories()
        End If

    End Sub
#End Region

    Private Sub checkForMemories()

        '--- remember what was selected last time I was here
        SwmsUI.MemoriesIn(New Control() {
            txtSn, txtLoc1, txtLoc2, txtLoc3, txtLoc4, ddlMtrType})

    End Sub

    Sub populateDdl()

        ' meter type --------------------------------------------
        ddlMtrType.Items.Clear()
        sql = " select '---' as SVD_Attribute union all"
        sql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        sql &= " WHERE (SVD_Name = 'MeterType') ORDER BY SVD_Attribute"

        SwmsUI.LoadDropDown(ddlMtrType,
        sql,
        Nothing,
        False,
        "SVD_Attribute",
        "SVD_Attribute")

    End Sub

    Sub displayMeters()

        sql = "SELECT * FROM ("
        sql &= " select meterid, isnull(metertype,'') as mtrType, mah.maxid,"
        sql &= " isnull(mtr.assetid,0) as assetId, isnull(ass.serialnumber,'---') as sn, "

        sql &= " case when mtr.assetid is null then"
        sql &= "    loc1.locationidcode else locAh1.locationIdCode end as loc1, "
        sql &= " case when mtr.assetid is null then"
        sql &= "    loc2.locationidcode else locAh2.locationIdCode end as loc2,"
        sql &= " case when mtr.assetid is null then"
        sql &= "    loc3.locationidcode else locAh3.locationIdCode end as loc3, "
        sql &= " case when mtr.assetid is null then"
        sql &= "    loc4.locationidcode else locAh4.locationIdCode end as loc4,"

        sql &= " case when mtr.assetid is null then " '-- get the location from the meter
        sql &= "    isnull(loc1.LocationIdcode,' - ') + ' - ' + isnull(loc2.LocationIdcode,'') "
        sql &= "        + ' - ' + isnull(loc3.LocationIdcode,'') + ' - ' "
        sql &= "        + isnull(loc4.LocationIdcode,'') "
        sql &= "        else  " ' --get the location from the most recent asset history record
        sql &= "    isnull(locAh1.LocationIdcode,' - ') + ' - ' + isnull(locAh2.LocationIdcode,'') "
        sql &= "        + ' - ' + isnull(locAh3.LocationIdcode,'') + ' - ' "
        sql &= "        + isnull(locAh4.LocationIdcode,'') end as locName"
        sql &= " from meters mtr "
        '---join locations on meter
        sql &= "    left outer join locations loc1 on mtr.locationid = loc1.locationid "
        sql &= "    left outer join locations loc2 on mtr.location2 = loc2.locationid "
        sql &= "    left outer join locations loc3 on mtr.location3 = loc3.locationid "
        sql &= "    left outer join locations loc4 on mtr.location4 = loc4.locationid "
        sql &= "    left outer join assets ass on mtr.assetid = ass.assetid"
        '--- determine most recent assethistory record
        sql &= "    left outer join ("
        sql &= "        select assetid, max(assethistoryid) as maxid from assethistory group by assetid"
        sql &= "    ) mah on mtr.assetid = mah.assetid"
        '--- join on most recent asset history record
        sql &= "    left outer join assethistory ah on mah.maxid = ah.assethistoryid"
        '---join locations on most recent asset history record
        sql &= "    left outer join locations locAh1 on ah.locationid = locAh1.locationid "
        sql &= "    left outer join locations locAh2 on ah.location2 = locAh2.locationid "
        sql &= "    left outer join locations locAh3 on ah.location3 = locAh3.locationid "
        sql &= "    left outer join locations locAh4 on ah.location4 = locAh4.locationid"
        sql &= " WHERE (MeterId Is Not NULL)"
        If ddlMtrType.SelectedValue <> "---" Then
            sql &= " AND (metertype = @MeterType)"
        End If
        If txtSn.Text <> "" Then
            sql &= " AND (ass.SerialNumber LIKE @SerialNumber)"
        End If
        sql &= " ) ty WHERE (MeterId Is Not NULL) "
        If txtLoc1.Text <> "" Then
            sql &= " AND (loc1 LIKE @loc1)"
        End If
        If txtLoc2.Text <> "" Then
            sql &= " AND (loc2 LIKE @loc2)"
        End If
        If txtLoc3.Text <> "" Then
            sql &= " AND (loc3 LIKE @loc3)"
        End If
        If txtLoc4.Text <> "" Then
            sql &= " AND (loc4 LIKE @loc4)"
        End If

        Dim rm As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, New SqlParameter() {
            New SqlParameter("@MeterType", ddlMtrType.SelectedValue),
            New SqlParameter("@SerialNumber", Server.HtmlEncode(txtSn.Text.Trim) & "%"),
            New SqlParameter("@loc1", Server.HtmlEncode(txtLoc1.Text.Trim) & "%"),
            New SqlParameter("@loc2", Server.HtmlEncode(txtLoc2.Text.Trim) & "%"),
            New SqlParameter("@loc3", Server.HtmlEncode(txtLoc3.Text.Trim) & "%"),
            New SqlParameter("@loc4", Server.HtmlEncode(txtLoc4.Text.Trim) & "%")
        })


        If rm.Rows.Count = 0 Then
            lblReccount.Text = "No Meters found"
        Else
            headerRow()
            Dim i As Integer
            Dim altRow As Boolean = False
            For i = 0 To rm.Rows.Count - 1

                Dim x1 As New TableRow

                x1.Cells.Add(SwmsUI.DataCell("<a href=""javascript:picMe(" & rm.Rows(i)("meterid") & ");"">" & rm.Rows(i)("meterid") & "</a>", "right"))

                x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("mtrType"), "center"))
                x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("locName"), "center"))
                x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("sn"), "center"))

                If altRow = True Then
                    x1.BackColor = System.Drawing.Color.WhiteSmoke
                    altRow = False
                Else
                    altRow = True
                End If
                If rm.Rows(i)("meterid") = Session("mtrId") Then
                    x1.BackColor = System.Drawing.Color.PaleGreen
                End If

                x1.Style.Add("cursor", "hand")
                x1.Attributes.Add("onClick", "picMe(" & rm.Rows(i)("meterid") & ");")
                assetsTab.Rows.Add(x1)
            Next
            If rm.Rows.Count = 1 Then
                lblReccount.Text = "1 Meter Found"
            Else
                lblReccount.Text = rm.Rows.Count & " Meters Found"
            End If
        End If

    End Sub

    Private Sub btnFind_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFind.Click

        '--- clear existing memories

        SwmsUI.MemoriesOut(New Control() {txtSn, ddlMtrType, txtLoc1, txtLoc2, txtLoc3, txtLoc4})

        displayMeters()

    End Sub

    Sub headerRow()
        Dim x1 As New TableRow

        x1.Cells.Add(SwmsUI.DataCell("Id #", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Type", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Location", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Serial #", "center", , , , "LightSteelBlue"))
        x1.CssClass = "smBContent"
        assetsTab.Rows.Add(x1)
    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Response.Redirect("EditMeters.aspx")
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        '--- clear memories

        sql = " DELETE FROM Memories WHERE (Page = 'FindMeters' AND UserId = @UserId) OR "

        sql &= " (FieldName = 'SerialNumber' AND UserId = @UserId) OR"

        sql &= " (FieldName = 'MeterType' AND UserId = @UserId) OR"

        sql &= " (FieldName = 'Location1' AND UserId = @UserId) OR"

        sql &= " (FieldName = 'Location2' AND UserId = @UserId) OR"

        sql &= " (FieldName = 'Location3' AND UserId = @UserId) OR"

        sql &= " (FieldName = 'Location4' AND UserId = @UserId)"

        SwmsAccess.ExecuteNonQuery(sql, New SqlParameter() {
            New SqlParameter("@UserId", Session("SWMSUId"))
        })


        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        txtSn.Text = ""
        txtLoc1.Text = ""
        txtLoc2.Text = ""
        txtLoc3.Text = ""
        txtLoc4.Text = ""
        ddlMtrType.SelectedValue = "---"
        lblReccount.Text = ""

    End Sub

End Class
