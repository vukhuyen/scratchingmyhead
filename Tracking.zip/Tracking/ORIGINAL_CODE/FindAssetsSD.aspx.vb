﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Tracking_FindAssetsSD
    Inherits System.Web.UI.Page

#Region "declarations"
    Dim Maintain As Boolean = False
    Dim sql As String = ""
#End Region



#Region "Page_Load"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        SwmsAccess.ValidateSession(True)

        If Request.QueryString("v") = "1" Then
            Maintain = False
        Else
            ' Inventory, Inventory/Specialist may maintain Assets.  All others read only.)
            '   47  QA Manager
            '   55  Inventory/Scheduler(Specialist)
            '   62  Asset Tracker - CR 9740/9803
            '   98  Database Admin
            '   99	Developer

            ''could use SwmsAccess.ExecuteScalar() here...
            Dim strSQL As String = "SELECT CASE WHEN EXISTS (SELECT FunctionClassId FROM SWMSSecurity.dbo.PeopleFunctionClasses WHERE "
            strSQL &= " (PeopleId = @Userid) AND (FunctionClassId IN (47, 55, 62, 98, 99))) THEN 'True' ELSE 'False' END AS Granted "

            Dim dtSecur As DataTable = SwmsAccess.ExecuteQueryToDataTable(strSQL, New SqlParameter() {
                New SqlParameter("@UserId", Session("SWMSUId"))
            })

            If dtSecur.Rows.Count > 0 Then
                Maintain = Boolean.Parse(dtSecur.Rows(0).Item("Granted").ToString)
            End If
        End If

        fillddls()
        fillLocations()

        If Not Page.IsPostBack Then
            checkForMemories()
            If Request.QueryString("id") <> "" And Request.QueryString("id") <> Nothing Then
                displayAssets()
            End If
        End If

        '
    End Sub
#End Region

    Sub fillddls()

        ' condition code --------------------------------------------
        ddlCc.Items.Clear()
        SwmsUI.LoadDropDown(ddlCc,
        "Select '-' as SVD_Attribute UNION ALL SELECT SVD_Attribute FROM System_Validation_Dictionary WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute",
        Nothing,
        False,
        "SVD_Attribute",
        "SVD_Attribute",
         IIf(Request.Form("ddlCc") = "" Or Request.Form("ddlCc") = Nothing, "-", ddlCc.Items.IndexOf(ddlCc.Items.FindByValue(Request.Form("ddlCc")))))

        ' SubGroup & Acct Code  -------------------------------(ProgramName, ProgramType)
        ddlSubGroup.Items.Clear()
        Dim sgSql As String = "SELECT '-' AS ProgramName, '' AS ProgramType "
        sgSql &= " UNION ALL "
        sgSql &= " SELECT ProgramName, ProgramType "
        sgSql &= " FROM Programs "
        sgSql &= " ORDER BY ProgramName"

        'SubGroup
        SwmsUI.LoadDropDown(ddlSubGroup,
        sgSql,
        Nothing,
        False,
        "ProgramName",
        "ProgramName")

        If Request.Form("ddlSubGroup") = "" Or Request.Form("ddlSubGroup") = Nothing Then
            ddlSubGroup.SelectedValue = "-"  'use - as default
        Else
            ddlSubGroup.SelectedIndex = ddlSubGroup.Items.IndexOf(ddlSubGroup.Items.FindByValue(Request.Form("ddlSubGroup")))
        End If

        'ddlAcct
        ddlAcct.Items.Clear()
        Dim sSql As String = "SELECT '-' AS ProgramType "
        sSql &= " UNION ALL "
        sSql &= " SELECT ProgramType "
        sSql &= " FROM Programs "
        sSql &= " GROUP BY ProgramType"
        sSql &= " ORDER BY ProgramType"

        'Dim swmsDb As New SqlConnection
        Dim sqldta As DataTable = Nothing

        Try
            sqldta = SwmsAccess.ExecuteQueryToDataTable(sSql, Nothing)
        Catch ex As Exception
            'cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sSql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/EditAssetSD.aspx")
            Throw ex
        Finally
        End Try

        SwmsUI.LoadDropDown(ddlAcct,
        sSql,
        Nothing,
        False,
        "ProgramType",
        "ProgramType")

        If Request.Form("ddlAcct") = "" Or Request.Form("ddlAcct") = Nothing Then
            ddlAcct.SelectedValue = "-"  'use - as default
        Else
            ddlAcct.SelectedIndex = ddlAcct.Items.IndexOf(ddlAcct.Items.FindByValue(Request.Form("ddlAcct")))
        End If
        '
    End Sub

    Sub fillLocations()
        '
        '' locationid ----------------------------------
        ddlLocLvl1.Items.Add(New ListItem("--", "0"))
        Dim l1Sql As String = "SELECT 0 AS LocationId, '--' AS LocationIdCode UNION "
        l1Sql &= "SELECT LocationId, LocationIdCode FROM Locations WHERE (LocationLevel = 1)"
        SwmsUI.LoadDropDown(ddlLocLvl1,
            l1Sql,
            Nothing,
            False,
            "LocationIdCode",
            "LocationId")
        '
        '' location2 ----------------------------------
        Dim sql2 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql2 &= " WHERE (LocationLevel = 2)"
        sql2 &= " ORDER BY LocationIdCode"
        SwmsUI.LoadDropDown(ddlSavLvl2,
            sql2,
            Nothing,
            False,
            "Code",
            "ParentLocationID")
        '
        ' Sub -------------- "Building" -------------------
        ddlSavLvl3.Items.Clear()
        Dim sql3 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql3 &= " WHERE (LocationLevel = 3)"
        sql3 &= " ORDER BY LocationIdCode"
        SwmsUI.LoadDropDown(ddlSavLvl3,
            sql3,
            Nothing,
            False,
            "Code",
            "ParentLocationID")
        '
        ' Micro -------------- "Bin" -------------------
        ddlSavLvl4.Items.Clear()
        Dim sql4 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql4 &= " WHERE (LocationLevel = 4)"
        sql4 &= " ORDER BY LocationIdCode"
        SwmsUI.LoadDropDown(ddlSavLvl4,
            sql4,
            Nothing,
            False,
            "Code",
            "ParentLocationID")

    End Sub

    Private Sub checkForMemories()

        Dim savLocation As String = ""
        Dim savBldg As String = ""
        Dim savBin As String = ""

        '--- remember what was selected last time I was here
        If SwmsUI.MemoriesIn(New Control() {
            txtNIIN, txtPartNumber, txtCAGE, txtSerial, ddlCc, txtModelNumber, txtNomenclature, txtICNnum, txtICNseq,
            ddlSubGroup, ddlAcct, ddlLocLvl1, ddlLocLvl2}) Then

            Dim j As Integer = 0
            Dim tli2 As New ListItem("--", "0")
            Dim tli3 As New ListItem("--", "0")
            Dim tli4 As New ListItem("--", "0")
            '
            ddlLocLvl2.Items.Clear()
            ddlLocLvl2.Items.Add(tli2)
            ' Populate the control after we know what has been selected for the prior control
            For i = 0 To ddlSavLvl2.Items.Count - 1
                If ddlSavLvl2.Items(i).Value = ddlLocLvl1.SelectedValue Then
                    j = InStr(ddlSavLvl2.Items(i).Text, "@")
                    Dim litmB As New ListItem
                    litmB.Value = Left(ddlSavLvl2.Items(i).Text, j - 1)
                    litmB.Text = Mid(ddlSavLvl2.Items(i).Text, j + 1)
                    ddlLocLvl2.Items.Add(litmB)
                End If
            Next
            ddlLocLvl2.ClearSelection()
            If Request.Form("ddlLocLvl2") = "" Or Request.Form("ddlLocLvl2") = Nothing Then
                If savLocation <> "" Then
                    ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByValue(savLocation))
                End If
            Else
                ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByValue(Request.Form("ddlLocLvl2")))
            End If
            '
            ddlLocLvl3.Items.Clear()
            ddlLocLvl3.Items.Add(tli3)
            ' Populate the control after the data record has been read
            For i = 0 To ddlSavLvl3.Items.Count - 1
                If ddlSavLvl3.Items(i).Value = ddlLocLvl2.SelectedValue Then
                    j = InStr(ddlSavLvl3.Items(i).Text, "@")
                    Dim litmC As New ListItem
                    litmC.Value = Left(ddlSavLvl3.Items(i).Text, j - 1)
                    litmC.Text = Mid(ddlSavLvl3.Items(i).Text, j + 1)
                    ddlLocLvl3.Items.Add(litmC)
                End If
            Next
            ddlLocLvl3.ClearSelection()
            If Request.Form("ddlLocLvl3") = "" Or Request.Form("ddlLocLvl3") = Nothing Then
                If savBldg <> "" Then
                    ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(savBldg))
                End If
            Else
                ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(Request.Form("ddlLocLvl3")))
            End If
            '
            ddlLocLvl4.Items.Clear()
            ddlLocLvl4.Items.Add(tli4)
            ' Populate the control after the data record has been read
            For i = 0 To ddlSavLvl4.Items.Count - 1
                If ddlSavLvl4.Items(i).Value = ddlLocLvl3.SelectedValue Then
                    j = InStr(ddlSavLvl4.Items(i).Text, "@")
                    Dim litmD As New ListItem
                    litmD.Value = Left(ddlSavLvl4.Items(i).Text, j - 1)
                    litmD.Text = Mid(ddlSavLvl4.Items(i).Text, j + 1)
                    ddlLocLvl4.Items.Add(litmD)
                End If
            Next
            ddlLocLvl4.ClearSelection()
            If Request.Form("ddlLocLvl4") = "" Or Request.Form("ddlLocLvl4") = Nothing Then
                If savBin <> "" Then
                    ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(savBin))
                End If
            Else
                ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(Request.Form("ddlLocLvl4")))
            End If
        Else    ' if no memories this must be the first time thru for this session
            '
            Dim j As Integer = 0
            ' Populate the control after we know what has been selected for the prior control
            ddlLocLvl2.Items.Clear()
            ddlLocLvl2.Items.Add(New ListItem("--", "0"))
            For i = 0 To ddlSavLvl2.Items.Count - 1
                If ddlSavLvl2.Items(i).Value = ddlLocLvl1.SelectedValue Then
                    j = InStr(ddlSavLvl2.Items(i).Text, "@")
                    Dim litmB As New ListItem
                    litmB.Value = Left(ddlSavLvl2.Items(i).Text, j - 1)
                    litmB.Text = Mid(ddlSavLvl2.Items(i).Text, j + 1)
                    ddlLocLvl2.Items.Add(litmB)
                End If
            Next
            ddlLocLvl2.ClearSelection()
            If Request.Form("ddlLocLvl2") = "" Or Request.Form("ddlLocLvl2") = Nothing Then

            Else
                ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByValue(Request.Form("ddlLocLvl2")))
            End If
            ' 
            ddlLocLvl3.ClearSelection()
            If Request.Form("ddlLocLvl3") = "" Or Request.Form("ddlLocLvl3") = Nothing Then
                ddlLocLvl3.Items.Add(New ListItem("--", "0"))
            Else
                ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(Request.Form("ddlLocLvl3")))
            End If
            '
            ddlLocLvl4.ClearSelection()
            If Request.Form("ddlLocLvl4") = "" Or Request.Form("ddlLocLvl4") = Nothing Then
                ddlLocLvl4.Items.Add(New ListItem("--", "0"))
            Else
                ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(Request.Form("ddlLocLvl4")))
            End If
        End If

    End Sub

    Sub headerRow()
        Dim x1 As New TableRow

        x1.Cells.Add(SwmsUI.DataCell("Sub Group", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Acct", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Part Number", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("CAGE", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Model", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("NIIN", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Serial", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("ICN", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Condition", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Nomenclature", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Status", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Location", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Bldg", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Bin", "center", , , "false", "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("AssetId", "center", , , "false", "LightSteelBlue"))
        x1.CssClass = "smBContent"
        assetsTab.Rows.Add(x1)
    End Sub

    Sub displayAssets()
        checkForMemories()
        assetsTab.Controls.Clear()
        headerRow()

        sql = "SELECT A.AssetId, "
        sql &= " ISNULL(A.SubGroup, '') AS SubGroup,"
        sql &= " ISNULL(A.PIN, '') AS AcctPIN,"
        sql &= " ISNULL(A.PartNumber, '') AS PartNumber, "
        sql &= " ISNULL(A.NIIN, '') AS NIIN, "
        sql &= " ISNULL(A.SerialNumber, '') AS SerialNumber,"
        sql &= " ISNULL(A.ICNnum, '') AS ICNnum,"
        sql &= " ISNULL(A.ICNseq, 0) AS ICNseq,"
        sql &= " ISNULL(A.Nomenclature, '') AS Nomenclature,"
        sql &= " ISNULL(A.ModelNumber, '') AS ModelNumber,"
        sql &= " ISNULL(A.Manufacturer, '') AS CAGE,"
        sql &= " ISNULL(A.CurrentCondition, '') AS ConditionCode,"
        sql &= " ISNULL(L1.LocationIdCode, 'Unknown') AS Status,"
        sql &= " ISNULL(L2.LocationIdCode, '') AS Location,"
        sql &= " ISNULL(L3.LocationIdCode, '') AS Building,"
        sql &= " ISNULL(L4.LocationIdCode, '') AS Bin"
        sql &= " FROM Assets A"
        sql &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationId"
        sql &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationId"
        sql &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationId"
        sql &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationId"
        sql &= " WHERE (A.AssetId IS NOT NULL)"

        If ddlLocLvl1.SelectedValue = "1" Then
            sql &= " AND (A.LocationId = 1)"    '   "Active"
        ElseIf ddlLocLvl1.SelectedValue = "2" Then
            sql &= " AND (A.LocationId = 2)"    '   "Issued"
        End If
        If ddlLocLvl2.SelectedIndex > 0 Then
            sql &= " AND (A.Location2 = @Location2)"
        End If
        If ddlLocLvl3.SelectedIndex > 0 Then
            sql &= " AND (A.Location3 = @Location3)"
        End If
        If ddlLocLvl4.SelectedIndex > 0 Then
            sql &= " AND (A.Location4 = @Location4)"
        End If
        If ddlSubGroup.SelectedIndex > 0 Then
            sql &= " AND (A.SubGroup = @ddlSubGroup)"
        End If
        If ddlAcct.SelectedIndex > 0 Then
            sql &= " AND (A.PIN = @ddlAcct)"
        End If

        If txtICNseq.Text <> "" Then
            Dim reg As New Regex("^\d$")
            If reg.IsMatch(txtICNseq.Text) Then
                sql &= " AND (A.ICNseq = @ICNseq)"
            Else
                txtICNseq.Text = ""
            End If
        End If
        If txtICNnum.Text <> "" Then
            sql &= " AND (A.ICNnum LIKE @ICNnum)"
        End If
        If txtNomenclature.Text <> "" Then
            sql &= " AND (A.Nomenclature LIKE @Nomenclature)"
        End If
        If txtModelNumber.Text <> "" Then
            sql &= " AND (A.ModelNumber LIKE @ModelNumber)"
        End If

        If ddlCc.SelectedIndex > 0 Then
            sql &= " AND (A.CurrentCondition = @ddlCc)"
        End If
        If txtSerial.Text <> "" Then
            sql &= " AND (A.SerialNumber LIKE @SerialNumber)"
        End If
        If txtPartNumber.Text <> "" Then
            sql &= " AND (A.PartNumber LIKE @PartNumber)"
        End If
        If txtNIIN.Text <> "" Then
            sql &= " AND (A.NIIN LIKE @NIIN)"
        End If

        sql &= " ORDER BY A.NIIN, A.PartNumber, A.SerialNumber"

        Dim cmd As SqlCommand = New SqlCommand()
        With cmd
            .CommandText = sql
            .Parameters.AddWithValue("@Location2", ddlLocLvl2.SelectedValue)
            .Parameters.AddWithValue("@Location3", ddlLocLvl3.SelectedValue)
            .Parameters.AddWithValue("@Location4", ddlLocLvl4.SelectedValue)
            .Parameters.AddWithValue("@SubGroup", ddlSubGroup.SelectedValue)
            .Parameters.AddWithValue("@PIN", ddlAcct.SelectedValue)
            .Parameters.AddWithValue("@ICNseq", txtICNseq.Text.Trim)
            .Parameters.AddWithValue("@Nomenclature", txtNomenclature.Text.Trim)
            .Parameters.AddWithValue("@ModelNumber", txtModelNumber.Text.Trim)
            .Parameters.AddWithValue("@CurrentCondition", ddlCc.SelectedValue)
            .Parameters.AddWithValue("@SerialNumber", txtSerial.Text.Trim)
            .Parameters.AddWithValue("@PartNumber", txtPartNumber.Text.Trim)
            .Parameters.AddWithValue("@NIIN", txtNIIN.Text.Trim)
        End With

        Dim rs As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

        If rs.Rows.Count > 0 Then
            Dim altRow As Boolean = False

            Dim i As Integer
            For i = 0 To rs.Rows.Count - 1
                Dim x1 As New TableRow

                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("SubGroup"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("AcctPIN"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("PartNumber"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("CAGE"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("ModelNumber"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("NIIN"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("SerialNumber"), "center", , , "false"))
                If rs.Rows(i)("ICNseq") > 0 Then
                    x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("ICNnum") & "-" & Right("000" & rs.Rows(i)("ICNseq"), 4), "center", , , "false"))
                Else
                    x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("ICNnum"), "center", , , "false"))
                End If
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("ConditionCode"), "center"))
                If Len(rs.Rows(i)("Nomenclature")) > 40 Then
                    x1.Cells.Add(SwmsUI.DataCell(Left(rs.Rows(i)("Nomenclature"), 37) & "...", "left", , rs.Rows(i)("Nomenclature")))
                Else
                    x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("Nomenclature"), "Nomenclature"))
                End If
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("Status"), "center"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("Location"), "center"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("Building"), "center"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("Bin"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("assetid"), "center"))
                '
                If Maintain Then
                    x1.Attributes.Add("onClick", "EditMe(" & rs.Rows(i)("AssetId") & ");")
                Else
                    x1.Attributes.Add("onClick", "picMe(" & rs.Rows(i)("AssetId") & ");")
                End If
                x1.Style.Add("cursor", "hand")
                '
                If altRow = True Then
                    x1.BackColor = System.Drawing.Color.WhiteSmoke
                    altRow = False
                Else
                    altRow = True
                End If
                If rs.Rows(i)("AssetId") = Request.QueryString("id") Then
                    x1.BackColor = System.Drawing.Color.PaleGreen
                End If
                assetsTab.Rows.Add(x1)
            Next

        End If

        If rs.Rows.Count = 0 Then
            lblRowCount.Text = "No records found"
        Else
            'If rs.Rows.Count = 1000 Then
            '    lblRowCount.Text = "Only the first 1000 records are displayed."
            '    lblRowCount.Text &= "<br>Please try entering more criteria to narrow down your search."
            'Else
            lblRowCount.Text = rs.Rows.Count & " Records found"
            'End If
        End If

    End Sub

    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrint.Click

        Response.Redirect("../common/PrintableAssetList.aspx?rtn=s")

    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        '--- clear memories

        sql = " DELETE FROM Memories WHERE (Page = 'FindAssets' AND UserId = @UserID)"

        SwmsAccess.ExecuteNonQuery(sql, New SqlParameter() {New SqlParameter("@UserId", Session("SWMSUId"))})

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        lblRowCount.Text = ""
        txtNIIN.Text = ""
        txtPartNumber.Text = ""
        txtCAGE.Text = ""
        txtSerial.Text = ""
        ddlCc.SelectedIndex = -1
        txtModelNumber.Text = ""
        txtNomenclature.Text = ""
        txtICNnum.Text = ""
        txtICNseq.Text = ""
        ddlSubGroup.SelectedIndex = -1
        ddlAcct.SelectedIndex = -1
        ddlLocLvl1.SelectedIndex = 0

        Dim j As Integer = 0
        Dim tli As New ListItem
        tli.Text = "--"
        tli.Value = "0"
        '
        ddlLocLvl2.Items.Clear()
        ddlLocLvl2.Items.Add(tli)
        ' prepare for next selection
        For i = 0 To ddlSavLvl2.Items.Count - 1
            If ddlSavLvl2.Items(i).Value = ddlLocLvl1.SelectedValue Then
                j = InStr(ddlSavLvl2.Items(i).Text, "@")
                Dim litm As New ListItem
                litm.Value = Left(ddlSavLvl2.Items(i).Text, j - 1)
                litm.Text = Mid(ddlSavLvl2.Items(i).Text, j + 1)
                ddlLocLvl2.Items.Add(litm)
            End If
        Next
        ddlLocLvl3.Items.Clear()
        ddlLocLvl3.Items.Add(tli)
        ddlLocLvl4.Items.Clear()
        ddlLocLvl4.Items.Add(tli)
    End Sub

    Protected Sub btnSho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSho.Click

        RefreshMemories()
        displayAssets()

    End Sub

    Sub RefreshMemories()

        SwmsUI.MemoriesOut(New Control() {
        txtNIIN, txtPartNumber, txtCAGE, txtSerial, txtModelNumber, txtNomenclature, txtICNnum, txtICNseq,
        ddlCc, ddlSubGroup, ddlAcct, ddlLocLvl1, ddlLocLvl2, ddlLocLvl3, ddlLocLvl4
        })
    End Sub

End Class

