﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls.Expressions
Imports System.IO
Partial Class Tracking_AssetVerScrubList
    Inherits System.Web.UI.Page
    Private conn As New Data.SqlClient.SqlConnection()

#Region " Declarations "
    Dim cC As New commonClass
    Dim sql As String = ""
    Dim str As String
#End Region

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        lblInvName.Text = Session("InventoryName") & " Assets Not Verified/Scrub List"
        lblDate.Text = Date.Today
        btnFinal.Enabled = False
        editCountSheet()

    End Sub

#Region "EditCountSheet"
    Sub editCountSheet()
        gv.DataSource = LinqDataSource1
        gv.PageIndex = 0
        gv.DataBind()

        If gv.Rows.Count.ToString = 1 Then
            Me.lblRowCount.Text = "1 Record"
        Else
            Me.lblRowCount.Text = gv.Rows.Count.ToString & " Records"
        End If
    End Sub

    Protected Sub LinqDataSource1_ContextCreating(sender As Object, e As LinqDataSourceContextEventArgs) Handles LinqDataSource1.ContextCreating
        e.ObjectInstance = New AssetVerifyDataContext(Session("swmsDBConnection").ToString)
    End Sub

    Protected Sub filterByInventoryName(ByVal sender As Object, ByVal e As CustomExpressionEventArgs)
        e.Query = From entireRow In e.Query.Cast(Of AssetVerifyScrubListView)() Where entireRow.InventoryName = Session("InventoryName").ToString _
            Select entireRow
    End Sub

    Protected Sub FilterStatus(ByVal sender As Object, ByVal e As CustomExpressionEventArgs)

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(control As Control)
        'Verifies that the control is rendered 
        ' prevents "Control 'gv' of type 'GridView' must be placed inside a form tag with runat=server." error
    End Sub

    Protected Sub gv_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gv.RowDataBound
        

        ' --- show Y/N links 
        If e.Row.RowType = DataControlRowType.DataRow Then
            Select Case DataBinder.Eval(e.Row.DataItem, "cm")
                Case "Not Found"
                    e.Row.Cells(10).Text = "N"
                    e.Row.BackColor = Drawing.Color.Linen
                Case ""
                    Dim lf As LinkButton = e.Row.FindControl("lnkFound")
                    lf.CommandName = "Select"
                    lf.CausesValidation = False
                    lf.Text = "Y"

                    Dim lnf As LinkButton = e.Row.FindControl("lnkNotFound")
                    lnf.CommandName = "Delete"
                    lnf.CausesValidation = False
                    lnf.Text = "N"
                Case "Exempt from Inventory", "Not in Snapshot"
                    e.Row.Cells(10).Text = ""
                    e.Row.BackColor = Drawing.Color.AliceBlue
                Case Else
                    e.Row.Cells(10).Text = "Y"
                    e.Row.BackColor = Drawing.Color.Honeydew
            End Select

            ' --- show undo links 
            Select Case DataBinder.Eval(e.Row.DataItem, "cm")
                Case "Exempt from Inventory", "Not in Snapshot", ""
                Case Else
                    If CStr(e.Row.Cells(14).Text) = "0" Then ' ---  scrub is not finalized
                        Dim undo As LinkButton = e.Row.FindControl("lnkUndo")
                        undo.CommandName = "Update"
                        undo.CausesValidation = False
                        undo.Text = "Undo"
                    End If
            End Select

            ' --- enable Finalize button only when all assets have been accounted for --- 
            If CStr(e.Row.Cells(14).Text) = "0" Then ' ---  scrub is not finalized
                If CStr(e.Row.Cells(13).Text) = "0" Then
                    btnFinal.Enabled = True
                Else
                    btnFinal.Enabled = False
                End If
            Else ' ---  scrub IS  finalized
                btnFinal.Visible = False
            End If
        End If

        ' --- hides the uncompletion count and scrubComplete fields ---
        If e.Row.Cells.Count > 4 Then
            e.Row.Cells(13).Visible = False
            e.Row.Cells(14).Visible = False
        End If

    End Sub

    Protected Sub gv_SelectedIndexChanged(sender As Object, e As EventArgs) Handles gv.SelectedIndexChanged
        ' --- using select function to mark asset as found --- @dateComplete
        conn.ConnectionString = Session("swmsDbConnection")
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyUpdate", conn)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@assetId", Me.gv.SelectedRow.Cells(0).Text.ToString)
        cmd.Parameters.AddWithValue("@inventoryName", Session("InventoryName"))
        cmd.Parameters.AddWithValue("@completionMethod", "Found in Location")
        cmd.Parameters.AddWithValue("@dateComplete", Date.Today)
        cmd.Parameters.AddWithValue("@completeBy", Session("SWMSUid"))
        cmd.Parameters.AddWithValue("@AVLId", "0")
        Try
            conn.Open()
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            conn.Close()
            conn.Dispose()
        End Try

        gv.DataSource = LinqDataSource1
        gv.DataBind()
    End Sub

    Protected Sub gv_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gv.RowDeleting
        ' --- using delete function to mark asset as not found ---
        conn.ConnectionString = Session("swmsDbConnection")
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyUpdate", conn)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@assetId", gv.DataKeys(e.RowIndex).Values("assetId").ToString())
        cmd.Parameters.AddWithValue("@inventoryName", Session("InventoryName"))
        cmd.Parameters.AddWithValue("@completionMethod", "Not Found")
        cmd.Parameters.AddWithValue("@dateComplete", Date.Today)
        cmd.Parameters.AddWithValue("@completeBy", Session("SWMSUid"))
        cmd.Parameters.AddWithValue("@AVLId", "0")
        Try
            conn.Open()
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            conn.Close()
            conn.Dispose()
        End Try

        gv.DataSource = LinqDataSource1
        gv.DataBind()
    End Sub

    Protected Sub gv_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gv.RowUpdating
        ' --- using update function to undo found or not found 
        conn.ConnectionString = Session("swmsDbConnection")
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyUpdate", conn)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@assetId", gv.DataKeys(e.RowIndex).Values("assetId").ToString())
        cmd.Parameters.AddWithValue("@inventoryName", Session("InventoryName"))
        cmd.Parameters.AddWithValue("@completionMethod", DBNull.Value)
        cmd.Parameters.AddWithValue("@dateComplete", DBNull.Value)
        cmd.Parameters.AddWithValue("@completeBy", DBNull.Value)
        cmd.Parameters.AddWithValue("@AVLId", DBNull.Value)
        Try
            conn.Open()
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            conn.Close()
            conn.Dispose()
        End Try

        gv.DataSource = LinqDataSource1
        gv.DataBind()

    End Sub

    Protected Sub btnFinal_Click(sender As Object, e As EventArgs) Handles btnFinal.Click

        conn.ConnectionString = Session("swmsDbConnection")
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyFinalizeScrubList", conn)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@inventoryName", Session("InventoryName"))
        cmd.Parameters.AddWithValue("@completeBy", Session("SWMSUid"))
        Try
            conn.Open()
            cmd.ExecuteNonQuery()
        Catch ex As Exception
        Finally
            conn.Close()
            conn.Dispose()
        End Try

        Response.Redirect("AssetInvVer.aspx")
    End Sub

#End Region

End Class
