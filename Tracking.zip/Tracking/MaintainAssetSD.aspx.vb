﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Partial Class Tracking_MaintainAssetSD
    Inherits System.Web.UI.Page

    Dim cC As New commonClass
    Dim sql As String = ""
    Dim thisId As String = "0"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
        If msg <> "" Then
            Response.Redirect(msg)
        End If

        ' Inventory, Inventory/Specialist may maintain Assets.  All others read only.)
        '   47  QA Manager
        '   55  Inventory/Scheduler(Specialist)
        '   62  Asset Tracker - CR 9740/9803
        '   98  Database Admin
        '   99	Developer
        Dim strSQL As String = "SELECT CASE WHEN EXISTS (SELECT FunctionClassId FROM SWMSSecurity.dbo.PeopleFunctionClasses WHERE "
        strSQL &= " (PeopleId = " & Session("SWMSUId") & ") AND (FunctionClassId IN (47, 55, 62, 98, 99))) THEN 'True' ELSE 'False' END AS Granted "
        Dim dtSecur As DataTable = cC.getAsDataTable(strSQL, Session("SWMSDBConnection"), , Session("SWMSUID").ToString, "Tracking\MaintainAssetSD.aspx.vb - Page_Load()")
        If dtSecur.Rows.Count > 0 Then
            If dtSecur.Rows(0).Item("Granted") = True Then
                'good to go
            Else
                Session("UserMsg") = "You are not authorized to use that page."
                Response.Redirect("../Main/Menu.aspx")
            End If
        Else
            Session("UserMsg") = "You are not authorized to use that page."
            Response.Redirect("../Main/Menu.aspx")
        End If

        lnkInv.Visible = False

        If CStr(Request.QueryString("id")) <> "" Then
            thisId = Request.QueryString("id")
            lnkRet.NavigateUrl = "FindAssetsSD.aspx?id=" & thisId
        Else
            lnkRet.NavigateUrl = "FindAssetsSD.aspx"
        End If

        'this is a one time memory
        sql = "SELECT [Value] FROM Memories WHERE (UserId = " & Session("SWMSUId") & ")"
        sql &= " AND (Page = 'MaintainAssetSD') AND (FieldName = 'UsrMsg');"
        Dim ms As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
        If ms.Rows.Count > 0 Then
            UsrMsg.Value = ms.Rows(0)("Value")
            sql = "DELETE FROM Memories WHERE (Page = 'MaintainAssetSD') AND (UserId = " & Session("SWMSUId") & "); "
            cC.executeNonQuery(sql, Session("swmsDbConnection"))
        Else
            UsrMsg.Value = ""
        End If

        If Not Page.IsPostBack Then '
            txtRemarks.Attributes.Add("maxlength", 500)
            '
            fillDdls()
            fillLocations()
            If CStr(Request.QueryString("id")) <> "" Then
                ' an asset is selected for edit
                displayAsset(Request.QueryString("id"))
                btnUPd.Visible = True
                '
            Else ' form is blank for adding a new asst
            End If
        Else
            If txtCommand.Value = "chg" Then
                txtCommand.Value = ""
                'test for values
                If txtNewNIIN.Text.Trim.Length <> 11 Then
                    'error
                    UsrMsg.Value = "A new NIIN is required."
                    reCycleMemories()
                    Response.Redirect("./MaintainAssetSD.aspx?id=" & Request.QueryString("id"))
                Else
                    'use change niin page
                    Server.Transfer("./NIINChangeSD.aspx?id=" & Request.QueryString("id") & "&Nniin=" & txtNewNIIN.Text & "&Cr=" & Request.Form("ddlCANreason") & "&Ed=" & Request.Form("txtEffDate"))
                End If
            End If
            If txtCommand.Value = "upd" Then
                txtCommand.Value = ""
                check4change()
            End If
        End If

    End Sub

    Sub fillDdls()
        '
        ' SubGroup & Acct Code  -------------------------------
        ddlSubGroup.Items.Clear()
        Dim sgSql As String = "SELECT '-' AS ProgramName, '' AS ProgramType "
        sgSql &= " UNION ALL "
        sgSql &= " SELECT ProgramName, ProgramType "
        sgSql &= " FROM Programs "
        sgSql &= " ORDER BY ProgramName"

        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing

        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(sgSql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sgSql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/EditAssetSD.aspx")
            Throw ex
        Finally
            swmsDb.Close()
        End Try

        ddlSubGroup.DataSource = sqldt
        ddlSubGroup.DataValueField = "ProgramName"
        ddlSubGroup.DataTextField = "ProgramName"
        ddlSubGroup.DataBind()

        ddlAcctPIN.DataSource = sqldt
        ddlAcctPIN.DataValueField = "ProgramType"
        ddlAcctPIN.DataTextField = "ProgramName"
        ddlAcctPIN.DataBind()

        ' condition code --------------------------------------------
        ddlCc.Items.Clear()
        Dim ccSql As String = " Select '-' as SVD_Attribute UNION ALL "
        ccSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        ccSql &= " WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute"
        ddlCc.DataSource = cC.getAsDataTable(ccSql, Session("swmsDbConnection"))
        ddlCc.DataValueField = "SVD_Attribute"
        ddlCc.DataTextField = "SVD_Attribute"
        ddlCc.DataBind()
        ddlCc.SelectedValue = "-"   'use - as default
        '
        ' reason -------------------------------------
        ddlReason.Items.Clear()
        'Dim rSql As String = "SELECT '-' as SVD_Attribute UNION ALL "
        'rSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        'rSql &= " WHERE (SVD_Name = 'AssetReason') ORDER BY SVD_Attribute"
        'ddlReason.DataSource = cC.getAsDataTable(rSql, Session("swmsDbConnection"))
        'ddlReason.DataValueField = "SVD_Attribute"
        'ddlReason.DataTextField = "SVD_Attribute"
        'ddlReason.DataBind()
        ddlReason.Items.Add(New ListItem("CORRECTION"))
        ddlReason.Items.Add(New ListItem("UPDATE ASSET"))
        '    
        ddlCANreason.Items.Clear()
        ddlCANreason.Items.Add(New ListItem("CORRECTION"))
        ddlCANreason.Items.Add(New ListItem("A/6 MODIFY UNIT"))
        ddlCANreason.Items.Add(New ListItem("F/7 WRONG MATERIAL"))

        ' packing status -------------------------------------
        ddlPackingStatus.Items.Clear()
        Dim pSql As String = "SELECT '-' as SVD_Attribute UNION ALL "
        pSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        pSql &= " WHERE (SVD_Name = 'PackStatus') ORDER BY SVD_Attribute"
        ddlPackingStatus.DataSource = cC.getAsDataTable(pSql, Session("swmsDbConnection"))
        ddlPackingStatus.DataValueField = "SVD_Attribute"
        ddlPackingStatus.DataTextField = "SVD_Attribute"
        ddlPackingStatus.DataBind()
        '
    End Sub

    Sub fillLocations()
        '
        '' location1 ------ Status ----------------
        Dim l1Sql As String = "SELECT LocationId, LocationIdCode FROM Locations WHERE ParentLocationId = 0 AND LocationId > 0"
        ddlLocLvl1.DataSource = cC.getAsDataTable(l1Sql, Session("swmsDbConnection"))
        ddlLocLvl1.DataValueField = "LocationId"
        ddlLocLvl1.DataTextField = "LocationIdCode"
        ddlLocLvl1.DataBind()
        '
        ddlLocLvl1.SelectedIndex = ddlLocLvl1.Items.IndexOf(ddlLocLvl1.Items.FindByText("ACTIVE"))

        '' location2 ------ Location ----------------
        ddlSavLvl2.Items.Clear()
        Dim sql2 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql2 &= " WHERE (LocationLevel = 2)"
        sql2 &= " ORDER BY LocationIdCode"
        Dim rtn2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
        ddlSavLvl2.DataSource = rtn2
        ddlSavLvl2.DataValueField = "ParentLocationID"
        ddlSavLvl2.DataTextField = "Code"
        ddlSavLvl2.DataBind()
        '
        ddlLocLvl2.Items.Clear()
        Dim tli As New ListItem
        tli.Text = "--"
        tli.Value = "0"
        ddlLocLvl2.Items.Add(tli)
        ' re-Populate the control after the data record has been read
        Dim j As Integer = 0
        For i As Integer = 0 To rtn2.Rows.Count - 1
            If rtn2.Rows(i)("ParentLocationID") = ddlLocLvl1.SelectedValue Then
                j = InStr(rtn2.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn2.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn2.Rows(i)("Code"), j + 1)
                ddlLocLvl2.Items.Add(litm)
            End If
        Next

        ' Sub -------------- "Building" -------------------
       ddlSavLvl3.Items.Clear()
        Dim sql3 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql3 &= " WHERE (LocationLevel = 3)"
        sql3 &= " ORDER BY LocationIdCode"
        Dim rtn3 As DataTable = cC.getAsDataTable(sql3, Session("swmsDbConnection"))
        ddlSavLvl3.DataSource = rtn3
        ddlSavLvl3.DataValueField = "ParentLocationID"
        ddlSavLvl3.DataTextField = "Code"
        ddlSavLvl3.DataBind()
        '
        ddlLocLvl3.Items.Clear()
        Dim tli3 As New ListItem
        tli3.Text = "--"
        tli3.Value = "0"
        ddlLocLvl3.Items.Add(tli3)
        ' Populate the control after the data record has been read


        ' Micro -------------- "Bin" -------------------
       ddlSavLvl4.Items.Clear()
        Dim sql4 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql4 &= " WHERE (LocationLevel = 4)"
        sql4 &= " ORDER BY LocationIdCode"
        Dim rtn4 As DataTable = cC.getAsDataTable(sql4, Session("swmsDbConnection"))
        ddlSavLvl4.DataSource = rtn4
        ddlSavLvl4.DataValueField = "ParentLocationID"
        ddlSavLvl4.DataTextField = "Code"
        ddlSavLvl4.DataBind()
        '
        ddlLocLvl4.Items.Clear()
        Dim tli4 As New ListItem
        tli4.Text = "--"
        tli4.Value = "0"
        ddlLocLvl4.Items.Add(tli4)
        ' Populate the control after the data record has been read

    End Sub

    Sub displayAsset(ByVal AId As String)
        Session("AId") = AId

        If CStr(AId) = "" Then
            Response.Redirect("FindAssetsSD.aspx")
        Else
            sql = "SELECT A.AssetId, A.Pid,"
            sql &= " ISNULL(A.SubGroup, '') AS SubGroup,"
            sql &= " ISNULL(A.PartNumber, '') AS PartNumber, "
            sql &= " ISNULL(A.NIIN, '') AS NIIN, "
            sql &= " ISNULL(A.SerialNumber, '') AS SerialNumber,"
            sql &= " ISNULL(A.Nomenclature, '') AS Nomenclature,"
            sql &= " ISNULL(A.ModelNumber, '') AS ModelNumber,"
            sql &= " ISNULL(A.CurrentCondition, '') AS ConditionCode,"
            sql &= " ISNULL(A.PIN, '') AS AcctCd,"
            sql &= " ISNULL(L1.LocationIdCode, 'Unknown') AS Status,"
            sql &= " ISNULL(L2.LocationIdCode, '') + ' - ' + ISNULL(L3.LocationIdCode, '')"
            sql &= "  + ' - ' + ISNULL(L4.LocationIdCode, '') AS Location,"
            sql &= " ISNULL(A.LocationId, 0) as LocN1, "
            sql &= " ISNULL(A.Location2, 0) as LocN2, "
            sql &= " ISNULL(A.Location3, 0) as LocN3, "
            sql &= " ISNULL(A.Location4, 0) as LocN4, "
            sql &= " ISNULL(A.ICNnum, '') AS ICN, ISNULL(ICNseq, 0) AS ICNseq,"
            sql &= " ISNULL(A.Reason, '') AS Reason,"
            sql &= " ISNULL(M.ProcurementCode, '') AS ProcurementCode,"
            sql &= " ISNULL(A.DocumentNumber, '') AS DocumentNumber,"
            sql &= " ISNULL(A.ReceivedFrom, '') AS ReceivedFrom,"
            sql &= " ISNULL(A.Manufacturer, '') AS CAGE,"
            sql &= " ISNULL(A.IssuedTo, '') AS IssuedTo,"

            sql &= " ISNULL(A.A_Cond_Date, '') AS A_Cond_Date,"
            sql &= " ISNULL(A.PackingStatus, '-') AS PackingStatus,"
            sql &= " ISNULL(A.MarkFor, '') AS MarkFor,"
            sql &= " ISNULL(A.ShipWeight, 0.0) AS ShipWeight,"
            sql &= " ISNULL(M.ShipWeight, 0.0) AS MasterWeight,"
            sql &= " ISNULL(A.ShipLength, 0.0) AS ShipLength,"
            sql &= " ISNULL(M.ShipLength,  0.0) AS MasterLength,"
            sql &= " ISNULL(A.ShipWidth, 0.0) AS ShipWidth,"
            sql &= " ISNULL(M.ShipWidth, 0.0) AS MasterWidth,"
            sql &= " ISNULL(A.ShipHeight, 0.0) AS ShipHeight,"
            sql &= " ISNULL(M.ShipHeight, 0.0) AS MasterHeight,"

            sql &= " ISNULL(A.Remarks, '') AS Remarks,"
            sql &= " A.EffectiveDate, A.LastTransDate, "
            sql &= " ISNULL(P1.UserName, '') AS UpdatedBy"
            sql &= " FROM Assets A"
            sql &= " INNER JOIN PartsMaster M On A.Pid = M.Pid"
            sql &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationId"
            sql &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationId"
            sql &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationId"
            sql &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationId"
            sql &= " LEFT OUTER JOIN People P1 ON A.LastTransBy = P1.PeopleId"
            sql &= " WHERE (A.AssetId  = " & AId & ")"

            Dim locId As Integer = 0
            Dim rs As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
            If rs.Rows.Count > 0 Then
                txtPid.Text = rs.Rows(0)("Pid") ' rdr("PID")
                lblAId.Text = rs.Rows(0)("AssetId")
                'lblSerial.Text = rs.Rows(0)("SerialNumber")

                ddlSubGroup.SelectedIndex = ddlSubGroup.Items.IndexOf(ddlSubGroup.Items.FindByValue(rs.Rows(0)("SubGroup")))
                ddlSubGroup.ToolTip = ddlSubGroup.SelectedItem.Text
                lblNiin.Text = rs.Rows(0)("NIIN")
                'lblNiin.ToolTip = rs.Rows(0)("NIIN")
                lblpn.Text = rs.Rows(0)("PartNumber")
                'lblpn.ToolTip = rs.Rows(0)("PartNumber")
                txtSn.Text = rs.Rows(0)("SerialNumber")
                txtSn.ToolTip = rs.Rows(0)("SerialNumber")
                txtModel.Text = rs.Rows(0)("ModelNumber")
                txtModel.ToolTip = rs.Rows(0)("ModelNumber")
                lblNomen.Text = rs.Rows(0)("Nomenclature")
                'lblNomen.ToolTip = rs.Rows(0)("Nomenclature")

                lblPIN.Text = rs.Rows(0)("AcctCd")
                ddlCc.SelectedIndex = ddlCc.Items.IndexOf(ddlCc.Items.FindByValue(rs.Rows(0)("ConditionCode")))
                ddlCc.ToolTip = ddlCc.SelectedItem.Text
                txtICN.Text = rs.Rows(0)("ICN")
                txtICN.ToolTip = rs.Rows(0)("ICN")
                If rs.Rows(0)("ICNseq") <> 0 Then
                    txtICNSeq.Text = Right("0000" & rs.Rows(0)("ICNseq"), 4)
                    txtICNSeq.ToolTip = txtICNSeq.Text
                Else
                    txtICNSeq.Text = ""
                    txtICNSeq.ToolTip = txtICNSeq.Text
                End If
                ddlReason.SelectedIndex = ddlReason.Items.IndexOf(ddlReason.Items.FindByValue(rs.Rows(0)("Reason")))
                ddlReason.ToolTip = ddlReason.SelectedItem.Text
                txtReceivedFrom.Text = ""       'UCase(rs.Rows(0)("ReceivedFrom"))
                txtReceivedFrom.ToolTip = UCase(rs.Rows(0)("ReceivedFrom"))

                txtDocNum.Text = ""     'rs.Rows(0)("DocumentNumber")
                txtDocNum.ToolTip = rs.Rows(0)("DocumentNumber")
                lblCage.Text = rs.Rows(0)("CAGE")  ' rdr("manu")
                lblCage.ToolTip = rs.Rows(0)("CAGE")  ' rdr("manu")
                txtIssuedTo.Text = ""       'UCase(rs.Rows(0)("IssuedTo"))
                txtIssuedTo.ToolTip = UCase(rs.Rows(0)("IssuedTo"))
                lblUpdatedBy.Text = rs.Rows(0)("UpdatedBy")

                If Not IsDBNull(rs.Rows(0)("A_Cond_Date")) Then
                    If CDate(rs.Rows(0)("A_Cond_Date")) = CDate("1/1/1900") Then
                        txtACondDate.Text = ""
                        txtACondDate.ToolTip = ""
                    Else
                        txtACondDate.Text = FormatDateTime(rs.Rows(0)("A_Cond_Date"), DateFormat.ShortDate)
                        txtACondDate.ToolTip = FormatDateTime(rs.Rows(0)("A_Cond_Date"), DateFormat.ShortDate)
                    End If
                End If
                ddlPackingStatus.SelectedIndex = ddlPackingStatus.Items.IndexOf(ddlPackingStatus.Items.FindByValue(rs.Rows(0)("PackingStatus")))
                txtMarkFor.Text = UCase(rs.Rows(0)("MarkFor"))
                lblMasterWeight.Text = FormatNumber(UCase(rs.Rows(0)("MasterWeight")), 0, , , False) & " lbs."
                lblMasterLength.Text = FormatNumber(UCase(rs.Rows(0)("MasterLength")), 0, , , False) & " inches"
                lblMasterWidth.Text = FormatNumber(UCase(rs.Rows(0)("MasterWidth")), 0, , , False) & " inches"
                lblMasterHeight.Text = FormatNumber(UCase(rs.Rows(0)("MasterHeight")), 0, , , False) & " inches"
                txtShipWeight.Text = FormatNumber(UCase(rs.Rows(0)("ShipWeight")), 0, , , False)
                txtShipLength.Text = FormatNumber(UCase(rs.Rows(0)("ShipLength")), 0, , , False)
                txtShipWidth.Text = FormatNumber(UCase(rs.Rows(0)("ShipWidth")), 0, , , False)
                txtShipHeight.Text = FormatNumber(UCase(rs.Rows(0)("ShipHeight")), 0, , , False)

                ' '' Remarks from before are seen in the history, this remarks is for now.
                '    Need to talk with Sandra about how to change the Asset.Remarks to Notes and keep the AssetHistory.Remarks seperate.
                txtRemarks.Text = rs.Rows(0)("remarks")
                ' '' Effective date should only be filled in as an override by the user.
                ' ''If Not IsDBNull(rs.Rows(0)("EffectiveDate")) Then
                ' ''    If CStr(rs.Rows(0)("EffectiveDate")) <> "1/1/1900" Then
                ' ''        txtEffDate.Text = rs.Rows(0)("EffectiveDate")
                ' ''    End If
                ' ''End If
                txtEffDate.Text = ""
                If Not IsDBNull(rs.Rows(0)("LastTransDate")) Then
                    If CStr(rs.Rows(0)("LastTransDate")) <> "1/1/1900" Then
                        lblRowCount.Text = FormatDateTime(rs.Rows(0)("LastTransDate"), 2)
                        lblHistoryDate.Text = FormatDateTime(rs.Rows(0)("LastTransDate"), 2)
                    End If
                End If


                ddlLocLvl1.SelectedIndex = ddlLocLvl1.Items.IndexOf(ddlLocLvl1.Items.FindByValue(rs.Rows(0)("LocN1")))
                ddlLocLvl1.ToolTip = ddlLocLvl1.SelectedItem.Text
                '
                Dim tliz As New ListItem
                tliz.Text = "--"
                tliz.Value = "0"
                ' re-Populate the controls after the data record has been read
                ddlLocLvl2.Items.Clear()
                ddlLocLvl2.Items.Add(tliz)
                Dim j As Integer = 0
                For i As Integer = 0 To ddlSavLvl2.Items.Count - 1
                    If ddlSavLvl2.Items(i).Value = ddlLocLvl1.SelectedValue Then
                        j = InStr(ddlSavLvl2.Items(i).Text, "@")
                        Dim litm As New ListItem
                        litm.Value = Left(ddlSavLvl2.Items(i).Text, j - 1)
                        litm.Text = Mid(ddlSavLvl2.Items(i).Text, j + 1)
                        ddlLocLvl2.Items.Add(litm)
                    End If
                Next
                ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByValue(rs.Rows(0)("LocN2")))
                ddlLocLvl2.ToolTip = ddlLocLvl2.SelectedItem.Text
                '
                ddlLocLvl3.Items.Clear()
                Dim tlix As New ListItem
                tlix.Text = "--"
                tlix.Value = "0"
                ddlLocLvl3.Items.Add(tlix)
                j = 0
                For i As Integer = 0 To ddlSavLvl3.Items.Count - 1
                    If ddlSavLvl3.Items(i).Value = ddlLocLvl2.SelectedValue Then
                        j = InStr(ddlSavLvl3.Items(i).Text, "@")
                        Dim litm As New ListItem
                        litm.Value = Left(ddlSavLvl3.Items(i).Text, j - 1)
                        litm.Text = Mid(ddlSavLvl3.Items(i).Text, j + 1)
                        ddlLocLvl3.Items.Add(litm)
                    End If
                Next
                ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(rs.Rows(0)("LocN3")))
                ddlLocLvl3.ToolTip = ddlLocLvl3.SelectedItem.Text
                '
                ddlLocLvl4.Items.Clear()
                Dim tliy As New ListItem
                tliy.Text = "--"
                tliy.Value = "0"
                ddlLocLvl4.Items.Add(tliy)
                j = 0
                For i As Integer = 0 To ddlSavLvl4.Items.Count - 1
                    If ddlSavLvl4.Items(i).Value = ddlLocLvl3.SelectedValue Then
                        j = InStr(ddlSavLvl4.Items(i).Text, "@")
                        Dim litm As New ListItem
                        litm.Value = Left(ddlSavLvl4.Items(i).Text, j - 1)
                        litm.Text = Mid(ddlSavLvl4.Items(i).Text, j + 1)
                        ddlLocLvl4.Items.Add(litm)
                    End If
                Next
                ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(rs.Rows(0)("LocN4")))
                ddlLocLvl4.ToolTip = ddlLocLvl4.SelectedItem.Text
                '
                'txtAHId.Text = rs.Rows(0)("AssetHistoryId")

                Dim hSql As String = "SELECT "
                hSql &= " AH.AssetHistoryId, AH.AssetId, ISNULL(AH.ConditionCode, '') AS ConditionCode, "
                hSql &= " ISNULL(AH.TransType, '') AS TransType, AH.TransDate, "
                hSql &= " ISNULL(P1.UserName, '') AS UpdBy,"
                hSql &= " ISNULL(AH.Remarks, '') AS Remarks, "
                hSql &= " ISNULL(AH.Reason, '') AS Reason, "
                hSql &= " ISNULL(AH.DocumentNumber, '') AS DocumentNumber, "
                hSql &= " ISNULL(AH.LocationId, 0) AS LocationId, "
                hSql &= " ISNULL(AH.Location2, 0) AS Location2, "
                hSql &= " ISNULL(AH.Location3, 0) AS Location3, "
                hSql &= " ISNULL(AH.Location4, 0) AS Location4, "
                hSql &= " ISNULL(AH.Location1Text, '') AS Location1Text, "
                hSql &= " ISNULL(AH.Location2Text, '') AS Location2Text, "
                hSql &= " ISNULL(AH.Location3Text, '') AS Location3Text, "
                hSql &= " ISNULL(AH.Location4Text, '') AS Location4Text, "
                hSql &= " ISNULL(AH.Status, '') AS Status, "
                hSql &= " ISNULL(AH.EffectiveDate, '01/01/1900') AS EffectiveDate,"
                hSql &= " ISNULL(AH.ICNnum, '') AS ICNnum, "
                hSql &= " ISNULL(AH.ICNSeq, 0) AS ICNseq,"
                hSql &= " ISNULL(AH.SubGroup, '') AS SubGroup, "
                hSql &= " ISNULL(AH.ReceivedFrom, '') AS ReceivedFrom, "
                hSql &= " ISNULL(AH.IssuedTo, '') AS IssuedTo, "
                hSql &= " ISNULL(AH.PIN, '') AS Acct"
                hSql &= " FROM AssetHistory AH "
                hSql &= " LEFT OUTER JOIN People P1 ON AH.TransBy = P1.PeopleId "
                hSql &= " WHERE (AH.AssetId = " & AId & ") "
                Select Case hidSrtBy.Text
                    Case "Eff"
                        'Get_Data(", P2.UserName")
                        hSql &= " ORDER BY AH.EffectiveDate, AH.AssetHistoryId desc"
                    Case "EffDown"
                        'Get_Data(", P2.UserName DESC")
                        hSql &= " ORDER BY AH.EffectiveDate DESC, AH.AssetHistoryId desc"
                    Case "Trn"
                        'Get_Data(", P1.UserName")
                        hSql &= " ORDER BY AH.TransDate, AH.AssetHistoryId desc"
                    Case "TrnDown"
                        'Get_Data(", P1.UserName DESC")
                        hSql &= " ORDER BY AH.TransDate DESC, AH.AssetHistoryId desc"
                    Case Else
                        hSql &= " ORDER BY AH.TransDate DESC, AH.AssetHistoryId desc"
                End Select

                Dim rf As DataTable = cC.getAsDataTable(hSql, Session("swmsDbConnection"))
                Dim altRow As Boolean = False
                If rf.Rows.Count > 0 Then
                    'headerRow()
                    lblRowCount.Text = rf.Rows.Count & " Records"
                    Dim i As Integer
                    For i = 0 To rf.Rows.Count - 1
                        Dim row As New TableRow ' --- this is the regular stuff --
                        If IsDBNull(rf.Rows(i)("EffectiveDate")) Then
                            row.Cells.Add(cC.DataCell(""))
                        Else
                            If DateTime.Parse(CStr(rf.Rows(i)("EffectiveDate"))).ToShortDateString.Contains("1900") Then
                                row.Cells.Add(cC.DataCell(""))
                            Else
                                row.Cells.Add(cC.DataCell(FormatDateTime(rf.Rows(i)("EffectiveDate"), 2)))
                            End If
                        End If
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("TransType")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("ConditionCode")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("Location1Text") & " - " & rf.Rows(i)("Location2Text") & " - " & rf.Rows(i)("Location3Text") & " - " & rf.Rows(i)("Location4Text")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("Reason")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("DocumentNumber") & "&nbsp;"))
                        If rf.Rows(i)("ICNseq") > 0 Then
                            row.Cells.Add(cC.DataCell(rf.Rows(i)("ICNnum") & "-" & Right("0000" & rf.Rows(i)("ICNseq"), 4) & "&nbsp;"))
                        Else
                            row.Cells.Add(cC.DataCell(rf.Rows(i)("ICNnum") & "&nbsp;"))
                        End If
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("SubGroup") & "&nbsp;" & rf.Rows(i)("Acct")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("ReceivedFrom")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("IssuedTo")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("Remarks")))
                        row.Cells.Add(cC.DataCell(rf.Rows(i)("UpdBy")))
                        If IsDBNull(rf.Rows(i)("TransDate")) Then
                            row.Cells.Add(cC.DataCell(""))
                        Else
                            row.Cells.Add(cC.DataCell(FormatDateTime(rf.Rows(i)("TransDate"), DateFormat.ShortDate), , , FormatDateTime(rf.Rows(i)("TransDate"), DateFormat.GeneralDate)))
                        End If
                        '
                        If altRow = True Then
                            row.BackColor = Drawing.Color.White
                            altRow = False
                        Else
                            row.BackColor = Drawing.Color.WhiteSmoke
                            altRow = True
                        End If
                        '
                        HistTab.Rows.Add(row)
                    Next
                End If
            Else
                lblRowCount.Text = "No Records found"
                txtAHId.Text = 0
            End If
            End If

    End Sub

    'Sub headerRow()

    '    Dim row As New TableRow ' --- this is the regular stuff --
    '    Dim ed As New TableCell
    '    Dim 
    '    ed.Text = "Effective"
    '    row.Cells.Add(ed)

    '    Dim tt As New TableCell
    '    tt.Text = "Type"
    '    row.Cells.Add(tt)

    '    Dim c1 As New TableCell
    '    c1.Text = "CC"
    '    row.Cells.Add(c1)

    '    Dim lo As New TableCell
    '    lo.Text = "Location"
    '    row.Cells.Add(lo)

    '    Dim re As New TableCell
    '    re.Text = "Reason"
    '    row.Cells.Add(re)

    '    Dim dc As New TableCell
    '    dc.Text = "Document"
    '    row.Cells.Add(dc)

    '    Dim ic As New TableCell
    '    ic.Text = "ICN"
    '    row.Cells.Add(ic)

    '    Dim sb As New TableCell
    '    sb.Text = "SubGroup/Acct"
    '    row.Cells.Add(sb)

    '    Dim rf As New TableCell
    '    rf.Text = "Received From"
    '    row.Cells.Add(rf)

    '    Dim it As New TableCell
    '    it.Text = "Issued To"
    '    row.Cells.Add(it)

    '    Dim rm As New TableCell
    '    rm.Text = "History Remarks"
    '    row.Cells.Add(rm)

    '    Dim ub As New TableCell
    '    ub.Text = "Updated By"
    '    row.Cells.Add(ub)

    '    Dim td As New TableCell
    '    td.Text = "Trans Date"
    '    row.Cells.Add(td)

    '    row.BackColor = Drawing.Color.DodgerBlue
    '    HistTab.Rows.Add(row)

    'End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect("./MaintainAssetSD.aspx?id=" & Request.QueryString("id"))
    End Sub

    Sub check4change()
        '
        Dim changefound As Integer = 0
        Dim errorfound As Integer = 0
        Dim uSql As String = "DECLARE @RightNow as datetime; SELECT @RightNow = Getdate(); UPDATE Assets SET LastTransBy = " & Session("SWMSUId")
        Dim notes As String = ""
        '
        sql = "SELECT A.AssetId, A.Pid,"
        sql &= " ISNULL(A.SubGroup, '') AS SubGroup,"
        sql &= " ISNULL(A.PartNumber, '') AS PartNumber, "
        sql &= " ISNULL(A.NIIN, '') AS NIIN, "
        sql &= " ISNULL(A.SerialNumber, '') AS SerialNumber,"
        sql &= " ISNULL(A.Nomenclature, '') AS Nomenclature,"
        sql &= " ISNULL(A.ModelNumber, '') AS ModelNumber,"
        sql &= " ISNULL(A.CurrentCondition, '') AS ConditionCode,"
        sql &= " ISNULL(A.PIN, '') AS AcctCd,"
        sql &= " ISNULL(L1.LocationIdCode, 'Unknown') AS Status,"
        sql &= " ISNULL(L2.LocationIdCode, '') + ' - ' + ISNULL(L3.LocationIdCode, '')"
        sql &= "  + ' - ' + ISNULL(L4.LocationIdCode, '') AS Location,"
        sql &= " ISNULL(A.LocationId, 0) as LocN1, "
        sql &= " ISNULL(A.Location2, 0) as LocN2, "
        sql &= " ISNULL(A.Location3, 0) as LocN3, "
        sql &= " ISNULL(A.Location4, 0) as LocN4, "
        sql &= " ISNULL(A.ICNnum, '') AS ICN, ISNULL(ICNseq, 0) AS ICNseq,"
        sql &= " ISNULL(A.Reason, '') AS Reason,"
        sql &= " ISNULL(M.ProcurementCode, '') AS ProcurementCode,"
        sql &= " ISNULL(A.DocumentNumber, '') AS DocumentNumber,"
        sql &= " ISNULL(A.ReceivedFrom, '') AS ReceivedFrom,"
        sql &= " ISNULL(A.Manufacturer, '') AS CAGE,"
        sql &= " ISNULL(A.IssuedTo, '') AS IssuedTo,"

        sql &= " ISNULL(A.A_Cond_Date, '') AS A_Cond_Date,"
        sql &= " ISNULL(A.PackingStatus, '-') AS PackingStatus,"
        sql &= " ISNULL(A.MarkFor, '') AS MarkFor,"
        sql &= " ISNULL(A.ShipWeight, 0.0) AS ShipWeight,"
        sql &= " ISNULL(A.ShipLength, 0.0) AS ShipLength,"
        sql &= " ISNULL(A.ShipWidth, 0.0) AS ShipWidth,"
        sql &= " ISNULL(A.ShipHeight, 0.0) AS ShipHeight,"

        sql &= " ISNULL(A.Remarks, '') AS Remarks,"
        sql &= " A.EffectiveDate, A.LastTransDate, "
        sql &= " ISNULL(P1.UserName, '') AS UpdatedBy"
        sql &= " FROM Assets A"
        sql &= " INNER JOIN PartsMaster M On A.Pid = M.Pid"
        sql &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationId"
        sql &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationId"
        sql &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationId"
        sql &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationId"
        sql &= " LEFT OUTER JOIN People P1 ON A.LastTransBy = P1.PeopleId"
        sql &= " WHERE (A.AssetId  = " & thisId & ")"

        Dim locId As Integer = 0
        Dim rs As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
        '
        If rs.Rows.Count > 0 Then
            Dim EffDateReq As Boolean = False
            'SubGroup
            If Request.Form("ddlSubGroup") <> rs.Rows(0)("SubGroup") Then
                changefound += 1
                uSql &= ", SubGroup = '" & Request.Form("ddlSubGroup") & "'"
                uSql &= ", PIN = (SELECT ProgramType FROM Programs WHERE (ProgramName = '" & Request.Form("ddlSubGroup") & "'))"
                notes &= " SubGroup/Acct from " & rs.Rows(0)("SubGroup") & "/' + "
                notes &= "(SELECT ProgramType FROM Programs WHERE (ProgramName = '" & rs.Rows(0)("SubGroup") & "')) + '"
                notes &= " to " & Request.Form("ddlSubGroup") & "/' + "
                notes &= "(SELECT ProgramType FROM Programs WHERE (ProgramName = '" & Request.Form("ddlSubGroup") & "')) + ', "
            End If
            'Serial Number ***
            If Request.Form("txtSn") <> rs.Rows(0)("SerialNumber") Then
                '  validSerial upplies the change transaction for the serial number
                If validSerial(thisId, Request.Form("txtSn")) = True Then
                    changefound += 1
                Else
                    errorfound += 1
                End If
            End If
            'Model Number
            If Request.Form("txtModel") <> rs.Rows(0)("ModelNumber") Then
                changefound += 1
                uSql &= ", ModelNumber = '" & Request.Form("txtModel") & "'"
                notes &= " ModelNumber from (" & rs.Rows(0)("ModelNumber") & ") to (" & Request.Form("txtModel") & "), "
            End If
            'Current Condition
            Dim CC2A As Boolean = False
            If Request.Form("ddlCc") <> rs.Rows(0)("ConditionCode") Then
                'special routine when changeing to A condition
                If Request.Form("ddlCc") = "A" Then
                    CC2A = True
                End If
                changefound += 1
                uSql &= ", CurrentCondition = '" & Request.Form("ddlCc") & "' "
                notes &= " CurrentCondition from (" & rs.Rows(0)("ConditionCode") & ") to (" & Request.Form("ddlCc") & "), "
            End If
            'A Condition Date
            'Response.Write("Form= " & Request.Form("txtACondDate") & " database= " & rs.Rows(0)("A_Cond_Date"))
            'Response.Flush()       1/1/1900
            If (IsDate(Request.Form("txtACondDate"))) And IsDate(rs.Rows(0)("A_Cond_Date")) Then
                If CDate(Request.Form("txtACondDate")) <> CDate(rs.Rows(0)("A_Cond_Date")) Then
                    If CDate(Request.Form("txtACondDate")) > CDate(Today) Then
                        errorfound += 1
                        UsrMsg.Value &= "Dates in the future are not allowed" & Chr(13)
                    Else
                        changefound += 1
                        uSql &= ", A_Cond_Date = '" & Request.Form("txtACondDate") & "'"
                        notes &= " A_Cond_Date change to " & Request.Form("txtACondDate") & ", "
                    End If
                End If
            ElseIf IsDate(Request.Form("txtACondDate")) Then
                If CDate(Request.Form("txtACondDate")) > CDate(Today) Then
                    errorfound += 1
                    UsrMsg.Value &= "Dates in the future are not allowed" & Chr(13)
                Else
                    changefound += 1
                    uSql &= ", A_Cond_Date = '" & Request.Form("txtACondDate") & "'"
                    notes &= " A_Cond_Date set to " & Request.Form("txtACondDate") & ", "
                End If
            ElseIf (IsDate(rs.Rows(0)("A_Cond_Date"))) And (CC2A = False) Then
                If CDate(rs.Rows(0)("A_Cond_Date")) <> CDate("1/1/1900") Then
                    changefound += 1
                    uSql &= ", A_Cond_Date = NULL"
                    notes &= " A_Cond_Date removed, "
                End If
            Else
                If CC2A = True Then
                    'special routine when changeing to A condition
                    If IsDate(Request.Form("txtEffDate")) Then
                        If CDate(Request.Form("txtEffDate")) > CDate(Today) Then
                            errorfound += 1
                            UsrMsg.Value &= "Dates in the future are not allowed" & Chr(13)
                        Else
                            uSql &= ", A_Cond_Date = '" & Request.Form("txtEffDate") & "'"
                        End If
                    Else
                        uSql &= ", A_Cond_Date = @RightNow "
                    End If
                End If
            End If

            'Status
            If Request.Form("ddlLocLvl1") <> rs.Rows(0)("LocN1") Then
                changefound += 1
                uSql &= ", LocationId = " & Request.Form("ddlLocLvl1") & " "
                ' add to notes later when we know the text of where the asset moved
            End If
            'Location
            If Request.Form("ddlLocLvl2") <> rs.Rows(0)("LocN2") Then
                changefound += 1
                uSql &= ", Location2 = " & Request.Form("ddlLocLvl2") & " "
            End If
            'Bulding
            If Request.Form("ddlLocLvl3") <> rs.Rows(0)("LocN3") Then
                changefound += 1
                uSql &= ", Location3 = " & Request.Form("ddlLocLvl3") & " "
            End If
            'Bin
            If Request.Form("ddlLocLvl4") <> rs.Rows(0)("LocN4") Then
                changefound += 1
                uSql &= ", Location4 = " & Request.Form("ddlLocLvl4") & " "
            End If
            'ICN
            If Request.Form("txtICN") <> rs.Rows(0)("ICN") Then
                changefound += 1
                uSql &= ", ICNnum = '" & Request.Form("txtICN") & "'"
                notes &= " ICN from (" & rs.Rows(0)("ICN") & ") to (" & Request.Form("txtICN") & "), "
            End If
            'ICNseq
            If valInt(Request.Form("txtICNseq")) Or Request.Form("txtICNseq") = "" Then
                Dim t As String = Right("0000" & Request.Form("txtICNseq"), 4)
                Dim d As String = Right("0000" & CStr(rs.Rows(0)("ICNseq")), 4)
                If t <> d Then
                    changefound += 1
                    uSql &= ", ICNseq = " & t & " "
                    notes &= " ICN seq from " & d & " to " & t & ", "
                End If
            Else
                errorfound += 1
                UsrMsg.Value &= "ICN sequence number error. " & Chr(13)
            End If
            'Received From
            If Request.Form("txtReceivedFrom") <> "" Then
                EffDateReq = True
                changefound += 1
                uSql &= ", ReceivedFrom = '" & Request.Form("txtReceivedFrom") & "'"
                notes &= " Received From " & Request.Form("txtReceivedFrom") & ", "
            End If
            'Document Number
            If Request.Form("txtDocNum") <> "" Then
                EffDateReq = True
                changefound += 1
                uSql &= ", DocumentNumber = '" & Request.Form("txtDocNum") & "'"
                notes &= " Document " & Request.Form("txtDocNum") & ", "
            End If
            'Issued To
            If Request.Form("txtIssuedTo") <> "" Then
                EffDateReq = True
                changefound += 1
                uSql &= ", IssuedTo = '" & Request.Form("txtIssuedTo") & "'"
                notes &= " IssuedTo " & Request.Form("txtIssuedTo") & ", "
            End If

            'PackingStatus
            If Request.Form("ddlPackingStatus") <> rs.Rows(0)("PackingStatus") Then
                changefound += 1
                If Request.Form("ddlPackingStatus") = "-" Then
                    uSql &= ", PackingStatus = NULL"
                    notes &= " PackingStatus From (" & rs.Rows(0)("PackingStatus") & ") to (), "
                Else
                    uSql &= ", PackingStatus = '" & Request.Form("ddlPackingStatus") & "'"
                    notes &= " PackingStatus from (" & rs.Rows(0)("PackingStatus") & ") to (" & Request.Form("ddlPackingStatus") & "), "
                End If
            End If
            'MarkFor
            If Request.Form("txtMarkFor") <> rs.Rows(0)("MarkFor") Then
                changefound += 1
                uSql &= ", MarkFor = '" & Request.Form("txtMarkFor") & "'"
                notes &= " Mark For from (" & rs.Rows(0)("MarkFor") & ") to (" & Request.Form("txtMarkFor") & "), "
            End If

            Dim tstStr As String = ""
            'ShipWeight
            If valDec(Request.Form("txtShipWeight")) Then
                If Request.Form("txtShipWeight") = "" Then
                    tstStr = "0.00"
                Else
                    tstStr = Request.Form("txtShipWeight")
                End If
                If CDec(tstStr) > CDec("999999.99") Then
                    errorfound += 1
                    UsrMsg.Value &= "Asset too heavy for shipping." & Chr(13)
                Else
                    If tstStr <> rs.Rows(0)("ShipWeight") Then
                        changefound += 1
                        If tstStr = "0.00" Then
                            uSql &= ", ShipWeight = NULL"
                            notes &= " Shipping Weight from " & FormatNumber(rs.Rows(0)("ShipWeight"), 0, , , 0) & " to 0, "
                        Else
                            uSql &= ", ShipWeight = " & tstStr
                            notes &= " Shipping Weight from " & FormatNumber(rs.Rows(0)("ShipWeight"), 0, , , 0) & " to " & FormatNumber(tstStr, 0, , , 0) & ", "
                        End If
                    End If
                End If
            Else
                errorfound += 1
                UsrMsg.Value &= "Shipping Weight error." & Chr(13)
            End If
            'ShipLength
            If valDec(Request.Form("txtShipLength")) Then
                If Request.Form("txtShipLength") = "" Then
                    tstStr = "0.00"
                Else
                    tstStr = Request.Form("txtShipLength")
                End If
                If CDec(tstStr) > CDec("999999.99") Then
                    errorfound += 1
                    UsrMsg.Value &= "Asset too long for shipping." & Chr(13)
                Else
                    If tstStr <> rs.Rows(0)("ShipLength") Then
                        changefound += 1
                        If tstStr = "0.00" Then
                            uSql &= ", ShipLength = NULL"
                            notes &= " Shipping Length from " & FormatNumber(rs.Rows(0)("ShipLength"), 0, , , 0) & " to 0, "
                        Else
                            uSql &= ", ShipLength = " & tstStr
                            notes &= " Shipping Length from " & FormatNumber(rs.Rows(0)("ShipLength"), 0, , , 0) & " to " & FormatNumber(tstStr, 0, , , 0) & ", "
                        End If
                    End If
                End If
            Else
                errorfound += 1
                UsrMsg.Value &= "Shipping Length error." & Chr(13)
            End If
            'ShipWidth
            If valDec(Request.Form("txtShipWidth")) Then
                If Request.Form("txtShipWidth") = "" Then
                    tstStr = "0.00"
                Else
                    tstStr = Request.Form("txtShipWidth")
                End If
                If CDec(tstStr) > CDec("999999.99") Then
                    errorfound += 1
                    UsrMsg.Value &= "Asset too wide for shipping." & Chr(13)
                Else
                    If tstStr <> rs.Rows(0)("ShipWidth") Then
                        changefound += 1
                        If tstStr = "0.00" Then
                            uSql &= ", ShipWidth = " & tstStr
                            notes &= " Shipping Width from " & FormatNumber(rs.Rows(0)("ShipWidth"), 0, , , 0) & " to 0, "
                        Else
                            uSql &= ", ShipWidth = " & tstStr
                            notes &= " Shipping Width from " & FormatNumber(rs.Rows(0)("ShipWidth"), 0, , , 0) & " to " & FormatNumber(tstStr, 0, , , 0) & ", "
                        End If
                    End If
                End If
            Else
                errorfound += 1
                UsrMsg.Value &= "Shipping Width error." & Chr(13)
            End If
            'ShipHeight
            If valDec(Request.Form("txtShipHeight")) Then
                If Request.Form("txtShipHeight") = "" Then
                    tstStr = "0.00"
                Else
                    tstStr = Request.Form("txtShipHeight")
                End If
                If CDec(tstStr) > CDec("999999.99") Then
                    errorfound += 1
                    UsrMsg.Value &= "Asset too wide for shipping." & Chr(13)
                Else
                    If tstStr <> rs.Rows(0)("ShipHeight") Then
                        changefound += 1
                        If tstStr = "0.00" Then
                            uSql &= ", ShipHeight = " & tstStr
                            notes &= " Shipping Height from " & FormatNumber(rs.Rows(0)("ShipHeight"), 0, , , 0) & " to 0, "
                        Else
                            uSql &= ", ShipHeight = " & tstStr
                            notes &= " Shipping Height from " & FormatNumber(rs.Rows(0)("ShipHeight"), 0, , , 0) & " to " & FormatNumber(tstStr, 0, , , 0) & ", "
                        End If
                    End If
                End If
            Else
                errorfound += 1
                UsrMsg.Value &= "Shipping Height error." & Chr(13)
            End If

            'Remarks
            If Request.Form("txtRemarks") <> rs.Rows(0)("Remarks") Then
                changefound += 1
                uSql &= ", Remarks = '" & Left(cC.BufStr(Request.Form("txtRemarks")), 500) & "'"
                notes &= " Asset Notes Updated. "
            End If
            'Reason
            If Request.Form("ddlReason") <> "" Then
                'changefound += 1   Reason is not a change
                uSql &= ", Reason = '" & Request.Form("ddlReason") & "'"
                notes &= " Reason " & Request.Form("ddlReason") & ". "
            End If

            uSql &= " WHERE (AssetId = " & thisId & "); "

            'add to history
            uSql &= " INSERT INTO AssetHistory ("
            uSql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
            uSql &= " LocationId, Location2, Location3, Location4,"
            uSql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
            uSql &= " Status,"
            uSql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
            '
            uSql &= " SELECT AssetId, "
            uSql &= " ISNULL(CurrentCondition, '') AS ConditionCode, "
            uSql &= " 'ASSET MAINT' AS TransType, "
            uSql &= " @RightNow AS TransDate, "
            uSql &= Session("SWMSUId") & " AS TransBy, "

            If Request.Form("ddlLocLvl1") <> rs.Rows(0)("LocN1") Or _
                Request.Form("ddlLocLvl2") <> rs.Rows(0)("LocN2") Or _
                Request.Form("ddlLocLvl3") <> rs.Rows(0)("LocN3") Or _
                Request.Form("ddlLocLvl4") <> rs.Rows(0)("LocN4") Then
                'include the notes from above
                uSql &= " '" & notes & " Asset moved from " & rs.Rows(0)("Status") & " - " & rs.Rows(0)("Location") & " to ' + "
                uSql &= " ISNULL(L1.LocationIdCode, '') + ' - ' +"
                uSql &= " ISNULL(L2.LocationIdCode, '') + ' - ' + ISNULL(L3.LocationIdCode, '')"
                uSql &= " + ' - ' + ISNULL(L4.LocationIdCode, '') AS Remarks, "
            Else
                uSql &= " '" & Left(notes, 500) & "' AS Remarks, "
            End If
            uSql &= " '" & Request.Form("ddlReason") & "' AS Reason, "
            uSql &= " '" & cC.BufStr(Request.Form("txtDocNum")) & "' AS DocumentNumber, "
            uSql &= " Assets.LocationId, "
            uSql &= " Assets.Location2, "
            uSql &= " Assets.Location3, "
            uSql &= " Assets.Location4, "
            uSql &= " L1.LocationIdCode AS Location1Text, "
            uSql &= " L2.LocationIdCode AS Location2Text, "
            uSql &= " L3.LocationIdCode AS Location3Text, "
            uSql &= " L4.LocationIdCode AS Location4Text,"
            uSql &= " L1.LocationIdCode AS Status, "
            If EffDateReq = True Then
                If Not IsDate(Request.Form("txtEffDate")) Then
                    errorfound += 1
                    UsrMsg.Value &= "Effective Date Required." & Chr(13)
                Else
                    uSql &= " '" & Request.Form("txtEffDate") & "' AS EffectiveDate, "
                End If
            ElseIf IsDate(Request.Form("txtEffDate")) Then
                If CDate(Request.Form("txtEffDate")) > CDate(Today) Then
                    errorfound += 1
                    UsrMsg.Value &= "Future Effective Date not allowed." & Chr(13)
                Else
                    uSql &= " '" & Request.Form("txtEffDate") & "' AS EffectiveDate, "
                End If
            Else
                uSql &= " @RightNow AS EffectiveDate, "
            End If
            uSql &= " ICNnum, "
            uSql &= " ICNSeq, "
            uSql &= " SubGroup, "
            uSql &= " '" & cC.BufStr(Request.Form("txtReceivedFrom")) & "' AS ReceivedFrom, "
            uSql &= " '" & cC.BufStr(Request.Form("txtIssuedTo")) & "' AS IssuedTo, "
            uSql &= " PIN"
            uSql &= " FROM Assets"
            uSql &= " LEFT OUTER JOIN Locations L1 ON Assets.LocationId = L1.LocationId"
            uSql &= " LEFT OUTER JOIN Locations L2 ON Assets.Location2 = L2.LocationId"
            uSql &= " LEFT OUTER JOIN Locations L3 ON Assets.Location3 = L3.LocationId"
            uSql &= " LEFT OUTER JOIN Locations L4 ON Assets.Location4 = L4.LocationId"
            uSql &= " WHERE (AssetId = " & thisId & "); "

            If errorfound > 0 Then
                'skip procesing because you found an error.
                'UsrMsg.Value = Left(UsrMsg.Value, 55) & Chr(13)
                UsrMsg.Value = UsrMsg.Value & Chr(13)
                UsrMsg.Value &= errorfound.ToString & " error(s) found.   No transaction applied."
            Else
                If changefound > 0 Then
                    '
                    cC.executeNonQuery(uSql, Session("swmsDbConnection"))
                    cC.LogIt("assets", "Assets: niin:" & rs.Rows(0)("NIIN") & " S/N:" & rs.Rows(0)("SerialNumber") & " Multiple changes.", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))

                    ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' ' 

                    If changefound = 1 Then
                        UsrMsg.Value = "One change found.  One transaction applied."
                    Else
                        UsrMsg.Value = changefound.ToString & " changes applied."
                    End If
                Else
                    UsrMsg.Value = "No change found.  No transaction applied."
                End If
            End If

            reCycleMemories()

            Response.Redirect("./MaintainAssetSD.aspx?id=" & Request.QueryString("id"))

        End If

    End Sub

    Sub reCycleMemories()
        '--- clear existing memories
        sql = "DELETE FROM Memories WHERE (Page = 'MaintainAssetSD') AND (UserId = " & Session("SWMSUId") & "); "
        cC.executeNonQuery(sql, Session("swmsDbConnection"))

        '--- create memories ---
        If UsrMsg.Value <> "" Then
            sql = "INSERT INTO Memories (Page, FieldName, [Value], UserId)"
            sql &= " values ('MaintainAssetSD', 'UsrMsg', '" & Left(UsrMsg.Value, 100) & "',"
            sql &= Session("SWMSUId") & ")"
            cC.executeNonQuery(sql, Session("swmsDbConnection"))
        End If
    End Sub

    Function valInt(ByVal str As String) As Boolean
        Dim reg As New Regex("^([0-9]{0,4})?$")
        If reg.IsMatch(str) Then
            Return True
        Else
            Return False
        End If
    End Function

    Function valDec(ByVal str As String) As Boolean
        Dim reg As New Regex("^([0-9]{0,6})?(\.)?(\d{1,2})?$")
        If reg.IsMatch(str) Then
            Return True
        Else
            Return False
        End If
    End Function

    Function validSerial(ByVal thisId As String, ByVal newSN As String) As Boolean
        '
        Dim trouble As Boolean = False
        '
        Dim sql As String = "SELECT Pid, NIIN, SerialNumber FROM Assets WHERE (AssetId = " & thisId & ")"
        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing
        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(sql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/MaintainAssetsSD.aspx - validSerial")
            Throw ex
        Finally
            swmsDb.Close()
        End Try
        '
        Dim oPid As Integer = 0
        Dim oNIIN As String = ""
        Dim oSerial As String = ""
        Dim NewAssetId As Integer = 0
        '
        If sqldt.Rows.Count > 0 Then
            oPid = sqldt.Rows(0)("Pid")
            oNIIN = sqldt.Rows(0)("NIIN")
            oSerial = sqldt.Rows(0)("SerialNumber")
        End If
        If oSerial <> newSN Then
            Dim sql2 As String = "SELECT A.AssetId, A.LocationId, "
            sql2 &= " L2.LocationIdCode AS L2Code, L3.LocationIdCode AS L3Code, "
            sql2 &= " L4.LocationIdCode AS L4Code"
            sql2 &= " FROM Assets A"
            sql2 &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationId"
            sql2 &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationId"
            sql2 &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationId"
            sql2 &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationId"
            sql2 &= " WHERE (A.SerialNumber = '" & newSN & "') AND (A.NIIN = '" & oNIIN & "') AND (A.AssetId <> " & thisId & ")"
            Dim sqldt2 As DataTable = Nothing
            Try
                Dim SqlCmd2 As New SqlCommand(sql2, swmsDb)
                Dim sqlDA2 As SqlDataAdapter = New SqlDataAdapter(SqlCmd2)
                sqldt2 = New DataTable("Results2")
                sqlDA2.Fill(sqldt2)
            Catch ex As Exception
                cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/IssueAssets.aspx")
            Finally
                swmsDb.Close()
            End Try
            If sqldt2.Rows.Count > 0 Then
                If sqldt2.Rows(0)("LocationId") = 1 Then
                    'if Active Asset - This change is not allowed.  The asset with that serial number is Active.
                    UsrMsg.Value &= "Serial Number " & oSerial & " can not change to " & newSN & " because the new number is Active." & Chr(13)
                    UsrMsg.Value &= "(" & sqldt2.Rows(0)("L2Code") & " - " & sqldt2.Rows(0)("L3Code") & " - " & sqldt2.Rows(0)("L4Code") & ")" & Chr(13)
                    trouble = True
                Else
                    'if Issued Asset - remap old assets history to this one and archive old asset
                    'update oldassetid to aid to current assetid
                    sql = "DECLARE @RightNow as datetime; "
                    sql &= "SELECT @RightNow = Getdate(); "
                    '
                    sql &= "UPDATE AssetHistory SET "
                    sql &= " AssetId = " & thisId & ","
                    sql &= " OldAssetId = " & sqldt2.Rows(0)("AssetId")
                    sql &= " WHERE (AssetId = " & sqldt2.Rows(0)("AssetId") & "); "

                    'then archive old asset
                    sql &= "INSERT INTO AssetArchive"
                    sql &= " (AssetId, PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber, "
                    sql &= " ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition, "
                    sql &= " LocationId, Location2, Location3, Location4, LastMoved, "
                    sql &= " Remarks, SubGroup, DocumentNumber, Reason, ReceivedFrom, "
                    sql &= " IssuedTo, EffectiveDate, LastTrans, LastTransDate, LastTransBy, "
                    sql &= " STOCKNO, DateRecorded, BSSId, VendorId, ModFromPid, PIN, "
                    sql &= " IntendedUse, AcceptanceDate, WarrantyBeginDate, WarrantyExpireDate, "
                    sql &= " A_Cond_Date, PackingStatus, ShipWeight, ShipLength, ShipWidth, ShipHeight, "
                    sql &= " NewId, ArchiveDate, ArchiveBy)"
                    sql &= " SELECT AssetId, PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber, "
                    sql &= " ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition, "
                    sql &= " LocationId, Location2, Location3, Location4, LastMoved, "
                    sql &= " Remarks, SubGroup, DocumentNumber, Reason, ReceivedFrom, "
                    sql &= " IssuedTo, EffectiveDate, LastTrans, LastTransDate, LastTransBy, "
                    sql &= " STOCKNO, DateRecorded, BSSId, VendorId, ModFromPid, PIN, "
                    sql &= " IntendedUse, AcceptanceDate, WarrantyBeginDate, WarrantyExpireDate, "
                    sql &= " A_Cond_Date, PackingStatus, ShipWeight, ShipLength, ShipWidth, ShipHeight, "
                    sql &= thisId & " AS NewId, GETDATE() AS ArchiveDate, " & Session("SWMSUId") & " AS ArchiveBy "
                    sql &= " FROM Assets WHERE (AssetId = " & sqldt2.Rows(0)("AssetId") & "); "

                    'then remove old asset
                    sql &= "DELETE FROM Assets WHERE (AssetId = " & sqldt2.Rows(0)("AssetId") & "); "

                    'update the serial number
                    sql &= "UPDATE Assets SET SerialNumber = '" & newSN & "', "
                    sql &= " EffectiveDate = @RightNow, "
                    sql &= " LastTrans = 'CHANGE SERIAL NUMBER W/HISTORY', "
                    sql &= " LastTransDate = @RightNow, "
                    sql &= " LastTransBy = " & Session("SWMSUId")
                    sql &= " WHERE (AssetId = " & thisId & "); "

                    'add to history
                    sql &= " INSERT INTO AssetHistory ("
                    sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
                    sql &= " LocationId, Location2, Location3, Location4,"
                    sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
                    sql &= " Status,"
                    sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
                    '
                    sql &= " SELECT AssetId, "
                    sql &= " ISNULL(CurrentCondition, '') AS ConditionCode, "
                    sql &= " 'CHANGE SERIAL NUMBER W/HISTORY' AS TransType, "
                    sql &= " @RightNow AS TransDate, "
                    sql &= Session("SWMSUId") & " AS TransBy, "
                    sql &= " 'SERIAL NUMBER CHANGE FROM " & oSerial & " TO " & newSN & "  ASSETID " & sqldt2.Rows(0)("AssetId") & " ARCHIVED' AS Remarks, "
                    sql &= " '" & Request.Form("ddlReason") & "' AS Reason, "
                    sql &= " '" & cC.BufStr(Request.Form("txtDocNum")) & "' AS DocumentNumber, "
                    sql &= " Assets.LocationId, "
                    sql &= " Assets.Location2, "
                    sql &= " Assets.Location3, "
                    sql &= " Assets.Location4, "
                    sql &= " L1.LocationIdCode AS Location1Text, "
                    sql &= " L2.LocationIdCode AS Location2Text, "
                    sql &= " L3.LocationIdCode AS Location3Text, "
                    sql &= " L4.LocationIdCode AS Location4Text,"
                    sql &= " L1.LocationIdCode AS Status, "
                    If IsDate(Request.Form("txtEffDate")) Then
                        sql &= " '" & Request.Form("txtEffDate") & "' AS EffectiveDate, "
                    Else
                        sql &= " @RightNow AS EffectiveDate, "
                    End If
                    sql &= " ICNnum, "
                    sql &= " ICNSeq, "
                    sql &= " SubGroup, "
                    sql &= " '" & cC.BufStr(txtReceivedFrom.Text) & "' AS ReceivedFrom, "
                    sql &= " '" & cC.BufStr(txtIssuedTo.Text) & "' AS IssuedTo, "
                    sql &= " PIN"
                    sql &= " FROM Assets"
                    sql &= " LEFT OUTER JOIN Locations L1 ON Assets.LocationId = L1.LocationId"
                    sql &= " LEFT OUTER JOIN Locations L2 ON Assets.Location2 = L2.LocationId"
                    sql &= " LEFT OUTER JOIN Locations L3 ON Assets.Location3 = L3.LocationId"
                    sql &= " LEFT OUTER JOIN Locations L4 ON Assets.Location4 = L4.LocationId"
                    sql &= " WHERE (AssetId = " & thisId & "); "

                    cC.executeNonQuery(sql, Session("swmsDbConnection"))
                    cC.LogIt("assets", "Assets: niin:" & oNIIN & " S/N:" & newSN & " Archived, AssetId:" & sqldt2.Rows(0)("AssetId") & " ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))
                    cC.LogIt("assets", "Assets: niin:" & oNIIN & " S/N Change from " & oSerial & " to " & newSN & " ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))

                End If
            Else
                'if no rows returned then this is the first time this Asset has been Issued.
                'change the Serial Number, record history and continue on.
                sql = "DECLARE @RightNow as datetime; "
                sql &= "SELECT @RightNow = Getdate(); "
                '
                sql &= " UPDATE Assets SET SerialNumber = '" & newSN & "', "
                sql &= " EffectiveDate = @RightNow, "
                sql &= " LastTrans = 'CHANGE SERIAL NUMBER', "
                sql &= " LastTransDate = @RightNow, "
                sql &= " LastTransBy = " & Session("SWMSUId")
                sql &= " WHERE (AssetId = " & thisId & "); "

                ' insert History
                sql &= " INSERT INTO AssetHistory ("
                sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
                sql &= " LocationId, Location2, Location3, Location4,"
                sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
                sql &= " Status,"
                sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
                '
                sql &= " SELECT AssetId, "
                sql &= " ISNULL(CurrentCondition, '') AS ConditionCode, "
                sql &= " 'CHANGE SERIAL NUMBER' AS TransType, "
                sql &= " @RightNow AS TransDate, "
                sql &= Session("SWMSUId") & " AS TransBy, "
                sql &= " 'SERIAL NUMBER CHANGE FROM " & oSerial & " TO " & newSN & "' AS Remarks, "
                sql &= " '" & Request.Form("ddlReason") & "' AS Reason, "
                sql &= " '" & cC.BufStr(Request.Form("txtDocNum")) & "' AS DocumentNumber, "
                sql &= " Assets.LocationId, "
                sql &= " Assets.Location2, "
                sql &= " Assets.Location3, "
                sql &= " Assets.Location4, "
                sql &= " L1.LocationIdCode AS Location1Text, "
                sql &= " L2.LocationIdCode AS Location2Text, "
                sql &= " L3.LocationIdCode AS Location3Text, "
                sql &= " L4.LocationIdCode AS Location4Text,"
                sql &= " L1.LocationIdCode AS Status, "
                If IsDate(Request.Form("txtEffDate")) Then
                    sql &= " '" & Request.Form("txtEffDate") & "' AS EffectiveDate, "
                Else
                    sql &= " @RightNow AS EffectiveDate, "
                End If
                sql &= " ICNnum, "
                sql &= " ICNSeq, "
                sql &= " SubGroup, "
                sql &= " '" & cC.BufStr(Request.Form("txtReceivedFrom")) & "' AS ReceivedFrom, "
                sql &= " '" & cC.BufStr(Request.Form("txtIssuedTo")) & "' AS IssuedTo, "
                sql &= " PIN"
                sql &= " FROM Assets"
                sql &= " LEFT OUTER JOIN Locations L1 ON Assets.LocationId = L1.LocationId"
                sql &= " LEFT OUTER JOIN Locations L2 ON Assets.Location2 = L2.LocationId"
                sql &= " LEFT OUTER JOIN Locations L3 ON Assets.Location3 = L3.LocationId"
                sql &= " LEFT OUTER JOIN Locations L4 ON Assets.Location4 = L4.LocationId"
                sql &= " WHERE (AssetId = " & thisId & "); "

                cC.executeNonQuery(sql, Session("swmsDbConnection"))
                cC.LogIt("assets", "Assets: niin:" & oNIIN & " S/N Change from " & oSerial & " to " & newSN & " ", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))

            End If
        End If
        '
        swmsDb.Dispose()
        '
        If trouble Then
            Return False
        Else
            Return True
        End If

    End Function

    Private Sub srtVisual()
        'clear sort indicator
        btnEff.BackColor = Drawing.Color.Transparent
        btnTrn.BackColor = Drawing.Color.Transparent

        btnEff.ToolTip = "Click to sort"
        btnTrn.ToolTip = "Click to sort"
        '
    End Sub

    Protected Sub btnEff_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEff.Click
        fillDdls()
        fillLocations()
        srtVisual()
        btnEff.BackColor = Drawing.Color.PaleGreen
        btnEff.ToolTip = "Click to reverse sort"
        If hidSrtBy.Text = "Eff" Then
            displayAsset(Session("AId"))
            'Get_Data(", P2.UserName DESC")
            hidSrtBy.Text = "EffDown"
        Else
            displayAsset(Session("AId"))
            'Get_Data(", P2.UserName")
            hidSrtBy.Text = "Eff"
        End If
    End Sub

    Protected Sub btnTrn_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnTrn.Click
        fillDdls()
        fillLocations()
        srtVisual()
        btnTrn.BackColor = Drawing.Color.PaleGreen
        btnTrn.ToolTip = "Click to reverse sort"
        If hidSrtBy.Text = "Trn" Then
            displayAsset(Session("AId"))
            'Get_Data(", P2.UserName DESC")
            hidSrtBy.Text = "TrnDown"
        Else
            displayAsset(Session("AId"))
            'Get_Data(", P2.UserName")
            hidSrtBy.Text = "Trn"
        End If
    End Sub

End Class
