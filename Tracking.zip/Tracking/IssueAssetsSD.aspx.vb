﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Partial Class Tracking_IssueAssetsSD
    Inherits System.Web.UI.Page

    
    Dim sql As String = ""
    Dim cmd as SqlCommand = new SqlCommand()

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        SwmsAccess.ValidateSession()

        cmd.Parameters.Add("@peopleId", SqlDbType.int, 4).Value = Session("SWMSUId")


        lnkInv.Visible = False
        ThisTime.Text = Today.ToShortDateString

        If Not Page.IsPostBack Then ' NEW Page
            'add required maxlength attribute to the textarea
            txtRemarks.Attributes.Add("maxlength", 500)
            ' condition code --------------------------------------------
            ddlCC.Items.Clear()
            Dim ccSql As String = " Select '-' as SVD_Attribute UNION ALL "
            ccSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
            ccSql &= " WHERE (SVD_Name = 'condition_code') ORDER BY SVD_Attribute"
            SWmsUI.loadDropDown(ddlCC, ccSql, Nothing, False, "SVD_Attribute", "SVD_Attribute", "A")
            '
            ' reason -------------------------------------
            ddlReason.Items.Clear()
            Dim rSql As String = "SELECT '-' as SVD_Attribute UNION ALL "
            rSql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
            rSql &= " WHERE (SVD_Name = 'AssetReason') "
            rSql &= " AND ((SVD_Attribute LIKE 'ISS%') or (SVD_Attribute LIKE 'A/6%')) "
            rSql &= " ORDER BY SVD_Attribute"
            SWmsUI.loadDropDown(ddlReason, rSql, Nothing, False, "SVD_Attribute", "SVD_Attribute")
            '
            ' SubGroup & Acct Code  -------------------------------
            ddlSubGroup.Items.Clear()
            Dim sgSql As String = "SELECT '-' AS ProgramName, '' AS ProgramType "
            sgSql &= " UNION ALL "
            sgSql &= " SELECT ProgramName, ProgramType "
            sgSql &= " FROM Programs "
            sgSql &= " ORDER BY ProgramName"

            SWmsUI.loadDropDown(ddlSubGroup, sgSql, Nothing, False, "ProgramName", "ProgramName")

            '  location3 & location4 ----------------------
            '       cannot be known until txtPid.text has been filled
            ddlLocLvl2.Items.Clear()
            ddlLocLvl3.Items.Clear()
            ddlLocLvl4.Items.Clear()
            Dim tlix As New ListItem
            tlix.Text = "--"
            tlix.Value = "0"
            ddlLocLvl2.Items.Add(tlix)
            ddlLocLvl3.Items.Add(tlix)
            ddlLocLvl4.Items.Add(tlix)
            ddlLocLvl2.SelectedValue = "0"
            ddlLocLvl3.SelectedValue = "0"
            ddlLocLvl4.SelectedValue = "0"
            '
        Else
            If txtNomenclature.Text = "" Then
                txtNomenclature.Text = Request.Form("txtNomenclature")
            End If
            If txtModelNumber.Text = "" Then
                txtModelNumber.Text = Request.Form("txtModelNumber")
            End If
            If txtCAGE.Text = "" Then
                txtCAGE.Text = Request.Form("txtCAGE")
            End If
            '
            If Request.Form("ddlLocLvl3") <> Nothing Then
                ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(Request.Form("ddlLocLvl3")))
            End If
            If Request.Form("ddlLocLvl4") <> Nothing Then
                ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(Request.Form("ddlLocLvl4")))
            End If
            '
            If txtCommand.Text = "Issue" Then
                LastValidation()
                If UsrMsg.Value = "" Then
                    IssueWhat()
                End If
                txtCommand.Text = ""
                showstuff()
            End If
        End If

    End Sub

    Sub LastValidation()
        ' start off cleam
        txtIssuedTo.BackColor = Drawing.Color.White
        txtDocument.BackColor = Drawing.Color.White
        txtRemarks.BackColor = Drawing.Color.White
        ddlReason.BackColor = Drawing.Color.White
        txtDate.BackColor = Drawing.Color.White
        '
        Dim errMsg As String = ""

        'Issue To
        If txtIssuedTo.Text.Trim = "" Then
            errMsg &= "Issued To is required." & Chr(13)
            txtIssuedTo.BackColor = Drawing.Color.MistyRose
        End If
        'Shipping Doc
        If txtDocument.Text.Trim = "" Then
            errMsg &= "The Shipping Document number is required." & Chr(13)
            txtDocument.BackColor = Drawing.Color.MistyRose
        End If
        'Remarks ?
        If txtRemarks.Text.Trim = "" Then
            errMsg &= "Remarks are required." & Chr(13)
            txtRemarks.BackColor = Drawing.Color.MistyRose
        End If
        'Reason ?
        If ddlReason.SelectedIndex <= 0 Then
            errMsg &= "Please select a reason." & Chr(13)
            ddlReason.BackColor = Drawing.Color.MistyRose
        End If
        'possible date
        If txtDate.Text.Trim <> "" Then
            If Not IsDate(txtDate.Text) Then
                errMsg &= "Please use date format mm/dd/yyyy." & Chr(13)
                txtDate.BackColor = Drawing.Color.MistyRose
            End If
        End If
        'run through the list of serial numbers...

        '
        If errMsg <> "" Then
            UsrMsg.Value = errMsg
        End If
    End Sub

    Sub IssueWhat()
        Dim Selected As Boolean = False
        Dim h, i, j, k As Integer
        Dim s, ss As String
        Dim arr1(), arr2() As String        ', arr3()
        Dim coll As Collections.Specialized.NameValueCollection
        h = 0
        k = 0
        coll = Request.Form '// Load Form collection into NameValueCollection object.
        arr1 = coll.AllKeys   '// Put names of all keys into a string array.
        For i = 0 To arr1.Length - 1
            If arr1(i) = "checked" Then 'name of CheckBox Group
                arr2 = coll.GetValues(i)    '// Get all values under this key.
                For j = 0 To arr2.Length - 1
                    s = arr2(j)
                    ss = s.Substring(3)
                    If CheckSerial(ss) Then
                        buildTrans(ss)
                        h = h + 1
                    End If
                    k += 1
                Next
            End If
        Next
        'Did all the assets get issued?
        If h < k Then
            If h > 0 Then
                UsrMsg.Value &= h.ToString & " Assets Issued."
            End If
        Else
            UsrMsg.Value = k.ToString & " Assets Issued."
        End If

    End Sub

    Function CheckSerial(ByVal ThisId As String) As Boolean
        '
        Dim trouble As Boolean = False
        '
        Dim NewSerial As String
        NewSerial = Request.Form("tdxSer" & ThisId)
        '"tdxSer" & sqldt.Rows(i)("AssetId") 

        cmd.Parameters.Add("@ThisId", SqlDbType.Int, 4).Value = ThisId
        Dim sql As String = "SELECT Pid, NIIN, SerialNumber FROM Assets WHERE (AssetId = @ThisId)"
        cmd.CommandText = sql
        Dim sqldt as DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)
        '
        Dim oPid As Integer = 0
        Dim oNIIN As String = ""
        Dim oSerial As String = ""
        Dim NewAssetId As Integer = 0
        '
        If sqldt.Rows.Count > 0 Then
            oPid = sqldt.Rows(0)("Pid")
            oNIIN = sqldt.Rows(0)("NIIN")
            oSerial = sqldt.Rows(0)("SerialNumber")
        End If

        cmd.Parameters.Add("@NewSerial", SqlDbType.varchar, 50).Value = NewSerial        
        cmd.Parameters.Add("@oNIIN", SqlDbType.varchar, 11).Value = Iif(sqldt.Rows.Count>0, sqldt.Rows(0)("NIIN"), "")
        cmd.Parameters.Add("@oSerial", SqlDbType.varchar, 50).Value = Iif(sqldt.Rows.Count>0, sqldt.Rows(0)("SerialNumber"), "")

        If oSerial <> NewSerial Then
            Dim sql2 As String = "SELECT A.AssetId, A.LocationId, "
            sql2 &= " L2.LocationIdCode AS L2Code, L3.LocationIdCode AS L3Code, "
            sql2 &= " L4.LocationIdCode AS L4Code"
            sql2 &= " FROM Assets A"
            sql2 &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationId"
            sql2 &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationId"
            sql2 &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationId"
            sql2 &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationId"
            sql2 &= " WHERE (A.SerialNumber = @NewSerial) AND (A.NIIN = @oNIIN) AND (A.AssetId <> @ThisId)"

            cmd.CommandText = sql2
            Dim sqldt2 As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

            If sqldt2.Rows.Count > 0 Then
                If sqldt2.Rows(0)("LocationId") = 1 Then
                    'if Active Asset - This change is not allowed.  The asset with that serial number is Active.
                    UsrMsg.Value &= "Serial Number " & oSerial & " can not change to @NewSerial because the new number is Active." & Chr(13)
                    UsrMsg.Value &= "(" & sqldt2.Rows(0)("L2Code") & " - " & sqldt2.Rows(0)("L3Code") & " - " & sqldt2.Rows(0)("L4Code") & ")" & Chr(13)
                    trouble = True
                Else

                    cmd.Parameters.Add("@AssetId", SqlDbType.int, 4).Value = Iif(sqldt.Rows.Count>0, sqldt2.Rows(0)("AssetId"), "")
                    
                    'if Issued Asset - remap old assets history to this one and archive old asset
                    'update oldassetid to aid to current assetid
                    sql = "DECLARE @RightNow as datetime; "
                    sql &= "SELECT @RightNow = Getdate(); "
                    '
                    sql &= "UPDATE AssetHistory SET "
                    sql &= " AssetId = @AssetId,"
                    sql &= " OldAssetId = @AssetId "
                    sql &= " WHERE (AssetId =@AssetId); "

                    'then archive old asset
                    sql &= "INSERT INTO AssetArchive"
                    sql &= " (AssetId, PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber, "
                    sql &= " ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition, "
                    sql &= " LocationId, Location2, Location3, Location4, LastMoved, "
                    sql &= " Remarks, SubGroup, DocumentNumber, Reason, ReceivedFrom, "
                    sql &= " IssuedTo, EffectiveDate, LastTrans, LastTransDate, LastTransBy, "
                    sql &= " STOCKNO, DateRecorded, BSSId, VendorId, ModFromPid, PIN, "
                    sql &= " IntendedUse, AcceptanceDate, WarrantyBeginDate, WarrantyExpireDate, "
                    sql &= " A_Cond_Date, PackingStatus, ShipWeight, ShipLength, ShipWidth, ShipHeight, "
                    sql &= " NewId, ArchiveDate, ArchiveBy)"
                    sql &= " SELECT AssetId, PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber, "
                    sql &= " ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition, "
                    sql &= " LocationId, Location2, Location3, Location4, LastMoved, "
                    sql &= " Remarks, SubGroup, DocumentNumber, Reason, ReceivedFrom, "
                    sql &= " IssuedTo, EffectiveDate, LastTrans, LastTransDate, LastTransBy, "
                    sql &= " STOCKNO, DateRecorded, BSSId, VendorId, ModFromPid, PIN, "
                    sql &= " IntendedUse, AcceptanceDate, WarrantyBeginDate, WarrantyExpireDate, "
                    sql &= " A_Cond_Date, PackingStatus, ShipWeight, ShipLength, ShipWidth, ShipHeight, "
                    sql &= " @ThisId AS NewId, GETDATE() AS ArchiveDate, @peopleId AS ArchiveBy "
                    sql &= " FROM Assets WHERE (AssetId = @AssetId); "

                    'then remove old asset
                    sql &= "DELETE FROM Assets WHERE (AssetId = @AssetId); "

                    'update the serial number
                    sql &= "UPDATE Assets SET SerialNumber = @NewSerial, "
                    sql &= " EffectiveDate = @RightNow, "
                    sql &= " LastTrans = 'CHANGE SERIAL NUMBER W/HISTORY', "
                    sql &= " LastTransDate = @RightNow, "
                    sql &= " LastTransBy = @peopleId "
                    sql &= " WHERE (AssetId = @ThisId); "

                    'add to history
                    sql &= " INSERT INTO AssetHistory ("
                    sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
                    sql &= " LocationId, Location2, Location3, Location4,"
                    sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
                    sql &= " Status,"
                    sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
                    '
                    sql &= " SELECT AssetId, "
                    sql &= " CurrentCondition AS ConditionCode, "
                    sql &= " 'CHANGE SERIAL NUMBER W/HISTORY' AS TransType, "
                    sql &= " @RightNow AS TransDate, "
                    sql &= " @peopleId AS TransBy, "
                    sql &= " 'SERIAL NUMBER CHANGE FROM @oSerial TO @NewSerial ASSETID @AssetId ARCHIVED' AS Remarks, "
                    sql &= " @Reason AS Reason, "
                    sql &= " @DocumentNumber AS DocumentNumber, "
                    sql &= " Assets.LocationId, "
                    sql &= " Assets.Location2, "
                    sql &= " Assets.Location3, "
                    sql &= " Assets.Location4, "
                    sql &= " L1.LocationIdCode AS Location1Text, "
                    sql &= " L2.LocationIdCode AS Location2Text, "
                    sql &= " L3.LocationIdCode AS Location3Text, "
                    sql &= " L4.LocationIdCode AS Location4Text,"
                    sql &= " L1.LocationIdCode AS Status, "
                    If IsDate(txtDate.Text) Then
                        sql &= "@EffectiveDate AS EffectiveDate, "
                    Else
                        sql &= " @RightNow AS EffectiveDate, "
                    End If
                    sql &= " ICNnum, "
                    sql &= " ICNSeq, "
                    sql &= " SubGroup, "
                    sql &= " ReceivedFrom, "
                    sql &= " @IssuedTo AS IssuedTo, "
                    sql &= " PIN"
                    sql &= " FROM Assets"
                    sql &= " LEFT OUTER JOIN Locations L1 ON Assets.LocationId = L1.LocationId"
                    sql &= " LEFT OUTER JOIN Locations L2 ON Assets.Location2 = L2.LocationId"
                    sql &= " LEFT OUTER JOIN Locations L3 ON Assets.Location3 = L3.LocationId"
                    sql &= " LEFT OUTER JOIN Locations L4 ON Assets.Location4 = L4.LocationId"
                    sql &= " WHERE (AssetId = @ThisId); "

                    cmd.CommandText = sql
                    SwmsAccess.ExecuteNonQuery(cmd)


                    SwmsLogger.LogEvent("assets", "Assets: niin:" & txtNIIN.Text & " S/N:" & NewSerial & " Archived, AssetId:" & sqldt2.Rows(0)("AssetId") & " ")
                    SwmsLogger.LogEvent("assets", "Assets: niin:" & txtNIIN.Text & " S/N Change from " & oSerial & " to " & NewSerial & " ")

                End If
            Else
                'if no rows returned then this is the first time this Asset has been Issued.
                'change the Serial Number, record history and continue on.
                sql = "DECLARE @RightNow as datetime; "
                sql &= "SELECT @RightNow = Getdate(); "
                '
                sql &= " UPDATE Assets SET SerialNumber = @NewSerial, "
                sql &= " EffectiveDate = @RightNow, "
                sql &= " LastTrans = 'CHANGE SERIAL NUMBER', "
                sql &= " LastTransDate = @RightNow, "
                sql &= " LastTransBy = @peopleId "
                sql &= " WHERE (AssetId = @ThisId); "

                ' insert History
                sql &= " INSERT INTO AssetHistory ("
                sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
                sql &= " LocationId, Location2, Location3, Location4,"
                sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
                sql &= " Status,"
                sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
                '
                sql &= " SELECT AssetId, "
                sql &= " CurrentCondition AS ConditionCode, "
                sql &= " 'CHANGE SERIAL NUMBER' AS TransType, "
                sql &= " @RightNow AS TransDate, "
                sql &= " @peopleId AS TransBy, "
                sql &= " 'SERIAL NUMBER CHANGE FROM @oSerial TO @NewSerial AS Remarks, "
                sql &= " @Reason AS Reason, "
                sql &= " @DocumentNumber AS DocumentNumber, "
                sql &= " Assets.LocationId, "
                sql &= " Assets.Location2, "
                sql &= " Assets.Location3, "
                sql &= " Assets.Location4, "
                sql &= " L1.LocationIdCode AS Location1Text, "
                sql &= " L2.LocationIdCode AS Location2Text, "
                sql &= " L3.LocationIdCode AS Location3Text, "
                sql &= " L4.LocationIdCode AS Location4Text,"
                sql &= " L1.LocationIdCode AS Status, "
                If IsDate(txtDate.Text) Then
                    sql &= " @EffectiveDate AS EffectiveDate, "
                Else
                    sql &= " @RightNow AS EffectiveDate, "
                End If
                sql &= " ICNnum, "
                sql &= " ICNSeq, "
                sql &= " SubGroup, "
                sql &= " ReceivedFrom, "
                sql &= " @IssuedTo AS IssuedTo, "
                sql &= " PIN"
                sql &= " FROM Assets"
                sql &= " LEFT OUTER JOIN Locations L1 ON Assets.LocationId = L1.LocationId"
                sql &= " LEFT OUTER JOIN Locations L2 ON Assets.Location2 = L2.LocationId"
                sql &= " LEFT OUTER JOIN Locations L3 ON Assets.Location3 = L3.LocationId"
                sql &= " LEFT OUTER JOIN Locations L4 ON Assets.Location4 = L4.LocationId"
                sql &= " WHERE (AssetId = @ThisId); "
                

                cmd.CommandText = sql
                SwmsAccess.ExecuteNonQuery(cmd)
                SwmsLogger.LogEvent("assets", "Assets: niin:" & txtNIIN.Text & " S/N Change from " & oSerial & " to " & NewSerial & " ")

            End If
        End If
        '
        If trouble Then
            Return False
        Else
            Return True
        End If

    
    
    
    End Function

    Sub buildTrans(ByVal ThisId As String)


           ' get serial number for log
        Dim sSql As String = "SELECT SerialNumber FROM Assets WHERE  (AssetId = @AssetId); "
        cmd.CommandText = sSql
        cmd.Parameters.Add("@AssetId", SqlDbType.Int, 4).Value = ThisId

        Dim sqldt As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

        ' update Asset
        sql = "DECLARE @RightNow as datetime; "
        sql &= "SELECT @RightNow = Getdate(); "

        sql &= " UPDATE Assets SET "
        sql &= " LocationId = 2, "  'ISSUED
        sql &= " Location2 = NULL, "
        sql &= " Location3 = NULL, "
        sql &= " Location4 = NULL,"
        sql &= " DocumentNumber = @DocumentNumber, "  ' /* ? */ "
        sql &= " Reason = @Reason, "
        sql &= " IssuedTo = @IssuedTo, "
        If IsDate(txtDate.Text) Then
            sql &= " EffectiveDate = @TransDate, "
            sql &= " LastMoved = @TransDate, "
        Else
            sql &= " EffectiveDate = @RightNow, "
            sql &= " LastMoved = @RightNow, "
        End If
        sql &= " LastTrans = 'ISSUED', "
        sql &= " LastTransDate = @RightNow, "
        sql &= " LastTransBy = @peopleId "
        sql &= " WHERE (AssetId = @AssetId); "


        ' insert History
        sql &= " INSERT INTO AssetHistory ("
        sql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, DocumentNumber,"
        sql &= " LocationId, Location2, Location3, Location4,"
        sql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
        sql &= " Status,"
        sql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
        '
        sql &= " SELECT AssetId, "
        sql &= " CurrentCondition AS ConditionCode, "
        sql &= " 'Issue Asset' AS TransType, "
        sql &= " @RightNow AS TransDate, "
        sql &= " @PeopleId AS TransBy, "
        sql &= " '" & Left("@Remarks", 500) & "' AS Remarks, "      'History Remarks
        sql &= " @Reason AS Reason, "
        sql &= " @DocumentNumber AS DocumentNumber, "
        sql &= " 2 AS LocationId, "
        sql &= " NULL AS Location2, "
        sql &= " NULL AS Location3, "
        sql &= " NULL AS Location4, "
        sql &= " 'ISSUED' AS Location1Text, "
        sql &= " NULL AS Location2Text, "
        sql &= " NULL AS Location3Text, "
        sql &= " NULL AS Location4Text, "
        sql &= " 'ISSUED' AS Status, "
        If IsDate(txtDate.Text) Then
            sql &= " @TransDate AS EffectiveDate, "
        Else
            sql &= " @RightNow AS EffectiveDate, "
        End If
        sql &= " ICNnum, "
        sql &= " ICNSeq, "
        sql &= " SubGroup, "
        sql &= " ReceivedFrom, "
        sql &= " @IssuedTo AS IssuedTo, "
        sql &= " PIN"
        sql &= " FROM Assets"
        sql &= " WHERE (AssetId = @ThisIdbuildTrans); "

        ' delete InventoryLocation
        sql &= "DELETE InventoryLocation WHERE (AssetId = @ThisIdbuildTrans); "

        ' execute & logit
        cmd.CommandText = sql
        
        cmd.Parameters.Add("@IssuedTo", SqlDbType.varchar, 50).Value = Server.HtmlEncode(txtIssuedTo.Text)
        cmd.Parameters.Add("@TransDate", SqlDbType.datetime, 8).Value = Iif(IsDate(txtDate.Text), txtDate.Text, DBNull.Value)
        cmd.Parameters.Add("@Reason", SqlDbType.varchar, 50).Value = ddlReason.SelectedItem.Text
        cmd.Parameters.Add("@Remarks", SqlDbType.varchar, 500).Value = Server.HtmlEncode(txtRemarks.Text)
        cmd.Parameters.Add("@DocumentNumber", SqlDbType.varchar, 50).Value = Server.HtmlEncode(txtDocument.Text)
        cmd.Parameters.Add("@ThisIdbuildTrans", SqlDbType.varchar, 50).Value = ThisId

        SwmsAccess.ExecuteNonQuery(cmd)

        SwmsLogger.LogEvent("assets", "Assets: niin:" & txtNIIN.Text & " part: " & txtPartNumber.Text & " S/N:" & sqldt.Rows(0)("SerialNumber") & " Issued ")

    End Sub

    Protected Sub btnSho_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSho.Click
        showstuff()
    End Sub

    Sub showstuff()
        '
        If txtPid.Text = "" Then
            If txtNIIN.Text.Trim <> "" Or txtPartNumber.Text.Trim <> "" Then
                GoGetIt()
            Else
                UsrMsg.Value = "Please use NIIN and/or Part Number to find Assets."
            End If
        End If

        If txtPid.Text = "" Then
            'still no match
            lblRowCount.Text = "No Assets found"
        Else
            'list available Assets
            sql = "SELECT A1.PID, A1.AssetId, A1.SerialNumber, "
            sql &= " ISNULL(A1.ICNnum, '') AS ICNnum, ISNULL(A1.ICNseq, '') AS ICNseq, ISNULL(A1.CurrentCondition, '') AS CurrentCondition, "
            sql &= " ISNULL(A1.Remarks, '') AS Remarks, ISNULL(A1.SubGroup, '') AS SubGroup, ISNULL(A1.DocumentNumber, '') AS DocumentNumber, "
            sql &= " ISNULL(A1.Reason, '') AS Reason, ISNULL(A1.ReceivedFrom, '') AS ReceivedFrom, ISNULL(A1.PIN, '') AS PIN, "
            sql &= " ISNULL(L1.LocationIdCode, 'ISSUED') AS CurrentStatus, A1.AcceptanceDate,"
            sql &= " ISNULL(L2.LocationIdCode, '') + '/' + ISNULL(L3.LocationIdCode, '')"
            sql &= "  	+ '/' + ISNULL(L4.LocationIdCode, '') AS CurrentLocation "
            sql &= " FROM Assets A1"
            sql &= " LEFT OUTER JOIN Locations L1 ON L1.LocationId = A1.LocationId"
            sql &= " LEFT OUTER JOIN Locations L2 ON L2.LocationId = A1.Location2"
            sql &= " LEFT OUTER JOIN Locations L3 ON L3.LocationId = A1.Location3"
            sql &= " LEFT OUTER JOIN Locations L4 ON L4.LocationId = A1.Location4"
            sql &= " WHERE (A1.LocationId = 1) AND (PID = @Pid)"
            If ddlCC.SelectedValue <> "-" Then
                sql &= " AND (A1.CurrentCondition = @CurrentCondition) "
            End If
            If txtSerial.Text <> "" Then
                sql &= " AND (A1.SerialNumber = @SerialNumber) "
            End If
            If txtICN.Text <> "" Then
                sql &= " AND (A1.ICNnum = @ICNnum) "
            End If
            If ddlSubGroup.SelectedItem.Text <> "-" Then
                sql &= " AND (A1.SubGroup = @SubGroup) "
            End If
            If Request.Form("ddlLocLvl2") <> "0" And Request.Form("ddlLocLvl2") <> Nothing Then
                sql &= " AND (A1.Location2 = @Location2) "
            End If
            If Request.Form("ddlLocLvl3") <> "0" And Request.Form("ddlLocLvl3") <> Nothing Then
                sql &= " AND (A1.Location3 = @Location3) "
            End If
            If Request.Form("ddlLocLvl4") <> "0" And Request.Form("ddlLocLvl4") <> Nothing Then
                sql &= " AND (A1.Location4 = @Location4) "
            End If
            sql &= " ORDER BY A1.Pid, A1.CurrentCondition, A1.AcceptanceDate, A1.SerialNumber"

            'Response.Write("ddlLocLvl3. request form = " & Request.Form("ddlLocLvl3") & "<br>" & sql)
            'Response.Flush()

            cmd.CommandText = sql
            ' cmd.Parameters.Add("@pid", SqlDbType.Int, 4).Value = Iif( txtPid.text <> "", txtPid.text, "")
            ' cmd.Parameters.Add("@CurrentCondition", SqlDbType.varchar, 1).Value = Iif( ddlCC.SelectedValue <> "", ddlCC.SelectedValue, "")
            ' cmd.Parameters.Add("@SerialNumber", SqlDbType.varchar, 50).Value = Iif( txtSerial.text <> "", txtSerial.text, "") 
            ' cmd.Parameters.Add("@ICNnum", SqlDbType.varchar, 8).Value = Iif( txtICN.text <> "", txtICN.text, "")
            ' cmd.Parameters.Add("@SubGroup", SqlDbType.varchar, 20).Value = Iif( ddlSubGroup.SelectedItem.Text <> "", ddlSubGroup.SelectedItem.Text, "") 
            cmd.Parameters.Add("@pid", SqlDbType.Int, 4).Value = txtPid.text
            cmd.Parameters.Add("@CurrentCondition", SqlDbType.varchar, 1).Value = ddlCC.SelectedValue
            cmd.Parameters.Add("@SerialNumber", SqlDbType.varchar, 50).Value = txtSerial.text
            cmd.Parameters.Add("@ICNnum", SqlDbType.varchar, 8).Value = txtICN.text
            cmd.Parameters.Add("@SubGroup", SqlDbType.varchar, 20).Value = ddlSubGroup.SelectedItem.Text
            cmd.Parameters.Add("@Location2", SqlDbType.int, 4).Value = Iif(Request.Form("ddlLocLvl2") <> "",Request.Form("ddlLocLvl2") , DBNull.Value)
            cmd.Parameters.Add("@Location3", SqlDbType.int, 4).Value = Iif(Request.Form("ddlLocLvl3") <> "",Request.Form("ddlLocLvl3") , DBNull.Value)
            cmd.Parameters.Add("@Location4", SqlDbType.int, 4).Value = Iif(Request.Form("ddlLocLvl4") <> "",Request.Form("ddlLocLvl4") , DBNull.Value)

            Dim sqldt As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

            AssetsTab.Controls.Clear()
            ' column headers
            Dim hdr As New TableRow

            Dim hxc0 As New TableCell
            hxc0.Text = "Select"
            hxc0.ToolTip = "Select for ISSUE"
            hdr.Cells.Add(hxc0)
            ' 
            Dim hxc1 As New TableCell
            hxc1.Text = "Serial Number"
            hdr.Cells.Add(hxc1)
            ' 
            Dim hxc2 As New TableCell
            hxc2.Text = "ICN"
            hdr.Cells.Add(hxc2)
            ' 
            Dim hxc3 As New TableCell
            hxc3.Text = "CC"
            hxc3.ToolTip = "Current Condition"
            hdr.Cells.Add(hxc3)
            ' 
            Dim hxc4 As New TableCell
            hxc4.Text = "SubGroup"
            hdr.Cells.Add(hxc4)
            ' 
            Dim hxc5 As New TableCell
            hxc5.Text = "Acct"
            hdr.Cells.Add(hxc5)
            ' 
            Dim hxc6 As New TableCell
            hxc6.Text = "Location"
            hdr.Cells.Add(hxc6)
            '
            hdr.BackColor = Drawing.Color.FromArgb(153, 204, 255)   ' #99CCFF
            'alternating background
            '
            AssetsTab.Rows.Add(hdr)
            '
            If sqldt.Rows.Count = 0 Then
                lblRowCount.Text = "No records found"
                '
                Dim noRows As New TableRow
                Dim no0 As New TableCell
                no0.Text = "No Assets available for Issue."
                no0.ForeColor = Drawing.Color.Red
                no0.ColumnSpan = 7
                no0.HorizontalAlign = HorizontalAlign.Center
                noRows.Cells.Add(no0)
                AssetsTab.Rows.Add(noRows)

            Else
                '
                lblRowCount.Text = sqldt.Rows.Count & " Assets found"
                lblCheckedCount.Text = "0 Assets selected"

                Dim altRow As Boolean = False
                Dim i As Integer = 0
                Do While i <= sqldt.Rows.Count - 1
                    Dim trx As New TableRow

                    Dim tx0 As New TableCell
                    tx0.Text = "<input type='checkbox' name='checked' value='cbx" & sqldt.Rows(i)("AssetId") & "' title='" & sqldt.Rows(i)("AssetId") & "'"
                    If sqldt.Rows.Count > 1 Then
                        tx0.Text &= " onclick='javascript:howManyChecked(form1.checked);' "
                    End If
                    tx0.Text &= "/>"
                    tx0.Style.Add("cursor", "hand")
                    trx.Cells.Add(tx0)
                    ' 
                    Dim tx1 As New TableCell
                    tx1.ToolTip = sqldt.Rows(i)("SerialNumber")
                    Dim tdxSer As New TextBox
                    tdxSer.ID = "tdxSer" & sqldt.Rows(i)("AssetId")     ' CStr(i)
                    If sqldt.Rows(i)("SubGroup") = "CICPOVHL" Then
                        tdxSer.Attributes.Add("onblur", "javascript:chkSn('tdxSer" & sqldt.Rows(i)("AssetId") & "', this.value, 'sp" & sqldt.Rows(i)("AssetId") & "');")
                    Else
                        tdxSer.ReadOnly = True
                        tdxSer.BackColor = Drawing.Color.LightBlue
                        tdxSer.ToolTip = "Serial Number may not be altered at ISSUE.  Use Asset Transfer."
                    End If
                    tdxSer.CssClass = "SmContent"
                    tdxSer.Width = Unit.Pixel(120)
                    tdxSer.Text = sqldt.Rows(i)("SerialNumber")
                    tdxSer.MaxLength = 50
                    tx1.Controls.Add(tdxSer)
                    Dim spn As New Label
                    spn.ID = "sp" & sqldt.Rows(i)("AssetId")
                    spn.Attributes.Add("Style", "FONT-WEIGHT:bold; FONT-SIZE:8pt; COLOR:red; FONT-FAMILY:Verdana")
                    tx1.Controls.Add(spn)
                    trx.Cells.Add(tx1)
                    ' 
                    Dim tx2 As New TableCell
                    tx2.Text = sqldt.Rows(i)("ICNnum")
                    If sqldt.Rows(i)("ICNnum").ToString <> "" Then
                        tx2.Text &= "-" & Right("000" & sqldt.Rows(i)("ICNseq").ToString, 4)
                    End If
                    trx.Cells.Add(tx2)
                    ' 
                    Dim tx3 As New TableCell
                    tx3.Text = sqldt.Rows(i)("CurrentCondition")
                    trx.Cells.Add(tx3)
                    ' 
                    Dim tx4 As New TableCell
                    tx4.Text = sqldt.Rows(i)("SubGroup")
                    trx.Cells.Add(tx4)
                    ' 
                    Dim tx5 As New TableCell
                    tx5.Text = sqldt.Rows(i)("PIN")
                    trx.Cells.Add(tx5)
                    ' 
                    Dim tx6 As New TableCell
                    tx6.Text = sqldt.Rows(i)("CurrentLocation")
                    trx.Cells.Add(tx6)
                    '
                    'alternating background
                    If altRow = True Then
                        trx.BackColor = System.Drawing.Color.WhiteSmoke
                        altRow = False
                    Else
                        altRow = True
                    End If '
                    AssetsTab.Rows.Add(trx)
                    '
                    i += 1
                Loop

                Dim db2 As New TableRow
                Dim bspn As New TableCell
                bspn.ColumnSpan = 3
                If sqldt.Rows.Count > 1 Then
                    Dim btnCka As New HtmlButton
                    btnCka.InnerText = "Check All"
                    btnCka.Attributes.Add("class", "smContent")
                    btnCka.Attributes.Add("onClick", "checkAll(form1.checked)")
                    btnCka.ID = "btnCheckAll" '& FormatDateTime(savStartDate, DateFormat.ShortDate)
                    bspn.Controls.Add(btnCka)
                    Dim btnUnCka As New HtmlButton
                    btnUnCka.InnerText = "UnCheck All"
                    btnUnCka.Attributes.Add("class", "smContent")
                    btnUnCka.Attributes.Add("onClick", "uncheckAll(form1.checked)")
                    btnUnCka.ID = "btnUnCheckAll" '& FormatDateTime(savStartDate, DateFormat.ShortDate)
                    bspn.Controls.Add(btnUnCka)
                Else
                    bspn.Text = "&nbsp;"
                End If
                db2.Cells.Add(bspn)

                Dim fspn As New TableCell
                fspn.ColumnSpan = 4
                Dim btnSubmit As New HtmlButton
                btnSubmit.InnerText = "Submit List"
                btnSubmit.Attributes.Add("class", "smContent")
                btnSubmit.Attributes.Add("onclick", "javascript:form1.txtCommand.value='Issue'; this.disabled = true; form1.submit();")
                fspn.Controls.Add(btnSubmit)
                'fspn.Text = "&nbsp;"
                db2.Cells.Add(fspn)
                db2.BorderColor = Drawing.Color.SteelBlue

                AssetsTab.Rows.Add(db2)

                AssetsTab.Visible = True
            End If
            '
            'list available Asset Locations based on the Asset searched for...
            GetLimitedLocations(txtPid.Text)

        End If

    End Sub

    Sub GoGetIt()
        'find the filter information to search for Assets to Issue
        sql = "SELECT Pid, NIIN, PartNumber, ISNULL(COG, '') AS COG, "
        sql &= " ISNULL(ModelNumber, '') AS ModelNumber, ISNULL(Nomenclature, '') AS Nomenclature, "
        sql &= " ISNULL(ProcurementCode, '') AS ProcurementCode, ISNULL(CAGE, '') AS CAGE "
        sql &= " FROM PartsMaster "
        sql &= " WHERE (Pid IS NOT NULL) "
        If txtNIIN.Text.Trim <> "" Then
            sql &= " AND (NIIN LIKE @niin) "
        End If
        If txtPartNumber.Text.Trim <> "" Then
            sql &= " AND (PartNumber LIKE @PartNumber) "
        End If

        cmd.CommandText = sql
        cmd.Parameters.Add("@NIIN", SqlDbType.varchar, 11).Value = txtNIIN.text.Trim
        cmd.Parameters.Add("@PartNumber", SqlDbType.varchar, 50).Value = txtPartNumber.text.Trim
        Dim sqldt As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)
        '
        If sqldt.Rows.Count = 1 Then
            SelTab.Visible = False
            AssetsTab.Visible = True
            txtPid.Text = sqldt.Rows(0)("Pid")
            txtNIIN.Text = sqldt.Rows(0)("NIIN")
            txtPartNumber.Text = sqldt.Rows(0)("PartNumber")
            txtNomenclature.Text = sqldt.Rows(0)("Nomenclature")
            txtModelNumber.Text = sqldt.Rows(0)("ModelNumber")
            txtCAGE.Text = sqldt.Rows(0)("CAGE")
            txtCOG.Text = sqldt.Rows(0)("COG")
            '
        End If
        '
        If sqldt.Rows.Count > 1 Then
            ' show selection div to indicate which part is to be used
            Dim hr1 As New TableRow
            hr1.BackColor = Drawing.Color.FromArgb(153, 204, 255)
            '
            Dim hd1 As New TableCell
            hd1.ColumnSpan = 6
            hd1.CssClass = "smBContent"
            hd1.HorizontalAlign = HorizontalAlign.Center
            hd1.Text = "Verify Assets For Issue"
            hr1.Cells.Add(hd1)
            '
            SelTab.Rows.Add(hr1)
            '
            Dim hr2 As New TableRow
            hr2.BackColor = Drawing.Color.FromArgb(153, 204, 255)

            Dim td0 As New TableCell
            td0.Text = "COG"
            td0.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td0)

            Dim td1 As New TableCell
            td1.Text = "NIIN"
            td1.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td1)
            '
            Dim td2 As New TableCell
            td2.Text = "Part Number"
            td2.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td2)
            '
            Dim td3 As New TableCell
            td3.Text = "Model Number"
            td3.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td3)
            '
            Dim td4 As New TableCell
            td4.Text = "Nomenclature"
            td4.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td4)
            '
            Dim td5 As New TableCell
            td5.Text = "Manufacturer"
            td5.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td5)
            '
            Dim td6 As New TableCell
            td6.Text = "Proc. Code"
            td6.HorizontalAlign = HorizontalAlign.Center
            hr2.Cells.Add(td6)
            '
            SelTab.Rows.Add(hr2)
            '
            Dim i As Integer = 0
            Do While i <= sqldt.Rows.Count - 1

                Dim trx As New TableRow
                Dim tx0 As New TableCell
                tx0.Text = sqldt.Rows(i)("COG")
                tx0.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx0.Style.Add("cursor", "hand")
                trx.Cells.Add(tx0)
                '
                Dim tx1 As New TableCell
                tx1.Text = sqldt.Rows(i)("NIIN").ToString()
                tx1.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx1.Style.Add("cursor", "hand")
                trx.Cells.Add(tx1)
                '
                Dim tx2 As New TableCell
                tx2.Text = sqldt.Rows(i)("PartNumber")
                tx2.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx2.Style.Add("cursor", "hand")
                trx.Cells.Add(tx2)
                '
                Dim tx3 As New TableCell
                tx3.Text = sqldt.Rows(i)("ModelNumber")
                tx3.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx3.Style.Add("cursor", "hand")
                trx.Cells.Add(tx3)
                '
                Dim tx4 As New TableCell
                tx4.Text = sqldt.Rows(i)("Nomenclature")
                tx4.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx4.Style.Add("cursor", "hand")
                trx.Cells.Add(tx4)
                '
                Dim tx5 As New TableCell
                tx5.Text = sqldt.Rows(i)("CAGE")
                tx5.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx5.Style.Add("cursor", "hand")
                trx.Cells.Add(tx5)
                '
                Dim tx6 As New TableCell
                tx6.Text = sqldt.Rows(i)("ProcurementCode")
                tx6.Attributes.Add("onClick", "picMe(" & sqldt.Rows(i)("Pid") & ");")
                tx6.Style.Add("cursor", "hand")
                trx.Cells.Add(tx6)
                '
                If txtPid.Text <> "" Then
                    If sqldt.Rows(i)("Pid") = txtPid.Text Then
                        trx.BackColor = System.Drawing.Color.PaleGreen
                    End If
                End If
                '
                SelTab.Rows.Add(trx)
                i += 1
            Loop
            SelTab.Visible = True
            'AssetsTab.Visible = False

        End If

    End Sub

    Sub GetLimitedLocations(ByVal pid As String)
        '
        locationFilter.Visible = True

        '' location2 ----------------------------------
        Dim l2Sql As String = "SELECT 0 AS LocationId, '--' AS LocationIdCode UNION "
        l2Sql &= " SELECT LocationId, LocationIdCode FROM Locations WHERE ParentLocationId = 1"
        SWmsUI.loadDropDown(ddlLocLvl2, l2Sql, Nothing, False, "LocationIdCode", "LocationId")
        '
        If Request.Form("ddlLocLvl2") <> "0" Then
            ddlLocLvl2.SelectedIndex = ddlLocLvl2.Items.IndexOf(ddlLocLvl2.Items.FindByValue(Request.Form("ddlLocLvl2")))
        Else
            ddlLocLvl2.SelectedValue = "0"
        End If

        ' Building
        ddlLocLvl3.Items.Clear()
        Dim sql3 As String = "SELECT ParentLocationID, CAST(LocationId as varchar) + '@' + LocationIdCode AS Code FROM Locations "
        sql3 &= " WHERE (LocationLevel = 3)"
        sql3 &= " ORDER BY LocationIdCode"

        cmd.CommandText = sql3
        Dim rtn3 As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)
        SWmsUI.loadDropDown(ddlSavLvl3, sql3, Nothing, False, "Code", "ParentLocationID")
        '
        Dim j As Integer = 0
        ddlLocLvl3.Items.Clear()
        Dim tli3 As New ListItem
        tli3.Text = "--"
        tli3.Value = "0"
        ddlLocLvl3.Items.Add(tli3)
        ' Populate the control after the data record has been read
        For i As Integer = 0 To rtn3.Rows.Count - 1
            If rtn3.Rows(i)("ParentLocationID") = ddlLocLvl2.SelectedValue Then
                j = InStr(rtn3.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn3.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn3.Rows(i)("Code"), j + 1)
                ddlLocLvl3.Items.Add(litm)
            End If
        Next
        If Request.Form("ddlLocLvl3") <> "0" Then
            ddlLocLvl3.SelectedIndex = ddlLocLvl3.Items.IndexOf(ddlLocLvl3.Items.FindByValue(Request.Form("ddlLocLvl3")))
        Else
            ddlLocLvl3.SelectedValue = "0"
        End If
        '
        ' Bin
        ddlSavLvl4.Items.Clear()
        '
        Dim sql4 As String = "SELECT L.ParentLocationID, CAST(L.LocationId as varchar) + '@' + L.LocationIdCode AS Code "
        sql4 &= " FROM Assets A "
        sql4 &= " INNER JOIN Locations L ON A.Location4 = L.LocationId"
        sql4 &= " WHERE (A.Pid = @PidByVal)"
        If ddlCC.SelectedValue <> "-" Then
            sql4 &= " AND (A.CurrentCondition = @ddlCC) "
        End If
        sql4 &= " AND (L.LocationLevel = 4)"
        sql4 &= " GROUP BY L.ParentLocationID, L.LocationId, L.LocationIdCode"
        sql4 &= " ORDER BY L.LocationIdCode"

        cmd.CommandText = sql4        
        cmd.Parameters.Add("@PidByVal", SqlDbType.Int, 4).Value = Pid
        cmd.Parameters.Add("@ddlCC", SqlDbType.varchar, 1).Value = ddlCC.SelectedValue

        Dim rtn4 As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)
        SWmsUI.loadDropDown(ddlSavLvl4, sql4, Nothing, False, "Code", "ParentLocationID")
        '

        ddlLocLvl4.Items.Clear()
        Dim tli4 As New ListItem
        tli4.Text = "--"
        tli4.Value = "0"
        ddlLocLvl4.Items.Add(tli4)
        ' Populate the control after the data record has been read
        For i As Integer = 0 To rtn4.Rows.Count - 1
            If rtn4.Rows(i)("ParentLocationID") = ddlLocLvl3.SelectedValue Then
                j = InStr(rtn4.Rows(i)("Code"), "@")
                Dim litm As New ListItem
                litm.Value = Left(rtn4.Rows(i)("Code"), j - 1)
                litm.Text = Mid(rtn4.Rows(i)("Code"), j + 1)
                ddlLocLvl4.Items.Add(litm)
            End If
        Next


        If Request.Form("ddlLocLvl4") <> "0" Then
            ddlLocLvl4.SelectedIndex = ddlLocLvl4.Items.IndexOf(ddlLocLvl4.Items.FindByValue(Request.Form("ddlLocLvl4")))
        Else
            ddlLocLvl4.SelectedValue = "0"
        End If
        '
        ' 
    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Response.Redirect("./IssueAssetsSD.aspx")
    End Sub

End Class
