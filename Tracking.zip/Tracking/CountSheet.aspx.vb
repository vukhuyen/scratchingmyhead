﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.UI.WebControls.Expressions
Imports System.IO
Imports System.Reflection

Partial Class Tracking_CountSheet
    Inherits System.Web.UI.Page    

#Region " Declarations "
    
    Dim sql As String = ""
    Dim str As String
#End Region

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' --- per sandra remove the search feature ---
        '<asp:panel ID="addNewPanel" runat="server">
        '    NIIN:<asp:TextBox ID="txtNiin" width="100px" runat="server" MaxLength="11" CssClass="SmContent"/>
        '        <asp:RequiredFieldValidator ID="reqNiin" runat="server" ControlToValidate="txtNiin" Text="*" />
        '    Serial :<asp:TextBox ID="txtSn" width="100px" runat="server" MaxLength="50" CssClass="SmContent"/>
        '        <asp:RequiredFieldValidator ID="reqSn" runat="server" ControlToValidate="txtSn" Text="*" />
        '    <asp:Button ID="btnSearch" runat="server" OnClick="btnSearch_Click" Text="Move Asset"  CssClass="SmContent" />
        '    <asp:Label ID="lblmsg" runat="server"  CssClass="TinyContent"></asp:Label>
        '</asp:panel>

        Select Case Session("viewMethod")
            Case "View"
                viewCountSheet()
                btnFinal.Visible = False
            Case "Enter"
                editCountSheet()
                btnPrint.Visible = False
        End Select
        getTitle()
    End Sub

    Protected Sub getTitle()
        
        Dim cmd As New SqlCommand("AssetVerCountSheetTitle", SWmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@AVLid", Session("alvId"))

        Dim dsdt As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd, true)

        If (dsdt.Rows.Count > 0) Then
            pageTitle.Text = dsdt.Rows(0)("inventoryName") & ": " & dsdt.Rows(0)("loc")
            lblInvName.Text = dsdt.Rows(0)("inventoryName")
            lblLocation.Text = dsdt.Rows(0)("loc")
            lblDate.Text = FormatDateTime(dsdt.Rows(0)("thedate"), 2)

            If IsDBNull(dsdt.Rows(0)("completedate")) Then
                ' lblDate.Text = Date.Today
                If CStr(Session("viewMethod")) = "View" Then
                    extraRows()
                End If
            Else
                btnPrint.Visible = False
                ' lblDate.Text = FormatDateTime(ds.Tables(0).Rows(0)("completedate"), 2)
            End If

        End If
    End Sub

#Region "EditCountSheet"
    Sub editCountSheet()
        gv.DataSource = LinqDataSource1
        gv.PageIndex = 0
        gv.DataBind()

        If gv.Rows.Count.ToString = 1 Then
            Me.lblRowCount.Text = "1 Record"
        Else
            Me.lblRowCount.Text = gv.Rows.Count.ToString & " Records"
        End If
    End Sub

    Protected Sub LinqDataSource1_ContextCreating(sender As Object, e As LinqDataSourceContextEventArgs) Handles LinqDataSource1.ContextCreating
        e.ObjectInstance = New AssetVerifyDataContext(SwmsAccess.GetSwmsConnection())
    End Sub

    Protected Sub filterByLocation(ByVal sender As Object, ByVal e As CustomExpressionEventArgs)

        Dim alvid = Session("alvId").ToString



        If Me.chkSubGroup.Checked Then


            e.Query = (From entireRow In e.Query.Cast(Of AssetVerCountSheetView)()) _
            .Where(Function(x) x.AVLId = alvid) _
            .OrderBy(Function(x) x.SubGroup).AsQueryable

        Else


            e.Query = (From entireRow In e.Query.Cast(Of AssetVerCountSheetView)()) _
                .Where(Function(x) x.AVLId = alvid) _
                .OrderByDescending(Function(x) x.SubGroup).AsQueryable

        End If

        Dim subgroup = Me.txtSubgroup.Text.ToString.Trim

        If Not String.IsNullOrWhiteSpace(subgroup) Then

            If (From rows In e.Query.Cast(Of AssetVerCountSheetView)() Where rows.SubGroup.ToUpper = subgroup.ToUpper).Count = 0 Then

            Else
                e.Query = From rows In e.Query.Cast(Of AssetVerCountSheetView)() Where rows.SubGroup.ToUpper = subgroup.ToUpper
            End If
        Else

        End If


    End Sub

    Protected Sub FilterStatus(ByVal sender As Object, ByVal e As CustomExpressionEventArgs)

    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(control As Control)
        'Verifies that the control is rendered 
        ' prevents "Control 'gv' of type 'GridView' must be placed inside a form tag with runat=server." error
    End Sub

    Protected Sub gv_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles gv.RowDataBound
        ' --- hides the uncompletion count field ---
        If e.Row.Cells.Count > 4 Then
            e.Row.Cells(11).Visible = False
        End If

        ' --- show Y/N links 
        If e.Row.RowType = DataControlRowType.DataRow Then
            Select Case DataBinder.Eval(e.Row.DataItem, "cm")
                Case "Not Found"
                    e.Row.Cells(8).Text = "N"
                    e.Row.BackColor = Drawing.Color.Linen
                Case ""
                    Dim lf As LinkButton = e.Row.FindControl("lnkFound")
                    lf.CommandName = "Select"
                    lf.CausesValidation = False
                    lf.Text = "Y"

                    Dim lnf As LinkButton = e.Row.FindControl("lnkNotFound")
                    lnf.CommandName = "Delete"
                    lnf.CausesValidation = False
                    lnf.Text = "N"
                Case "Exempt from Inventory", "Not in Snapshot"
                    e.Row.Cells(8).Text = ""
                    e.Row.BackColor = Drawing.Color.AliceBlue
                Case Else
                    e.Row.Cells(8).Text = "Y"
                    e.Row.BackColor = Drawing.Color.Honeydew
            End Select

            ' --- show undo links 
            Select Case DataBinder.Eval(e.Row.DataItem, "cm")
                Case ""
                Case "Exempt from Inventory", "Not in Snapshot"
                Case Else
                    Dim undo As LinkButton = e.Row.FindControl("lnkUndo")
                    undo.CommandName = "Update"
                    undo.CausesValidation = False
                    undo.Text = "Undo"
            End Select

            ' --- enable Finalize button only when all assets have been accounted for --- 
            If CStr(e.Row.Cells(11).Text) = "0" Then
                btnFinal.Enabled = True
            Else
                btnFinal.Enabled = False
            End If

        End If
    End Sub

    Protected Sub gv_SelectedIndexChanged(sender As Object, e As EventArgs) Handles gv.SelectedIndexChanged
        ' --- using select function to mark asset as found --- @dateComplete
        
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyUpdate", SWmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@assetId", Me.gv.SelectedRow.Cells(0).Text.ToString)
        cmd.Parameters.AddWithValue("@inventoryName", lblInvName.Text)
        cmd.Parameters.AddWithValue("@completionMethod", "Found in Location")
        cmd.Parameters.AddWithValue("@dateComplete", Date.Today)
        cmd.Parameters.AddWithValue("@completeBy", Session("SWMSUid"))
        cmd.Parameters.AddWithValue("@AVLId", Session("alvId"))

        SwmsAccess.ExecuteNonQuery(cmd, true)

        gv.DataSource = LinqDataSource1
        gv.DataBind()
    End Sub

    Protected Sub gv_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles gv.RowDeleting
        ' --- using delete function to mark asset as not found ---
        
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyUpdate", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@assetId", gv.DataKeys(e.RowIndex).Values("assetId").ToString())
        cmd.Parameters.AddWithValue("@inventoryName", lblInvName.Text)
        cmd.Parameters.AddWithValue("@completionMethod", "Not Found")
        cmd.Parameters.AddWithValue("@dateComplete", Date.Today)
        cmd.Parameters.AddWithValue("@completeBy", Session("SWMSUid"))
        cmd.Parameters.AddWithValue("@AVLId", Session("alvId"))

        SwmsAccess.ExecuteNonQuery(cmd, true)

        gv.DataSource = LinqDataSource1
        gv.DataBind()
    End Sub

    Protected Sub gv_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles gv.RowUpdating
        ' --- using update function to undo found or not found 
        
        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyUpdate", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@assetId", gv.DataKeys(e.RowIndex).Values("assetId").ToString())
        cmd.Parameters.AddWithValue("@inventoryName", lblInvName.Text)
        cmd.Parameters.AddWithValue("@completionMethod", DBNull.Value)
        cmd.Parameters.AddWithValue("@dateComplete", DBNull.Value)
        cmd.Parameters.AddWithValue("@completeBy", DBNull.Value)
        cmd.Parameters.AddWithValue("@AVLId", DBNull.Value)

        SwmsAccess.ExecuteNonQuery(cmd, true)

        gv.DataSource = LinqDataSource1
        gv.DataBind()

    End Sub

    Protected Sub btnFinal_Click(sender As Object, e As EventArgs) Handles btnFinal.Click

        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyFinalize", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@AVLId", Session("alvId"))
        cmd.Parameters.AddWithValue("@completeBy", Session("SWMSUid"))
        cmd.Parameters.AddWithValue("@inventoryName", lblInvName.Text)

        SwmsAccess.ExecuteNonQuery(cmd, true)

        Response.Redirect("AssetInvVer.aspx")
    End Sub

#End Region

#Region "ViewCountSheet"
    Sub countSheetHeaderRow()
        Dim r2 As New TableRow
        'r2.Cells.Add(SwmsUI.DataCell("Asset ID", "center", , , , , , , 60))
        'r2.Cells.Add(SwmsUI.DataCell("CAGE", "center", , , , , , , 60))
        'r2.Cells.Add(SwmsUI.DataCell("Part #", "center", , , , , , , 180))
        'r2.Cells.Add(SwmsUI.DataCell("Nomen.", "center", , , , , , , 300))
        'r2.Cells.Add(SwmsUI.DataCell("NIIN", "center", , , , , , , 100))
        'r2.Cells.Add(SwmsUI.DataCell("Serial #", "center", , , , , , , 100))
        'r2.Cells.Add(SwmsUI.DataCell("Found", "center", , , , , , , 50))
        'r2.Cells.Add(SwmsUI.DataCell("Reported", "center", , , , , , , 50))

        r2.Cells.Add(SwmsUI.DataCell("Asset ID", "center"))
        r2.Cells.Add(SwmsUI.DataCell("SubGroup", "center"))
        r2.Cells.Add(SwmsUI.DataCell("CAGE", "center"))
        r2.Cells.Add(SwmsUI.DataCell("Part #", "center"))
        r2.Cells.Add(SwmsUI.DataCell("Nomen.", "center"))
        r2.Cells.Add(SwmsUI.DataCell("NIIN", "center"))
        r2.Cells.Add(SwmsUI.DataCell("Serial #", "center"))
        r2.Cells.Add(SwmsUI.DataCell("Found", "center"))
        r2.Cells.Add(SwmsUI.DataCell("Reported", "center"))
        r2.BackColor = Drawing.Color.Gainsboro
        r2.CssClass = "smBContent"
        r2.Font.Bold = True
        locTable.Rows.Add(r2)
    End Sub

    Protected Sub viewCountSheet()

        ' --- list of active assets ---
        Dim cmd As New SqlCommand("AssetVerCountSheet", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@AVLid", Session("alvId"))

        dim dsdt as DataTable = SWmsAccess.ExecuteQueryToDataTable(cmd, true)

        If (dsdt.Rows.Count = 0) Then
            lblRowCount.Text = "No assets in this location"
        Else
            If dsdt.Rows.Count = 1 Then
                lblRowCount.Text = "1 item"
            Else
                lblRowCount.Text = dsdt.Rows.Count & " items"
            End If



            generateViewCountSheet(FilterTheDataTable(dsdt))

        End If

    End Sub



    Private Function FilterTheDataTable(dataTable As DataTable) As DataTable



        If Not String.IsNullOrWhiteSpace(Me.txtSubgroup.Text.ToString.Trim) Then
            Dim datacheck = dataTable.AsEnumerable().Where(Function(x) x.Field(Of String)("SubGroup").ToUpper.Equals(Me.txtSubgroup.Text.ToString.Trim.ToUpper)).Count
            If datacheck = 0 Then
                Return dataTable
            Else
                Return dataTable.AsEnumerable().Where(Function(x) x.Field(Of String)("SubGroup").ToUpper.Equals(Me.txtSubgroup.Text.ToString.Trim.ToUpper)).CopyToDataTable
            End If
        Else
            If Me.chkSubGroup.Checked Then
                Return dataTable.AsEnumerable.OrderBy(Function(x) x.Field(Of String)("SubGroup")).CopyToDataTable
            Else
                Return dataTable.AsEnumerable.OrderByDescending(Function(x) x.Field(Of String)("SubGroup")).CopyToDataTable
            End If
        End If
        Return dataTable
    End Function

    Sub extraRows()

        Dim r2 As New TableRow
        str = "<br />Found during inventory - list any units found in location that are not printed on the list"
        r2.Cells.Add(SwmsUI.DataCell(str, "left", 9))
        r2.Height = Unit.Pixel(25)
        r2.CssClass = "Content"
        locTable.Rows.Add(r2)

        countSheetHeaderRow()

        Dim j As Integer
        For j = 1 To 10
            Dim rb As New TableRow
            rb.Cells.Add(SwmsUI.DataCell(""))
            rb.Cells.Add(SwmsUI.DataCell(""))
            rb.Cells.Add(SwmsUI.DataCell(""))
            rb.Cells.Add(SwmsUI.DataCell(""))
            rb.Cells.Add(SwmsUI.DataCell(""))
            rb.Cells.Add(SwmsUI.DataCell(""))
            rb.Cells.Add(SwmsUI.DataCell(""))
            rb.Cells.Add(SwmsUI.DataCell(" Y&nbsp;&nbsp;&nbsp;N ", "center"))
            rb.Cells.Add(SwmsUI.DataCell(" Y&nbsp;&nbsp;&nbsp;N ", "center"))
            locTable.Rows.Add(rb)
        Next

        Dim r4 As New TableRow
        str = "<br />Units Found and not listed in SWMS have been approved for receipt in SWMS _____________________________________"
        str &= "<br /><span class=""TinyContent"" style=""padding-left:550px;"">Name</span><span class=""TinyContent"" style=""padding-left:150px;"">Date</span>"
        r4.Cells.Add(SwmsUI.DataCell(str, "left", 9))
        r4.Height = Unit.Pixel(25)
        r4.CssClass = "Content"
        locTable.Rows.Add(r4)
    End Sub

    Sub generateViewCountSheet(ByVal rs As DataTable)

        If rs.Rows.Count > 0 Then

            If Not IsDBNull(rs.Rows(0)("AssetId")) Then
                countSheetHeaderRow()

                Dim rowsPerPage As Decimal = 45
                Dim rowCounter As Decimal = 0.0
                Dim firstTime As Boolean = True

                Dim i As Integer
                For i = 0 To rs.Rows.Count - 1

                    If rowCounter >= rowsPerPage Then
                        pageBreak(8)
                        rowCounter = 0.0
                        countSheetHeaderRow()
                        rowsPerPage = 50
                    End If

                    Dim r As New TableRow
                    rowCounter += 1
                    r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("AssetId"), "center", , , "false"))
                    r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("SubGroup"), "center", , , "false"))
                    r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("cage"), "center", , , "false"))
                    r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("pn"), "center", , , "false"))
                    r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("nomen"), "center", , , "false"))
                    r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("niin"), "center", , , "false"))
                    r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("sn"), "center", , , "false"))
                    If CStr(rs.Rows(i)("cm")) = "" Then
                        r.Cells.Add(SwmsUI.DataCell(" Y&nbsp;&nbsp;&nbsp;N ", "center"))
                        r.Cells.Add(SwmsUI.DataCell(" Y&nbsp;&nbsp;&nbsp;N ", "center"))
                    Else
                        r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("cm"), "center"))
                        r.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("datecomplete"), "center")) ' & " by " & rs.Rows(i)("cmpBY")
                    End If

                    Select Case CStr(rs.Rows(i)("cm"))
                        Case "Exempt from Inventory", "Not in Snapshot"
                            r.BackColor = Drawing.Color.AliceBlue
                        Case "Not Found"
                            r.BackColor = Drawing.Color.Linen
                        Case "Found in Location"
                            r.BackColor = Drawing.Color.Honeydew
                    End Select
                    locTable.Rows.Add(r)
                Next
            End If

        End If

    End Sub

    Sub pageBreak(ByVal cols As Integer)
        Dim hr As New TableRow
        hr.Cells.Add(SwmsUI.DataCell("&nbsp;<div style=""PAGE-BREAK-AFTER:always""></div>", "center", cols))
        locTable.Rows.Add(hr)
    End Sub

    Protected Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click

        Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifyPrintCountSheet", SwmsAccess.GetSwmsConnection())
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@AVLId", Session("alvId"))
        cmd.Parameters.AddWithValue("@inventoryName", Session("InventoryName"))

        SwmsAccess.ExecuteNonQuery(cmd, true)

        btnPrint.Visible = False
        Dim strPage As String = "javascript:window.print();"
        Page.ClientScript.RegisterClientScriptBlock(GetType(String), "print", strPage, True)
    End Sub
#End Region

#Region "not used"
    Protected Sub btnSearch_Click(sender As Object, e As System.EventArgs)
        '    Dim assetId As String = ""
        '    conn.ConnectionString = Session("swmsDbConnection")
        '    Dim cmd As New Data.SqlClient.SqlCommand("AssetVerifySearch", conn)
        '    cmd.CommandType = CommandType.StoredProcedure
        '    cmd.Parameters.AddWithValue("@niin", cC.BufStr(txtNiin.Text.Trim))
        '    cmd.Parameters.AddWithValue("@serial", cC.BufStr(txtSn.Text.Trim))
        '    cmd.Parameters.AddWithValue("@inventoryName", lblInvName.Text)
        '    cmd.Parameters.AddWithValue("@completeBy", Session("SWMSUid"))
        '    cmd.Parameters.AddWithValue("@AVLId", Session("alvId"))

        '    cmd.Parameters.Add("@assetId", SqlDbType.Int)
        '    cmd.Parameters("@assetId").Direction = ParameterDirection.Output
        '    ' Try
        '    conn.Open()
        '    'cmd.ExecuteNonQuery()
        '    cmd.ExecuteNonQuery()
        '    assetId = cmd.Parameters("@assetId").Value

        '    If assetId = "0" Then
        '        lblmsg.Text = "Do Receiving Transaction"
        '    End If
        '    '  Catch ex As Exception
        '    ' Finally
        '    conn.Close()
        '    conn.Dispose()
        '    ' End Try

        '    gv.DataSource = LinqDataSource1
        '    gv.DataBind()
    End Sub

    Protected Sub Print(sender As Object, e As EventArgs)
        '    '<asp:ImageButton ID="btnPrint" runat="server" CausesValidation="false" ImageUrl="~/images/printer2.gif" OnClick="Print" />
        '    gv.UseAccessibleHeader = True
        '    gv.HeaderRow.TableSection = TableRowSection.TableHeader
        '    gv.FooterRow.TableSection = TableRowSection.TableFooter
        '    gv.Attributes("style") = "border-collapse:separate"

        '    For Each row As GridViewRow In gv.Rows
        '        If row.RowIndex Mod 40 = 0 AndAlso row.RowIndex <> 0 Then
        '            row.Attributes("style") = "page-break-after:always;"
        '        End If
        '    Next

        '    Dim sw As New StringWriter()
        '    Dim hw As New HtmlTextWriter(sw)

        '    gv.RenderControl(hw)
        '    Dim gridHTML As String = sw.ToString().Replace("""", "'").Replace(System.Environment.NewLine, "")
        '    Dim sb As New StringBuilder()
        '    sb.Append("<script type = 'text/javascript'>")
        '    sb.Append("window.onload = new function(){")
        '    sb.Append("var printWin = window.open('', '', 'left=0")
        '    sb.Append(",top=0,width=1000,height=600,status=no,resizable=yes, left=50,scrollbars=yes');")
        '    sb.Append("printWin.document.write(""")
        '    Dim style As String = "<style type = 'text/css'>thead {display:table-header-group;} tfoot{display:table-footer-group;}</style>"
        '    sb.Append(style & gridHTML)
        '    sb.Append(""");")
        '    sb.Append("printWin.document.close();")
        '    sb.Append("printWin.focus();")
        '    sb.Append("printWin.print();")
        '    'sb.Append("printWin.close();")
        '    sb.Append("};")
        '    sb.Append("</script>")
        '    ClientScript.RegisterStartupScript(Me.[GetType](), "GridPrint", sb.ToString())
        '    gv.DataBind()

    End Sub
#End Region

    Protected Sub btnSubGroup_Click(sender As Object, e As EventArgs) Handles btnSubGroup.Click
        Me.gv.DataBind()
    End Sub




End Class
