﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Tracking_EditMeters
    Inherits System.Web.UI.Page

#Region "declarations"
    Dim sql As String = ""
    Dim str As String
    Dim cmd as SqlCommand = new SqlCommand()    
#End Region

#Region "pageLoad"
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        SwmsAccess.ValidateSession()

        AAddValuesSqlCommandParameters()

        If Request.QueryString("sn") <> "" Then
            If Request.QueryString("sn") <> CStr(txtSn.Text) Then
                lblSnWarning.Text = "Click update to apply new serial number"
            End If
        End If
        

        If Not Page.IsPostBack Then
            fillDdls()
            If CStr(Request.QueryString("id")) <> "" And _
             CStr(Request.QueryString("id")) <> "0" Then ' an asset is selected for edit
                displayMeter(Request.QueryString("id"))
                btnUPd.Visible = True
                btnAdd.Visible = False
            Else ' form is blank for adding a new asst

                If Request.QueryString("sn") <> "" Then
                    txtSn.Text = Request.QueryString("sn")
                End If
                btnUPd.Visible = False
                btnAdd.Visible = True
            End If
        Else
            Select Case txtCommand.Value
                Case "add" ' adds new meter record
                    addNew()
                Case "upd" ' the update button was clicked 
                    updMeter()
                Case "addPrep", "pic", "can"
                    displayMeter(Request.QueryString("id"))
                Case "addRdg"
                    addRdg()
                Case "updRdg"
                    updRdg()
                Case "delRdg"
                    delRdg()
                Case Else ' a new location was selected or added OR the add level button was clicked
                    displayReadings()
            End Select
            txtCommand.Value = ""
        End If

    End Sub
#End Region

#Region " meters "

    '---fill the dropdown lists (except for locations)
    Sub fillDdls()

    
        ' meter type --------------------------------------------
        ddlMtrType.Items.Clear()
        sql = "" 'select '---' as SVD_Attribute union all"
        sql &= " SELECT SVD_Attribute FROM System_Validation_Dictionary "
        sql &= " WHERE (SVD_Name = 'MeterType') ORDER BY SVD_Attribute"

        SwmsUI.LoadDropDown(ddlMtrType,
        sql,
        Nothing,
        False,
        "SVD_Attribute",
        "SVD_Attribute")
    End Sub

    '---displays the selected meter record
    Sub displayMeter(ByVal mtrId As String)
        Session("mtrId") = mtrId

        If CStr(mtrId) = "" Then
            Response.Redirect("FindMeters.aspx")
        Else
            sql = " select meterid, isnull(metertype,'') as mtrType,  "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "        loc1.locationidcode else locAh1.locationIdCode end,'') as loc1,  "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "            loc2.locationidcode else locAh2.locationIdCode end,'') as loc2, "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "        loc3.locationidcode else locAh3.locationIdCode end ,'') as loc3,  "
            sql &= "    isnull(case when mtr.assetid is null then "
            sql &= "        loc4.locationidcode else locAh4.locationIdCode end ,'') as loc4, "
            sql &= "    isnull(mtr.assetid,0) as assetId, isnull(ass.serialnumber,'') as sn,  "
            sql &= "    isnull(Rollover,0) as rolo, isnull(Comments,'') as cmt "
            sql &= " from meters mtr "
            sql &= "    left outer join assets ass on mtr.assetid = ass.assetid "
            '---join locations on meter
            sql &= "    left outer join locations loc1 on mtr.locationid = loc1.locationid  "
            sql &= "    left outer join locations loc2 on mtr.location2 = loc2.locationid  "
            sql &= "    left outer join locations loc3 on mtr.location3 = loc3.locationid  "
            sql &= "    left outer join locations loc4 on mtr.location4 = loc4.locationid  "
            '--- determine most recent assethistory record
            sql &= "    left outer join ( "
            sql &= "        select assetid, max(assethistoryid) as maxid from assethistory group by assetid "
            sql &= "    ) mah on mtr.assetid = mah.assetid "
            '--- join on most recent asset history record
            sql &= "    left outer join assethistory ah on mah.maxid = ah.assethistoryid "
            '---join locations on most recent asset history record
            sql &= "    left outer join locations locAh1 on ah.locationid = locAh1.locationid  "
            sql &= "    left outer join locations locAh2 on ah.location2 = locAh2.locationid  "
            sql &= "    left outer join locations locAh3 on ah.location3 = locAh3.locationid  "
            sql &= "    left outer join locations locAh4 on ah.location4 = locAh4.locationid "
            sql &= " where (meterid = @meterid)"

            
            Dim rs As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
                new SqlParameter("@MeterId", mtrId)
            })            

            lblId.Text = rs.Rows(0)("meterid") ' rdr("meterid")
            txtCmt.Text = rs.Rows(0)("cmt") ' rdr("cmt")
            txtRolo.Text = FormatNumber(rs.Rows(0)("rolo"), 0, , , 0)
            Try
                ddlMtrType.SelectedValue = rs.Rows(0)("mtrType") ' rdr("mtrType")
            Catch ex As Exception
            End Try
            ' ---these maybe affected if navigated from assets
            txtSn.Text = rs.Rows(0)("sn") ' rdr("sn")
            txtLoc1.Text = rs.Rows(0)("loc1")
            txtLoc2.Text = rs.Rows(0)("loc2")
            txtLoc3.Text = rs.Rows(0)("loc3")
            txtLoc4.Text = rs.Rows(0)("loc4")

            If CStr(Request.QueryString("aid")) <> "" Then
                txtAid.Value = Request.QueryString("aid")             
            Else
                txtAid.Value = rs.Rows(0)("assetId") ' rdr("assetId")
            End If

            If CStr(txtAid.value) = "0" Then '  the meter is NOT attached to an asset
                '  displayLocation(txtLoc.Text) ' allow the location to be edited
                lnkAst.Visible = False
                lblAst.Visible = False
            Else ' the meter IS attached to an asset 
                lblAst.Visible = True
                lnkAst.Visible = True ' link to asset from meter
                lnkAst.NavigateUrl = "EditAsset.aspx?id=" & txtAid.value
                lnkAst.Text = txtSn.Text
                'txtLoc1.ReadOnly = True
                'txtLoc2.ReadOnly = True
                'txtLoc3.ReadOnly = True
                'txtLoc4.ReadOnly = True
            End If

            displayReadings()
        End If

    End Sub

    '---begins the process of validating a new meter to the meters table
    Sub addNew()
        UsrMsg.Value = ""
        Dim ok2go As Boolean = False

        'deal with asset serial number ------
        If CStr(txtSn.Text) <> "" Then ' 
            If CStr(txtAid.value) = "" Then ' asset sn was entered but not verified
                '------------------------------------------------------------------
                Dim strSn As String = txtAid.value.Trim
                sql = "select ast.assetid,  "
                sql &= "    isnull(locAh1.locationIdCode,'') as loc1,"
                sql &= "    isnull(locAh2.locationIdCode,'') as loc2,"
                sql &= "    isnull(locAh3.locationIdCode,'') as loc3,"
                sql &= "    isnull(locAh4.locationIdCode,'') as loc4"
                sql &= " from assets ast"
                sql &= "    left outer join ( "
                sql &= "        select assetid, max(assethistoryid) as maxid from assethistory group by assetid "
                sql &= "    ) mah on ast.assetid = mah.assetid "
                sql &= "    left outer join assethistory ah on mah.maxid = ah.assethistoryid"
                sql &= "    left outer join locations locAh1 on ah.locationid = locAh1.locationid  "
                sql &= "    left outer join locations locAh2 on ah.location2 = locAh2.locationid  "
                sql &= "    left outer join locations locAh3 on ah.location3 = locAh3.locationid  "
                sql &= "    left outer join locations locAh4 on ah.location4 = locAh4.locationid"
                sql &= " where serialnumber = @Serialnumber"

                ' cmd.CommandText = sql    
                ' Dim rq As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)   

                dim rq as DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
                    new SqlParameter("@Serialnumber", Server.HtmlEncode(Request.Form("txtSn")))
                })             

                Dim i As Integer
                For i = 0 To rq.Rows.Count - 1
                    txtAid.Value = rq.Rows(i)("AssetId") ' rdr("assetid")
                    txtLoc1.Text = rq.Rows(i)("loc1") ' rdr("assetid")
                    txtLoc2.Text = rq.Rows(i)("loc2") ' rdr("assetid")
                    txtLoc3.Text = rq.Rows(i)("loc3") ' rdr("assetid")
                    txtLoc4.Text = rq.Rows(i)("loc4") ' rdr("assetid")
                Next

                'if ONLY one match is found call addSerialNumber
                If rq.Rows.Count = 1 Then
                    ok2go = True
                Else
                    Dim snPopUp As String
                    If rq.Rows.Count = 0 Then 'suggest redirect to maintain assets page
                        snPopUp = "if (confirm('" & Request.Form("txtSn") & " was not found. Do you want to add it?')) {"
                        snPopUp &= "window.location.assign('EditAsset.aspx?sn=" & Request.Form("txtSn")
                        snPopUp &= "&mtr=" & Request.QueryString("id") & "');}"
                    Else ' more than one match was found, pop-up the search screen
                        txtCommand.Value = "addSnPrep"
                        snPopUp = "vWinSch = window.open(""SNSearch.aspx?sn=" & Request.Form("txtSn") & """,""SN"","
                        snPopUp &= """width=400,height=424,status=no,resizable=yes,top=75,left=175,scrollbars=yes"");"
                        snPopUp &= "vWinSch.opener = self;"
                        snPopUp &= "vWinSch.focus();"
                    End If
                    Response.Write("<SCRIPT LANGUAGE='JavaScript'>" & snPopUp & "</SCRIPT>")
                End If
                '------------------------------------------------------------------
            Else ' the id has been verified for the asset
                ok2go = True
            End If
        Else ' the meter is not attached to an asset
            ok2go = True
        End If

        If ok2go = True Then
            validLocations("add")
        End If

    End Sub

    '---really adds the meter
    Private Sub addMeter(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)
        '' insert the new meter record -----------
        sql = "insert into Meters (MeterType, LocationId, Location2, Location3, Location4, Rollover, Comments, AssetId)"
        sql &= " Values (@MeterType, " ' MeterType
        sql &= " @loc1, @loc2, @loc3, @loc4, "
        If IsNumeric(txtRolo.Text) Then
            sql &= " @Rollover, "
        Else
            sql &= " NULL, "
        End If
        sql &= "@comments, "
        If CStr(txtAid.Value) <> "" Then
            sql &= " @aid)" ' AssetId
        Else
            sql &= " NULL)" ' AssetId
        End If
        sql &= " SELECT SCOPE_IDENTITY() "

        'get the new meterid -----------
        ' cmd.CommandText = sql
        ' Dim dlId As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)  <--npt??

        Dim dlId As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
            new SqlParameter("@loc1", loc1),
            new SqlParameter("@loc2", loc2),
            new SqlParameter("@loc3", loc3),
            new SqlParameter("@loc4", loc4),
            new SqlParameter("@MeterType", ddlMtrType.SelectedValue),
            new SqlParameter("@Rollover", txtRolo.Text.Trim),
            new SqlParameter("@Comments", Left(txtCmt.text, 200).Trim),
            new SqlParameter("@aid", txtAid.value)
        })
        

        If dlId.Rows.Count > 0 Then
            Response.Redirect("EditMeters.aspx?id=" & dlId.Rows(0).Item(0))
        End If

    End Sub

    '---validates the locations
    Sub validLocations(ByVal action As String)
        '---validate the locations
        UsrMsg.Value = ""

        Dim loc1 As Integer = 0, loc2 As Integer = 0
        Dim loc3 As Integer = 0, loc4 As Integer = 0

        '---1st level - super
        If CStr(Request.Form("txtLoc1").Trim) <> "" Then
            Dim sql1 As String = "select top 1 LocationId from locations"
            sql1 &= " where (locationlevel = 1)"
            sql1 &= " and (locationidcode = @loc1)"
            sql1 &= " order by locationid"

            'cmd.CommandText = sql1
            Dim rl1 As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql1, new SqlParameter(){
                new SqlParameter("@loc1", Request.Form("txtLoc1"))
            })
            If rl1.Rows.Count > 0 Then ' its a match
                loc1 = rl1.Rows(0)("locationid")
            Else
                UsrMsg.Value &= "Super location '" & Request.Form("txtLoc1").Trim & "' not found "
            End If
        End If

        '---2nd level - location
        If CStr(Request.Form("txtLoc2").Trim) <> "" Then
            Dim sql2 As String = "select top 1 locationid, "
            sql2 &= " parentlocationid from locations"
            sql2 &= " where (locationidcode = @loc2)"
            sql2 &= " and (locationlevel = 2)"
            If loc1 <> 0 Then
                sql2 &= " and (parentlocationid = @loc1)" '--------------------
            End If
            sql2 &= " order by locationid"

            Dim rl2 As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql2, new SqlParameter(){
                new SqlParameter("@loc1", loc1),
                new SqlParameter("@loc2", Request.Form("txtLoc2"))
            })



            'Dim rl2 As DataTable = cC.getAsDataTable(sql2, Session("swmsDbConnection"))
            If rl2.Rows.Count > 0 Then ' its a match
                loc2 = rl2.Rows(0)("locationid")
                loc1 = rl2.Rows(0)("parentlocationid")
            Else
                UsrMsg.Value &= "Location '" & Request.Form("txtLoc2").Trim & "' not found "
            End If
        End If

        '---3rd level - sub
        If CStr(Request.Form("txtLoc3").Trim) <> "" Then
            Dim sql3 As String = " select  top 1 locationid, parentlocationid, "
            sql3 &= " isnull((select parentlocationid from locations "
            sql3 &= "   where locationid = loc.parentlocationid),0) as grandLocationid "
            sql3 &= " from locations loc"
            sql3 &= " where (locationidcode = @Loc3)"
            sql3 &= " and (locationlevel = 3)"
            If loc2 <> 0 Then
                sql3 &= " and (parentlocationid = @loc2)" '--------------------
            End If
            sql3 &= " order by locationid"

            ' cmd.CommandText = sql3
            ' Dim rl3 As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

            Dim rl3 As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql3, new SqlParameter(){
                new SqlParameter("@loc2", loc2),
                new SqlParameter("@loc3", Request.Form("txtLoc3"))
            })

            'Dim rl3 As DataTable = cC.getAsDataTable(sql3, Session("swmsDbConnection"))
            If rl3.Rows.Count > 0 Then ' its a match
                loc3 = rl3.Rows(0)("locationid")
                loc2 = rl3.Rows(0)("parentlocationid")
                loc1 = rl3.Rows(0)("grandLocationid")
            Else
                UsrMsg.Value &= "Sub Location '" & Request.Form("txtLoc3").Trim & "' not found "
            End If
        End If

        '---4th level - micro
        If CStr(Request.Form("txtLoc4").Trim) <> "" Then
            Dim sql4 As String = " select top 1 locationid, parentlocationid, "
            sql4 &= " isnull((select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid),0) as grandLocationid, "
            sql4 &= " isnull((select parentlocationid from locations"
            sql4 &= "   where locationid = (select parentlocationid from locations "
            sql4 &= "   where locationid = loc.parentlocationid)),0) as greatlocationid"
            sql4 &= "  from locations loc"
            sql4 &= " where (locationidcode = @Loc4)"
            sql4 &= " and (locationlevel = 4)"
            If loc3 <> 0 Then
                sql4 &= " and (parentlocationid = @loc3)" '--------------------
            End If
            sql4 &= " order by locationid"
            
            ' cmd.CommandText = sql4
            ' Dim rl4 As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)


            Dim rl4 As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql4, new SqlParameter(){
                new SqlParameter("@loc3", loc3),
                new SqlParameter("@loc4", Request.Form("txtLoc4"))
            })

            'Dim rl4 As DataTable = cC.getAsDataTable(sql4, Session("swmsDbConnection"))
            If rl4.Rows.Count > 0 Then ' its a match
                loc4 = rl4.Rows(0)("locationid")
                loc3 = rl4.Rows(0)("parentlocationid")
                loc2 = rl4.Rows(0)("grandlocationid")
                loc1 = rl4.Rows(0)("greatlocationid")
            Else
                UsrMsg.Value &= "Micro Location '" & Request.Form("txtLoc4").Trim & "' not found"
            End If
        End If

        If UsrMsg.Value = "" Then

            If action = "add" Then
                addMeter(loc1, loc2, loc3, loc4)
            End If
            If action = "upd" Then
                reallyUpdateMeter(loc1, loc2, loc3, loc4)
            End If

        End If
    End Sub

    '---begins the process of validating updates to the meter record
    Sub updMeter()
        Dim ok2go As Boolean = False

        If txtPicked.Value = "pick" Then ' if a serial number is selected
            ok2go = True
        Else
            If CStr(txtSn.Text) = "" Then  ' if a serial number is not entered
                ok2go = True
            Else ' NO serial number is entered
                'look up the old serial number to see if its changed on the form
                Dim luSql As String = "select isnull(m.AssetId,0) as assetId, isnull(ass.Serialnumber,'') as sn"
                luSql &= " from meters m left outer join assets ass on m.assetid = ass.assetid"
                luSql &= " where (meterid = @meterid)"

                cmd.CommandText = luSql
                Dim rs As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

                If rs.Rows.Count > 0 Then
                    If Server.HtmlEncode(rs.Rows(0)("sn")) = Server.HtmlEncode(txtSn.Text.Trim) Then ' no change
                        ok2go = True
                    Else
                        'look up the entered serial number
                        Dim sql2 As String = "select assetid from assets where serialnumber = @Serialnumber"

                        cmd.CommandText = sql2
                        Dim rt As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)
                        

                        Dim i As Integer
                        For i = 0 To rt.Rows.Count - 1
                            txtAid.Value = rt.Rows(i)("assetid") ' rdr2("assetid")
                        Next

                        If rt.Rows.Count = 1 Then 'if theres only 1, return the asset id
                            ok2go = True
                        Else
                            Dim snPopUp As String
                            If rt.Rows.Count = 0 Then 'suggest redirect to maintain assets page
                                snPopUp = "if (confirm('" & Request.Form("txtSn") & " was not found. Do you want to add it?')) {"
                                snPopUp &= "window.location.assign('EditAsset.aspx?sn=" & Request.Form("txtSn")
                                snPopUp &= "&mtr=" & Request.QueryString("id") & "');}"
                            Else ' more than one match was found, pop-up the search screen
                                txtCommand.Value = "addSnPrep"
                                snPopUp = "vWinSch = window.open(""SNSearch.aspx?sn=" & Request.Form("txtSn") & """,""SN"","
                                snPopUp &= """width=400,height=424,status=no,resizable=yes,top=75,left=175,scrollbars=yes"");"
                                snPopUp &= "vWinSch.opener = self;"
                                snPopUp &= "vWinSch.focus();"
                            End If
                            Response.Write("<SCRIPT LANGUAGE='JavaScript'>" & snPopUp & "</SCRIPT>")
                        End If ' couunter = 1
                    End If ' matched
                End If ' If luRdr.Read Then
            End If ' serial number is entered
        End If ' If txtPicked.Text = "pick" Then
        'deal with the serial number

        If ok2go = True Then
            validLocations("upd")
        End If
        txtPicked.Value = ""
    End Sub

    '---really updates the meter
    Private Sub reallyUpdateMeter(ByVal loc1 As Integer, ByVal loc2 As Integer, ByVal loc3 As Integer, ByVal loc4 As Integer)

        Dim insAssetHist As Boolean = False

        sql = "update meters set "
        If CStr(txtSn.Text) = "" Then
            sql &= " assetid = NULL, "
        Else
            sql &= " assetid = @aid, "
        End If
        If IsNumeric(txtRolo.Text) Then
            sql &= " Rollover = @Rollover, "
        End If
        sql &= " MeterType = @MeterType, "
        sql &= " Comments = @Comments"

        If CStr(txtSn.Text) = "" Then ' meter is not attached to asset
            '---update the meter location
            sql &= ", LocationId = @loc1, Location2 = @loc2, "
            sql &= " Location3 = @Loc3, Location4 = @loc4 "
        Else ' meter is attached to asset
            '---update the most recent asset history location
            insAssetHist = True
        End If
        sql &= " where (MeterId = @MeterId) "

        Try
            SwmsAccess.executeNonQuery(sql, new SqlParameter(){
                new SqlParameter("@aid", txtAid.Value),
                new SqlParameter("@Rollover", txtRolo.Text),
                new SqlParameter("@MeterType", ddlMtrType.SelectedValue),
                new SqlParameter("@Comments", Left(Server.HtmlEncode(txtCmt.Text), 200).Trim),
                new SqlParameter("@loc1", loc1),
                new SqlParameter("@loc2", loc2),
                new SqlParameter("@Loc3", loc3),
                new SqlParameter("@loc4", loc4),
                new SqlParameter("@MeterId", Request.QueryString("id"))
            })
            
        Catch ex As Exception
        End Try

        If insAssetHist = True Then
            sql = "Insert into assethistory "
            sql &= "    (assetid, bssid,conditioncode, transdate, transby, remarks,"
            sql &= "    reason, documentnumber, ilsmiscontrolnumber, LocationId, Location2, "
            sql &= "    location3, location4, Status, Purposecode, ProcurementCode, "
            sql &= "    MaintDocNumber, EffectiveDate, oldAssetId, ReworkNumber)"

            sql &= " select top 1 assetid, bssid, conditioncode, getdate(), "
            sql &= " @peopleid transby, 'Meter location update' as remarks, "
            sql &= "    reason, documentnumber, ilsmiscontrolnumber, "
            sql &= " @loc1, @loc2, @loc3, @loc4, "
            sql &= "    status, purposecode, procurementcode, maintdocnumber, effectivedate, "
            sql &= "    oldassetid, reworknumber "
            sql &= " from assethistory WHERE (assetid = @aid) order by transdate desc"

            ' cmd.CommandText = sql
            ' SwmsAccess.executeNonQuery(cmd)

            SwmsAccess.executeNonQuery(sql, new SqlParameter(){
                new SqlParameter("@peopleid", Session("SWMSUId")),
                new SqlParameter("@loc1", loc1),
                new SqlParameter("@loc2", loc2),
                new SqlParameter("@Loc3", loc3),
                new SqlParameter("@loc4", loc4),
                new SqlParameter("@aid", txtAid.value)
            })
            
        
        End If

        Response.Redirect("EditMeters.aspx?id=" & Request.QueryString("id"))

    End Sub

#End Region

#Region " readings "

    'build the meter readings table
    Sub displayReadings()

        If CStr(Request.QueryString("id")) <> "" Then
            readingsHeader()
            addRow()

            sql = "select meterrdgid, rDate, rValue, rSrc, rCmt, stat, prevRdg, numDays, "
            sql &= " case when stat = 'Failed' then rFhpd else"
            '---if status is failed, then show what was entered
            '---ohter wise (current value - prev. value) / date diff
            sql &= "    (rValue - prevRdg) / numDays end as rFhpd  from ("

            sql &= " select meterrdgid, rdgDate as rDate, "
            sql &= "    isnull(rdgvalue,0) as rValue, isnull(failhrsperday,0) as rFhpd, "
            sql &= "        datediff(d, (select top 1 RdgDate from meterreadings "
            sql &= "        where (meterid = mr.meterid) and (rdgDate < mr.RdgDate) and (status <> 'Exclude')"
            sql &= "        order by rdgDate desc), rdgDate) as numDays,"
            sql &= "    (select top 1 rdgValue from meterreadings "
            sql &= "        where (meterid = mr.meterid) and (rdgDate < mr.RdgDate) and (status <> 'Exclude')"
            sql &= "        order by rdgDate desc) as prevRdg,"
            sql &= "    isnull(source,'') as rSrc, isnull(comments,'') as rCmt, isnull(status,'') as stat "
            sql &= " from meterreadings mr where (meterid = @MeterId) "

            sql &= " ) ty ORDER BY rDate DESC"

            ' cmd.CommandText = sql
            ' Dim rm As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

            Dim rm As DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlParameter(){
                new SqlParameter("@MeterId",  Request.QueryString("id"))
            })

            Dim altRow As Boolean = False
            Dim i As Integer
            For i = 0 To rm.Rows.Count - 1
                Dim x1 As New TableRow
                If CStr(rm.Rows(i)("meterrdgid")) = CStr(txtPicked.Value) Then

                    str = "<input type=""text"" class=""SmContent"" size=""10"" maxlength=""10"""
                    str &= " id=""txtDate"" name=""txtDate"" onblur=""javascript:return(chkDate(this));"" "
                    If IsDate(rm.Rows(i)("rdate")) Then
                        str &= " value="""">"
                    Else
                        str &= " value=""" & rm.Rows(i)("rdate") & """>"
                    End If
                    x1.Cells.Add(SwmsUI.DataCell(str, "center"))

                    str = "<input type=""text"" class=""SmContent"" maxlength=""10"" onblur=""javascript:numChk(this);"" "
                    str &= " size=""8""  id=""txtValue"" name=""txtValue"" value=""" & rm.Rows(i)("rValue") & """>"
                    x1.Cells.Add(SwmsUI.DataCell(str, "center"))

                    str = "<select name=""selStatus"" id=""selStatus"" class=""SmContent"">"
                    Dim stSql As String = " SELECT SVD_Attribute FROM System_Validation_Dictionary "
                    stSql &= " WHERE (SVD_Name = 'MeterStatus') ORDER BY SVD_Attribute"
                    
                    cmd.CommandText = stSql
                    Dim ri As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)
                    
                    If ri.Rows.Count > 0 Then
                        Dim j As Integer
                        For j = 0 To ri.Rows.Count - 1
                            str &= "<option value=""" & ri.Rows(j)("SVD_Attribute") & """"
                            If CStr(ri.Rows(j)("SVD_Attribute")) = CStr(rm.Rows(i)("stat")) Then
                                str &= " selected "
                            End If
                            str &= ">" & ri.Rows(j)("SVD_Attribute") & "</option>"
                        Next
                    End If
                    str &= "</select>"
                    x1.Cells.Add(SwmsUI.DataCell(str, "center"))

                    x1.Cells.Add(SwmsUI.DataCell("", "center"))

                    str = "<input type=""text"" class=""SmContent"" size=""5"" maxlength=""6"""
                    str &= " onblur=""javascript:numChk(this);"" id=""txtFh"" name=""txtFh"" "
                    If Not IsDBNull(rm.Rows(i)("rFhpd")) Then
                        str &= " value=""" & FormatNumber(rm.Rows(i)("rFhpd"), 2) & """ "
                    End If
                    str &= ">"
                    x1.Cells.Add(SwmsUI.DataCell(str, "center"))

                    str = "<input type=""text"" class=""SmContent"" size=""25"" maxlength=""200"""
                    str &= " id=""txtRdgCmt"" name=""txtRdgCmt"" value=""" & rm.Rows(i)("rCmt") & """>"
                    x1.Cells.Add(SwmsUI.DataCell(str, "center"))

                    str = "<a href=""javascript:updRdg();"">Upd</a>&nbsp; <a href=""javascript:can();"">Can</a>&nbsp;"
                    str &= "<a href=""javascript:delRdg();"">Del</a>"
                    x1.Cells.Add(SwmsUI.DataCell(str, "center"))
                Else

                    If IsDBNull(rm.Rows(i)("rDate")) Then
                        x1.Cells.Add(SwmsUI.DataCell(""))
                    Else
                        If rm.Rows(i)("rDate") = "1/1/1900" Then
                            x1.Cells.Add(SwmsUI.DataCell(""))
                        Else
                            x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("rDate"), "center"))
                        End If
                    End If

                    x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("rValue"), "center"))
                    x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("stat"), "center"))
                    '--------------------------------------------------------------------------------------
                    If IsDBNull(rm.Rows(i)("numDays")) Or CStr(rm.Rows(i)("stat")) = "Exclude" Then
                        x1.Cells.Add(SwmsUI.DataCell("", "center"))
                    Else
                        x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("numDays"), "center"))
                    End If
                    '--------------------------------------------------------------------------------------

                    Dim str2 As String = ""
                    If IsDBNull(rm.Rows(i)("rFhpd")) Or CStr(rm.Rows(i)("stat")) = "Exclude" Then
                        x1.Cells.Add(SwmsUI.DataCell("", "center"))
                    Else
                        str = FormatNumber(rm.Rows(i)("rFhpd"), 2)
                        str2 = "(" & rm.Rows(i)("rValue") & " - " & rm.Rows(i)("prevRdg") & ") / " & rm.Rows(i)("numDays") ' 
                        If CStr(rm.Rows(i)("stat")) = "Failed" Then
                            str &= "*"
                            str2 = "Estimate Hours Per Day"
                        End If
                        x1.Cells.Add(SwmsUI.DataCell(str, "center", , str2))
                    End If

                    '--------------------------------------------------------------------------------------
                    If Len(rm.Rows(i)("rCmt")) > 30 Then
                        x1.Cells.Add(SwmsUI.DataCell(Left(rm.Rows(i)("rCmt"), 27) & "...", "center", , rm.Rows(i)("rCmt")))
                    Else
                        x1.Cells.Add(SwmsUI.DataCell(rm.Rows(i)("rCmt"), "center"))
                    End If

                    x1.Cells.Add(SwmsUI.DataCell("<a href=""javascript:picMe('" & rm.Rows(i)("meterrdgid") & "');"">Edit</a>", "center"))
                End If

                If altRow = False Then
                    x1.BackColor = System.Drawing.Color.White
                    altRow = True
                Else
                    x1.BackColor = System.Drawing.Color.WhiteSmoke
                    altRow = False
                End If
                tblReadings.Rows.Add(x1)

            Next

        End If

    End Sub

    'builds the column headers for the readings table
    Sub readingsHeader()
        Dim x1 As New TableRow

        x1.Cells.Add(SwmsUI.DataCell("Date", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Reading", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Status", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("# Days", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Hrs/Day", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Comments", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("", "center", , , , "LightSteelBlue"))
        x1.CssClass = "smBContent"
        tblReadings.Rows.Add(x1)
    End Sub

    'creates the add reading link or add reading textboxes
    Sub addRow()
        Dim x1 As New TableRow
        If txtCommand.Value = "addPrep" Then

            str = "<input type=""text"" id=""txtDate"" class=""SmContent"" onblur=""javascript:return(chkDate(this));"" "
            str &= " value=""" & Request.Form("txtDate") & """ size=""10"" maxlength=""10"" name=""txtDate"" >*"
            x1.Cells.Add(SwmsUI.DataCell(str, "center"))

            str = "<input type=""text"" id=""txtValue"" name=""txtValue"" class=""SmContent"" size=""8"" "
            str &= " onblur=""javascript:numChk(this);"" value=""" & Request.Form("txtValue") & """  maxlength=""10"">*"
            x1.Cells.Add(SwmsUI.DataCell(str, "center"))

            str = "<select name=""selStatus"" id=""selStatus"" class=""SmContent"">"
            Dim stSql As String = " SELECT SVD_Attribute FROM System_Validation_Dictionary "
            stSql &= " WHERE (SVD_Name = 'MeterStatus') ORDER BY SVD_Attribute"

            cmd.CommandText = stSql
            Dim rh As DataTable = SwmsAccess.ExecuteQueryToDataTable(cmd)

            If rh.Rows.Count > 0 Then
                Dim i As Integer
                For i = 0 To rh.Rows.Count - 1
                    str &= "<option value=""" & rh.Rows(i)("SVD_Attribute") & """ "
                    If rh.Rows(i)("SVD_Attribute") = "Pending" Then
                        str &= " selected"
                    End If
                    str &= ">" & rh.Rows(i)("SVD_Attribute") & "</option>"
                Next
            End If
            str &= "</select>"
            x1.Cells.Add(SwmsUI.DataCell(str, "center"))

            x1.Cells.Add(SwmsUI.DataCell("", "center"))

            str = "<input type=""text"" id=""txtFh"" name=""txtFh"" class=""SmContent"" size=""5"" "
            str &= " onblur=""javascript:numChk(this);"" value=""" & Request.Form("txtFh") & """ maxlength=""6"">"
            x1.Cells.Add(SwmsUI.DataCell(str, "center"))

            str = "<input type=""text"" id=""txtRdgCmt"" name=""txtRdgCmt"" class=""SmContent"""
            str &= " value=""" & Request.Form("txtRdgCmt") & """ size=""25"" maxlength=""200"">"
            x1.Cells.Add(SwmsUI.DataCell(str, "center"))

            x1.Cells.Add(SwmsUI.DataCell("<a href=""javascript:addRdg();"">Add</a>&nbsp;<a href=""javascript:can();"">Can</a>", "center"))

        Else
            x1.Cells.Add(SwmsUI.DataCell("<a href=""javascript:addPrep();"">Add New</a>", "center", 7))
        End If

        tblReadings.Rows.Add(x1)
    End Sub

    'adds a new meter reading 
    Sub addRdg()
        sql = "insert into meterReadings "
        sql &= " (MeterId, RdgDate, RdgValue, Status, FailHrsPerDay, Source, Comments)"
        sql &= " values (@MeterId, " ' MeterId
        sql &= " @RdgDate, " ' RdgDate
        sql &= " @RdgValue, " ' RdgValue
        sql &= " @status, "' status

        If IsNumeric(Request.Form("txtFh")) Then
            sql &= " @FailHrsPerDay, " 'FailHrsPerDay
        Else
            sql &= "NULL, "  ' ' FailHrsPerDay
        End If
        sql &= "'EditMeters.aspx', " ' Source
        sql &= " @comments)" ' Comments

        cmd.CommandText = sql    
        SwmsAccess.executeNonQuery(cmd)

        displayMeter(Request.QueryString("id"))
    End Sub

    'updates the selected reading
    Sub updRdg()

        sql = "update meterreadings set"
        sql &= " rdgDate =@RdgDate,"
        sql &= " rdgvalue = @RdgValue, "
        sql &= " Status = @status, "
        If CStr(Request.Form("txtFh")) = "" Then
            sql &= " failhrsperday = NULL, "
        Else
            If IsNumeric(Request.Form("txtFh")) Then
                sql &= " failhrsperday = @FailHrsPerDay, "
            End If
        End If
        sql &= " comments=@comments"
        sql &= " where (meterrdgid = @pick)"

        cmd.CommandText = sql
        SwmsAccess.executeNonQuery(cmd)
        
        txtPicked.Value = ""
        displayMeter(Request.QueryString("id"))
    End Sub

    'deletes the seleted mter reading
    Sub delRdg()

        sql = "delete from meterreadings where (meterrdgid = @pick)"
        cmd.CommandText = sql
        SwmsAccess.executeNonQuery(cmd)        

        displayMeter(Request.QueryString("id"))
    End Sub

#End Region


    Private Sub AAddValuesSqlCommandParameters()
            With cmd                        
                .Parameters.AddWithValue("@Serialnumber", Iif(Request.Form("txtSn")<>"", Server.HtmlEncode(Request.Form("txtSn")), ""))
                .Parameters.AddWithValue("@MeterType",  ddlMtrType.SelectedValue)
                .Parameters.AddWithValue("@Rollover", txtRolo.Text.Trim)
                .Parameters.AddWithValue("@peopleid",  Session("SWMSUId"))
                .Parameters.AddWithValue("@meterid", Request.QueryString("id"))
                .Parameters.AddWithValue("@pick",  txtPicked.Value)
                .Parameters.AddWithValue("@RdgDate", Iif(Request.Form("txtDate")<>"", Server.HtmlEncode(Request.Form("txtDate")), ""))
                .Parameters.AddWithValue("@RdgValue", Iif(Request.Form("txtValue")<>"", Server.HtmlEncode(Request.Form("txtValue")), ""))
                .Parameters.AddWithValue("@status", Iif(Request.Form("selStatus")<>"", Server.HtmlEncode(Request.Form("selStatus")), ""))
                .Parameters.AddWithValue("@FailHrsPerDay",  Iif(Request.Form("txtFh")<>"", Server.HtmlEncode(Request.Form("txtFh")), ""))
                .Parameters.AddWithValue("@comments",Iif(Request.Form("txtRdgCmt")<>"", Server.HtmlEncode(Left(Request.Form("txtRdgCmt"), 200)), ""))
                .Parameters.AddWithValue("@aid", Iif(Cstr(txtAid.Value)<>"", txtAid.Value, ""))
            End with
    End Sub
End Class
