﻿
Imports System
Imports System.Data

Partial Class Tracking_FindAssets
    Inherits System.Web.UI.Page

    #Region "declarations"
        Dim sql As String
    #End Region


    'Dim cC As New commonClass
    'Dim sql As String = ""
    ' --- CR 1753: add search by UMM

    #Region "Page_Load"
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            
            SwmsAccess.ValidateSession()

            ' Dim msg As String = cC.sessionCheck(Session("SWMSlvl"), Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"), "main")
            ' If msg <> "" Then
            '     Response.Redirect(msg)
            ' End If

            Select Case Request.QueryString("nxt")
                Case "config"
                    btnNew.Visible = False
                    txtNext.Value = "config"
                    lnkRet.NavigateUrl = "../Main/WalkAbout.aspx?d=Shop/ShopMenu.aspx&w=SWMSNET"
                Case "maint"
                    btnNew.Visible = True
                    txtNext.Value = "maint"
                    lnkRet.NavigateUrl = "../Main/Menu.aspx"
                Case Else
            End Select

            If Not Page.IsPostBack Then
                checkForMemories()
            End If

           Console.WriteLine ("Command Line: " & Environment.CommandLine)

        End Sub
    #End Region

    Private Sub checkForMemories()

        '--- remember what was selected last time I was here
        'sql = "select distinct FieldName, [Value] from memories where (Userid = " & Session("SWMSUId") & ") and (Page = 'FindAssets')"
        sql = "select distinct FieldName, [Value] from memories where (Userid = @Userid) and (Page = 'FindAssets')"

        'Dim rs As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))

       ' Try


        Dim rs As DataTable = SwmsAccess.ExecuteQueryToDataTable( sql, New SqlClient.SqlParameter() {
            New SqlClient.SqlParameter("@Userid", Session("SWMSUId"))
        })

        If rs.Rows.Count > 0 Then ' --yes - I've been here before
            Dim i As Integer
            For i = 0 To rs.Rows.Count - 1
                Dim FieldName As String = rs.Rows(i)("FieldName")
                
                Select Case FieldName
                    Case "NIIN"
                        txtNiin.Text = rs.Rows(i)("Value")
                    Case "PartNumber"
                        txtPn.Text = rs.Rows(i)("Value")
                    Case "SerialNumber"
                        txtSn.Text = rs.Rows(i)("Value")
                    Case "ModelNumber"
                        txtModel.Text = rs.Rows(i)("Value")
                End Select
                
            Next
            ' --- if anything exists, go ahead and populate the table
            displayAssets()

        End If


        'Catch ex as Exception
            'Console.WriteLine("Error {0}", ex.Message)

       ' End Try

    End Sub

    Sub headerRow()
        Dim x1 As New TableRow

        x1.Cells.Add(SwmsUI.DataCell("Part #", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("NIIN", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("umm", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Serial #", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Nomenclature", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Model #", "center", , , , "LightSteelBlue"))
        x1.Cells.Add(SwmsUI.DataCell("Asset Id", "center", , , , "LightSteelBlue"))
        x1.CssClass = "smBContent"
        assetsTab.Rows.Add(x1)
    End Sub

    Sub displayAssets()
        headerRow()

        sql = "SELECT  top 1000 at.AssetId, at.PID, isnull(pm.PartNumber,'') as PartNumber, "
        sql &= " isnull(at.SerialNumber,'') as SerialNumber, isnull(at.modelnumber,'') as ModelNumber, "
        sql &= " isnull(pm.nomenclature,'') as Nomen, isnull(pm.niin,'') as NIIN, isnull(pm.erpmatlmaster,'') as UMM, "
        sql &= " (select count(id) as thecount from bomhierarchy "
        sql &= "    where parent = at.PID and ConfigItem = 1) as Children "
        sql &= " FROM Assets AS at "
        sql &= "    INNER JOIN PartsMaster AS pm ON pm.PID = at.Pid"
        sql &= " WHERE (AssetId IS NOT NULL)"


        If CStr(txtModel.Text) <> "" Then
            'sql &= " AND (at.ModelNumber LIKE '%" & cC.BufStr(txtModel.Text.Trim) & "%')"
            sql &= " AND (at.ModelNumber LIKE @ModelNumber) "
        End If
        If Cstr(txtSn.Text) <> "" Then
            'sql &= " AND (at.SerialNumber LIKE '%" & cC.BufStr(txtSn.Text.Trim) & "%')"
            sql &= " AND (at.SerialNumber LIKE @SerialNumber)"
        End If
        If Cstr(txtPn.Text) <> "" Then
            'sql &= " AND (pm.PartNumber LIKE '%" & cC.BufStr(txtPn.Text.Trim) & "%')"
            sql &= " AND (pm.PartNumber LIKE @PartNumber)"
        End If
        If CStr(txtUmm.Text) <> "" Then
            sql &= " AND (pm.ERPMatlMaster LIKE @UMM)"
        End If
        'do stuff here to make it work with or without the dashes ------
        If CStr(txtNiin.Text) <> "" Then
            sql &= " AND (pm.niin LIKE @NIIN)"
        End If



        sql &= " ORDER BY pm.PartNumber, at.SerialNumber"

        'Dim rs As DataTable = cC.getAsDataTable(sql, Session("swmsDbConnection"))
        Dim rs as DataTable = SwmsAccess.ExecuteQueryToDataTable(sql, new SqlClient.SqlParameter(){
            New SqlClient.SqlParameter("@NIIN", "%" & txtNiin.Text.Trim & "%" ),
            New SqlClient.SqlParameter("@SerialNumber", "%" & txtSn.Text.Trim & "%"),
            New SqlClient.SqlParameter("@PartNumber", "%" & txtPn.Text.Trim & "%"),
            New SqlClient.SqlParameter("@UMM", "%" & txtUmm.Text.Trim & "%"),
            New SqlClient.SqlParameter("@ModelNumber", "%" & txtModel.Text.Trim & "%")
        })





        If rs.Rows.Count > 0 Then
            Dim altRow As Boolean = False

            Dim i As Integer
            For i = 0 To rs.Rows.Count - 1
                Dim x1 As New TableRow

                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("PartNumber"), "center"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("NIIN"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("UMM"), "center", , , "false"))
                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("SerialNumber"), "center"))

                If Len(rs.Rows(i)("nomen")) > 40 Then
                    x1.Cells.Add(SwmsUI.DataCell(Left(rs.Rows(i)("nomen"), 37) & "...", "left", , rs.Rows(i)("nomen")))
                Else
                    x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("nomen"), "nomen"))
                End If

                x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("ModelNumber"), "center"))

                If txtNext.Value = "config" Then
                    If CStr(rs.Rows(i)("children")) = "0" Then
                        x1.Cells.Add(SwmsUI.DataCell(rs.Rows(i)("assetid"), "center"))
                    Else
                        x1.Cells.Add(SwmsUI.DataCell("<a href=""javascript:picMe(" & rs.Rows(i)("AssetId") & ");"">" & rs.Rows(i)("AssetId") & "</a>", "center"))
                    End If
                Else
                    x1.Cells.Add(SwmsUI.DataCell("<a href=""javascript:picMe(" & rs.Rows(i)("AssetId") & ");"">" & rs.Rows(i)("AssetId") & "</a>", "center"))
                End If

                If txtNext.Value = "config" Then
                    If CStr(rs.Rows(i)("children")) = "0" Then
                        x1.ToolTip = "No template exists for this parent Asset"
                        x1.ForeColor = System.Drawing.Color.SlateGray
                    Else
                        x1.Attributes.Add("onClick", "picMe(" & rs.Rows(i)("AssetId") & ");")
                        x1.Style.Add("cursor", "hand")
                    End If
                Else
                    x1.Attributes.Add("onClick", "picMe(" & rs.Rows(i)("AssetId") & ");")
                    x1.Style.Add("cursor", "hand")
                End If

                If altRow = True Then
                    x1.BackColor = System.Drawing.Color.WhiteSmoke
                    altRow = False
                Else
                    altRow = True
                End If
                If rs.Rows(i)("AssetId") = Request.QueryString("id") Then
                    x1.BackColor = System.Drawing.Color.PaleGreen
                End If
                assetsTab.Rows.Add(x1)
            Next

        End If

        If rs.Rows.Count = 0 Then
            lblRowCount.Text = "No records found"
        Else
            If rs.Rows.Count = 1000 Then
                lblRowCount.Text = "Only the first 1000 records are displayed."
                lblRowCount.Text &= "<br>Please try entering more criteria to narrow down your search."
            Else
                lblRowCount.Text = rs.Rows.Count & " Records found"
            End If

        End If

    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        If Session("DB") = "SDSWMS" Then
            Response.Redirect("EditAssetSD.aspx")
        Else
            Response.Redirect("EditAsset.aspx")
        End If

    End Sub

    Protected Sub btnClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnClear.Click
        '--- clear memories

        sql = " DELETE FROM Memories WHERE (Page = 'FindAssets' AND UserId = " & Session("SWMSUId") & ")"
        
        SwmsAccess.ExecuteNonQuery(sql, new SqlClient.SqlParameter() _
        {
            New SqlClient.SqlParameter("@Userid", Session("SWMSUId"))
        })

        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        txtNiin.Text = ""
        txtPn.Text = ""
        txtSn.Text = ""
        txtModel.Text = ""
        txtUmm.Text = ""

    End Sub

    Protected Sub btnFind_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnFind.Click

        Dim cmd As Data.SqlClient.SqlCommand = New SqlClient.SqlCommand()

        With cmd            
            .Parameters.AddWithValue("@Userid", Session("SWMSUId"))    
            .Parameters.AddWithValue("@NIIN", txtNiin.Text.Trim)
            .Parameters.AddWithValue("@SerialNumber", txtSn.Text.Trim)
            .Parameters.AddWithValue("@PartNumber", txtPn.Text.Trim)
            .Parameters.AddWithValue("@ModelNumber", txtModel.Text.Trim)
        End With

        '--- clear existing memories
        sql = " DELETE FROM Memories WHERE (Page = 'FindAssets') AND (Userid = @Userid) ;"    

        ' '--- create memories ---
        If CStr(txtNiin.Text) <> "" Then
            sql &= " insert into memories (Page, FieldName, [Value], Userid)"
            sql &= " values ('FindAssets', 'NIIN', @NIIN , @Userid); "
            
        End If

        If CStr(txtPn.Text) <> "" Then
            sql &= " insert into memories (Page, FieldName, [Value], UserId)"
            sql &= " values ('FindAssets', 'PartNumber', @PartNumber, @Userid);"
        End If

        If CStr(txtSn.Text) <> "" Then
            sql &= " insert into memories (Page, FieldName, [Value], UserId)"
            sql &= " values ('FindAssets', 'SerialNumber', @SerialNumber, @Userid);"
        End If

        If CStr(txtModel.Text) <> "" Then
            sql &= " insert into memories (Page, FieldName, [Value], UserId)"            
            sql &= " values ('FindAssets', 'ModelNumber', @ModelNumber, @Userid);"
        End If

        cmd.CommandText = sql        

        SwmsAccess.ExecuteNonQuery(cmd)

        displayAssets()

    End Sub
End Class
