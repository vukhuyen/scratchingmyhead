﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class Tracking_NIINChangeSD
    Inherits System.Web.UI.Page

    Dim cC As New commonClass

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("SWMSlvl") < 10 Or Session("SWMSlvl") = Nothing) Then
            Response.Redirect("../Main/WalkAbout.aspx?d=Default.aspx&w=MNT")
        Else
            cC.HitCount(Session("SWMSUId"), Request.ServerVariables("URL"), Request.ServerVariables("Remote_Addr"), Session("swmsDbConnection"))
        End If
        If Session("UserMsg") <> "" And Session("UserMsg") <> Nothing Then
            UsrMsg.Value = Session("UserMsg")
            Session("UserMsg") = ""
        End If
        ' Inventory, Inventory/Specialist may maintain Assets.  All others read only.)
        '   33  Inventory
        '   55  Inventory/Scheduler(Specialist)
        '   43  QA Inspector
        '   47  QA Manager
        '   98  Database Admin
        '   99	Developer
        Dim strSQL As String = "SELECT CASE WHEN EXISTS (SELECT FunctionClassId FROM SWMSSecurity.dbo.PeopleFunctionClasses WHERE "
        'strSQL &= " (PeopleId = " & Session("SWMSUId") & ") AND (FunctionClassId IN (98, 99))) THEN 'True' ELSE 'False' END AS Granted "
        strSQL &= " (PeopleId = " & Session("SWMSUId") & ") AND (FunctionClassId IN (47, 55, 98, 99))) THEN 'True' ELSE 'False' END AS Granted "
        Dim dtSecur As DataTable = cC.getAsDataTable(strSQL, Session("SWMSDBConnection"), , Session("SWMSUID").ToString, "Tracking\NIINChangeSD.aspx.vb - Page_Load()")
        If dtSecur.Rows.Count > 0 Then
            If dtSecur.Rows(0).Item("Granted") = True Then
                'good to go
            Else
                Session("UserMsg") = "You are not authorized to use that page."
                Response.Redirect("../Main/Menu.aspx")
            End If
        Else
            Session("UserMsg") = "You are not authorized to use that page."
            Response.Redirect("../Main/Menu.aspx")
        End If
        '
        lblMessage.Text = ""
        '
        If Not Page.IsPostBack Then
            fillddls()
            '("./NIINChangeSD.aspx?id=" & Request.QueryString("id") & "&Nniin=" & txtNewNIIN.Text & "&Cr=" & Request.Form("ddlReason") & "&Ed=" & Request.Form("txtEffDate"))
            Dim assetid As Integer = 0
            If IsNumeric(Request.QueryString("id")) Then
                assetid = Request.QueryString("id")
            End If
            Dim sql As String = "DECLARE @Id int; SET @Id =" & assetid.ToString
            '   /* are multiple parts available with the same NIIN? */
            sql &= "; SELECT PM.NIIN, COUNT(*) AS NIINcnt, A.SerialNumber"
            sql &= " FROM PartsMaster PM, Assets A"
            sql &= " WHERE (PM.NIIN = A.NIIN)"
            sql &= " AND (A.AssetId = @Id)"
            sql &= " GROUP BY PM.NIIN, A.SerialNumber;"
            '
            Dim swmsDb As New SqlConnection
            Dim sqldt As DataTable = Nothing

            Try
                swmsDb.ConnectionString = Session("swmsDbConnection")
                swmsDb.Open()
                Dim SqlCmd As New SqlCommand(sql, swmsDb)
                Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
                sqldt = New DataTable("Results")
                sqlDA.Fill(sqldt)
            Catch ex As Exception
                cC.sendExEmail("AST/Tracking/NIINChangeSD.aspx.vb", sql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/NIINChangeSD.aspx")
                Throw ex
            Finally
                swmsDb.Close()
                swmsDb.Dispose()
            End Try

            If sqldt.Rows.Count <> 1 Then
                lblMessage.Text = "The From Asset could not be found with the NIIN & Serial Number entered.<br/>"
            Else
                hidNIINcnt.Value = sqldt.Rows(0).Item("NIINcnt")
                txtFrNIIN.Text = sqldt.Rows(0).Item("NIIN")
                txtSer.Text = sqldt.Rows(0).Item("SerialNumber")
                txtToNIIN.Text = Request.QueryString("Nniin")
                ddlReason.SelectedIndex = ddlReason.Items.IndexOf(ddlReason.Items.FindByValue(Request.QueryString("Cr")))
                'txtEffectiveDate.Text = Request.QueryString("Ed")
                lnkRet.NavigateUrl = "./MaintainAssetSD.aspx?id=" & assetid
            End If

        End If        'Else    'Page.IsPostBack

        Dim valid As Boolean = True
        'test for valid date
        'If txtEffectiveDate.Text <> "" Then
        '    '    If IsDate(Request.Form("txtEffectiveDate")) = False Then
        '    '        lblMessage.Text &= Chr(13) & "Valid date required for Effective Date (" & Request.Form("txtEffectiveDate") & ")"
        '    '        valid = False
        '    '    Else
        '    '        If CDate(Request.Form("txtEffectiveDate")) > CDate(Today) Then
        '    '            lblMessage.Text &= Chr(13) & "Effective Date may not be in the future (" & Request.Form("txtEffectiveDate") & ")"
        '    '            valid = False
        '    '        End If
        '    '    End If
        '    If IsDate(txtEffectiveDate.Text) = False Then
        '        lblMessage.Text &= Chr(13) & "Valid date required for Effective Date (" & txtEffectiveDate.Text & ")"
        '        valid = False
        '    Else
        '        If CDate(txtEffectiveDate.Text) > CDate(Today) Then
        '            lblMessage.Text &= Chr(13) & "Effective Date may not be in the future (" & txtEffectiveDate.Text & ")"
        '            valid = False
        '        End If
        '    End If
        'End If
        If ddlReason.SelectedIndex <= 0 Then
            lblMessage.Text &= Chr(13) & "Why are you doing this?  A Reason required."
            valid = False
        End If
        If txtSer.Text.Trim.Length <= 0 Then
            lblMessage.Text &= Chr(13) & "Serial Number is required."
            valid = False
        End If
        If txtFrNIIN.Text = txtToNIIN.Text And txtFrNIIN.Text.Trim.Length = 11 Then
            If hidNIINcnt.Value = "1" Then
                lblMessage.Text &= Chr(13) & "To NIIN is the same as From NIIN.  No change found."
                valid = False
            End If
        End If
        If txtFrNIIN.Text.Trim.Length <> 11 Then
            lblMessage.Text &= Chr(13) & "From NIIN required format is nn-nnn-nnnn."
            valid = False
        End If
        If txtToNIIN.Text.Trim.Length <> 11 Then
            lblMessage.Text &= Chr(13) & "To NIIN required format is nn-nnn-nnnn."
            valid = False
        End If
        If valid = True Then
            testitout()
        End If
        'End If
    End Sub

    Sub testitout()
        '1. test for unique old asset
        '2. test for new asset in the partsmaster
        '3. test for unique new asset & current status

        Dim Overwrite_Issued_Asset As Boolean = False

        Dim sql As String = ""
        sql = " DECLARE @OldNiin varchar(11);"
        sql &= " DECLARE @NewNiin varchar(11);"
        sql &= " DECLARE @SerialNum varchar(50);"
        sql &= " DECLARE @NewPid int;"
        sql &= " SELECT @OldNiin = '" & txtFrNIIN.Text & "', @NewNiin = '" & txtToNIIN.Text & "', @SerialNum = '" & txtSer.Text & "', @NewPid = " & hidNewPid.Value & ";"
        '
        sql &= " SELECT "
        sql &= " ISNULL(MAX(OldAssetId), 0) AS OldAssetId, ISNULL(MAX(OldAssetLocation), 0) AS OldAssetLocation,"
        sql &= " @NewPid AS NewPid, ISNULL(MAX(MasterNIIN), 'n/a') AS MasterNIIN, "
        sql &= " ISNULL(MAX(MakeBuy), 'n/a') AS MakeBuy, ISNULL(MAX(Serialized), 'n/a') AS Serialized,  "
        sql &= " ISNULL(MAX(NewAssetId), 0) AS NewAssetId, ISNULL(MAX(Status), 'n/a') AS Status, "
        sql &= " ISNULL(MAX(Location), 'n/a') AS Location, "
        sql &= " ISNULL(MAX(Building), 'n/a') AS Building, ISNULL(MAX(Bin), 'n/a') AS Bin"
        sql &= " FROM ("
        sql &= "    SELECT AssetId AS OldAssetId, LocationId AS OldAssetLocation,  "
        sql &= "    NULL AS MasterNIIN, NULL AS MakeBuy, NULL AS Serialized, "
        sql &= "    NULL AS NewAssetId, NULL AS Status, NULL AS Location, NULL AS Building, NULL AS Bin"
        sql &= "    FROM Assets WHERE (NIIN = @OldNIIN) AND (SerialNumber = @SerialNum)"
        sql &= "    UNION"
        sql &= "    SELECT NULL AS OldAssetId, NULL AS OldAssetLocation, "
        sql &= "    NIIN AS MasterNIIN, MakeBuy, Serialized, "
        sql &= "    NULL AS NewAssetId, NULL AS Status, NULL AS Location, NULL AS Building, NULL AS Bin"
        sql &= "    FROM PartsMaster WHERE (NIIN = @NewNIIN)"
        sql &= "    UNION"
        sql &= "    SELECT NULL AS OldAssetId, NULL AS OldAssetLocation, "
        sql &= "    NULL AS MasterNIIN, NULL AS MakeBuy, NULL AS Serialized, "
        sql &= "    A.AssetId AS NewAssetId, L1.LocationIdCode AS Status, L2.LocationIdCode AS Location, "
        sql &= "    L3.LocationIdCode AS Building, L4.LocationIdCode AS Bin"
        sql &= "    FROM Assets A "
        sql &= "    LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationID"
        sql &= "    LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationID"
        sql &= "    LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationID"
        sql &= "    LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationID"
        sql &= "    WHERE (A.NIIN = @NewNIIN) AND (A.SerialNumber = @SerialNum)"
        sql &= " ) tt;"

        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing

        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(sql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/CommonClass.vb - getAsDataTable()", sql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/NIINChange.aspx")
            Throw ex
        Finally
            swmsDb.Close()
        End Try

        If sqldt.Rows.Count <> 1 Then
            lblMessage.Text = "The From Asset could not be found with the NIIN & Serial Number entered.<br/>"
        Else
            hidOldAssetId.Value = sqldt.Rows(0).Item("OldAssetId")
            'what's it all mean?
            lblMessage.Text = ""
            Dim errMsg As String = ""
            If sqldt.Rows(0).Item("OldAssetId") <= 0 Then
                errMsg &= "Original Asset not found by From NIIN & Serial Number.<br/>"
            End If
            If sqldt.Rows(0).Item("MakeBuy") <> "M" Then
                errMsg &= "The new NIIN is not defined as a Make part.  Please check Parts Master for this part.<br/>"
                errMsg &= "<a href='../Main/WalkAbout.aspx?w=PLN&d=Library/PartsEdit.aspx?id=" & sqldt.Rows(0).Item("NewPid") & "'>Library - Parts Edit</a>"
            End If
            If sqldt.Rows(0).Item("Serialized") <> "Y" Then
                errMsg &= "The new NIIN is not defined as Serialized.  Please check Parts Master for this part.<br/>"
                errMsg &= "<a href='../Main/WalkAbout.aspx?w=PLN&d=Library/PartsEdit.aspx?id=" & sqldt.Rows(0).Item("NewPid") & "'>Library - Parts Edit</a>"
            End If
            If sqldt.Rows(0).Item("NewAssetId") <> 0 Then
                If hidNIINcnt.Value <> "1" And sqldt.Rows(0).Item("NewAssetId") = sqldt.Rows(0).Item("OldAssetId") Then
                    'allow special case: changing NIIN to same NIIN with multiple parts
                Else
                    If sqldt.Rows(0).Item("Status") = "ACTIVE" Then
                        errMsg &= "The new Asset, with NIIN & Serial Number, already exists at: " & sqldt.Rows(0).Item("Location")
                        errMsg &= " - " & sqldt.Rows(0).Item("Building") & " - " & sqldt.Rows(0).Item("Bin") & "<br/>"
                    Else    ' ISSUED status
                        'errMsg &= "New asset identified as issued.  "
                        Overwrite_Issued_Asset = True
                    End If
                End If
            End If
            '
            If errMsg <> "" Then
                'report the error(s)
                lblMessage.Text = errMsg
                errMsg = ""

                btnSub.Disabled = True

            Else
                'show asset before 
                shoBefore()

                If hidAction.Value = "Test" Then
                    btnSub.Disabled = False
                Else
                    ChangeIt()
                    hidAction.Value = "Test"
                End If

            End If

        End If
    End Sub

    Sub shoHeader(ByVal state As String, ByVal thisAsset As String)
        '
        Dim hdr As New TableRow
        Dim hc0 As New TableCell
        hc0.Text = ""
        hc0.ToolTip = "State of Asset " & thisAsset
        hdr.Cells.Add(hc0)
        '  
        Dim hc1 As New TableCell
        hc1.Text = "NIIN"
        hc1.ToolTip = "NIIN"
        hdr.Cells.Add(hc1)
        '  
        Dim hc2 As New TableCell
        If state = "Before" Then
            hc2.Text = "PP"
            hc2.ToolTip = "Primary Part for this NIIN"
        Else
            hc2.Text = "SN"
            hc2.ToolTip = "Serial Number"
        End If
        hdr.Cells.Add(hc2)
        '  
        Dim hc3 As New TableCell
        If state = "Before" Then
            hc3.Text = "SEL"
            hc3.ToolTip = "Selection"
        Else
            hc3.Text = "CC"
            hc3.ToolTip = "Condition Code"
        End If

        hdr.Cells.Add(hc3)
        '  
        Dim hc4 As New TableCell
        hc4.Text = "Part"
        hc4.ToolTip = "Part Number"
        hdr.Cells.Add(hc4)
        '  
        Dim hc5 As New TableCell
        hc5.Text = "Nomenclature"
        hc5.ToolTip = "Nomenclature"
        hdr.Cells.Add(hc5)
        '  
        Dim hc6 As New TableCell
        hc6.Text = "Model"
        hc6.ToolTip = "Model Number"
        hdr.Cells.Add(hc6)
        '  
        Dim hc7 As New TableCell
        hc7.Text = "CAGE"
        hc7.ToolTip = "Commercial And Government Entity Code "
        hdr.Cells.Add(hc7)
        '  
        'Dim hc8 As New TableCell
        'hc8.Text = "ICN"
        'hc8.ToolTip = "Internal Control Number"
        'hdr.Cells.Add(hc8)
        '  
        hdr.CssClass = "smBContent"
        If state = "Before" Then
            hdr.BackColor = Drawing.Color.SkyBlue
        Else
            hdr.BackColor = Drawing.Color.LightGreen
        End If
        BeforeAndAfter.Rows.Add(hdr)
        '

    End Sub

    Sub shoBefore()

        Dim bsql As String = ""
        bsql &= "DECLARE @OldNiin varchar(11);"
        bsql &= " DECLARE @NewNiin varchar(11);"
        bsql &= " DECLARE @SerialNum varchar(50);"
        '
        bsql &= " SELECT @OldNiin = '" & txtFrNIIN.Text & "', @NewNiin = '" & txtToNIIN.Text & "', @SerialNum = '" & txtSer.Text & "';"
        '
        bsql &= " SELECT Context, AssetId, NIIN,"
        bsql &= " CASE WHEN PP = '0' THEN"
        bsql &= " 	CASE WHEN NIINcnt = 1 THEN '1'"
        bsql &= " 	ELSE '0' END"
        bsql &= " ELSE PP END AS TruePP, Pid,"
        bsql &= " Part, Nomenclature, Model, CAGE, Serial, cC, ICN"
        bsql &= " FROM ("
        bsql &= " 	SELECT 'Before Change' AS Context, A1.AssetId, A1.NIIN,"
        bsql &= " 	ISNULL(P1.PrimaryPart, '0') AS PP,"
        bsql &= " 	(SELECT COUNT(*) FROM PartsMaster PM"
        bsql &= " 	 WHERE (PM.NIIN = @OldNiin) GROUP BY PM.NIIN) AS NIINcnt,"
        bsql &= " 	A1.Pid, A1.PartNumber AS Part, A1.Nomenclature,"
        bsql &= " 	ISNULL(A1.ModelNumber, '') AS Model, ISNULL(A1.Manufacturer, '') AS CAGE,"
        bsql &= " 	A1.SerialNumber AS Serial, A1.CurrentCondition AS CC,"
        bsql &= "   Case A1.SubGroup"
        bsql &= " 		WHEN 'CICPOVHL' THEN"
        bsql &= "           A1.ICNnum + '-' + RIGHT('0000' + CAST(A1.ICNseq AS varchar(4)), 4)"
        bsql &= " 		ELSE"
        bsql &= "           ISNULL(A1.ICNnum, '')"
        bsql &= " 	END AS ICN"
        bsql &= " 	FROM Assets A1"
        bsql &= " 	INNER JOIN PartsMaster P1 ON A1.PID = P1.Pid"
        bsql &= " 	WHERE (A1.NIIN = @OldNiin) AND (A1.SerialNumber = @SerialNum)"
        '
        bsql &= "   UNION"
        '
        bsql &= " 	SELECT 'with Change' AS Context, A.AssetId,"
        bsql &= " 	PM.NIIN, ISNULL(PM.PrimaryPart, '0') AS PP,"
        bsql &= " 	(SELECT COUNT(*) FROM PartsMaster PM"
        bsql &= " 	 WHERE (PM.NIIN = @NewNiin) GROUP BY PM.NIIN) AS NIINcnt,"
        bsql &= " 	PM.Pid, PM.PartNumber AS Part, PM.Nomenclature,"
        bsql &= " 	ISNULL(PM.ModelNumber, '') AS Model, ISNULL(PM.CAGE, '') AS CAGE,"
        bsql &= " 	A.SerialNumber AS Serial, A.CurrentCondition AS CC,"
        bsql &= "   Case A.SubGroup"
        bsql &= " 		WHEN 'CICPOVHL' THEN"
        bsql &= "           A.ICNnum + '-' + RIGHT('0000' + CAST(A.ICNseq AS varchar(4)), 4)"
        bsql &= " 		ELSE"
        bsql &= "           ISNULL(A.ICNnum, '')"
        bsql &= " 	END AS ICN"
        bsql &= " 	FROM Assets A, PartsMaster PM"
        bsql &= " 	WHERE (A.NIIN = @OldNiin) AND (A.SerialNumber = @SerialNum)"
        bsql &= " 	AND (PM.NIIN = @NewNiin)"
        bsql &= " ) X"
        bsql &= " ORDER BY Context, PP DESC;"

        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing

        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(bsql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/Tracking/NIINChangeSD.aspx - shoBefore()", bsql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/NIINChangeSD.aspx")
            Throw ex
        Finally
            swmsDb.Close()
        End Try

        ' BeforeAndAfter
        Dim i As Integer = 0
        Do While i <= sqldt.Rows.Count - 1
            '
            If i = 0 Then
                shoHeader("Before", sqldt.Rows(i).Item("AssetId").ToString)
            End If
            '
            Dim trx As New TableRow
            If i = 0 Then
                trx.ID = "trxBefor"
            Else
                trx.ID = "trxChng" & i.ToString
                trx.Attributes.Add("Name", "Candidates")
            End If

            Dim tc0 As New TableCell
            tc0.Text = sqldt.Rows(i).Item("Context")
            tc0.CssClass = "smBContent"
            trx.Cells.Add(tc0)
            '  
            Dim tc1 As New TableCell
            tc1.Text = sqldt.Rows(i).Item("NIIN")
            tc1.Wrap = False
            trx.Cells.Add(tc1)
            '  
            Dim tc2 As New TableCell
            If sqldt.Rows(i).Item("TruePP") = "1" Then
                tc2.Text = "*"
            Else
                tc2.Text = "&nbsp;"
            End If
            tc2.Wrap = False
            trx.Cells.Add(tc2)
            '  
            Dim tc3 As New TableCell
            If sqldt.Rows(i).Item("Context") = "Before Change" Then
                tc3.Text = ""
            ElseIf sqldt.Rows(i).Item("TruePP") = "1" Then
                If hidAction.Value = "Submit" Then
                    hidNewPid.Value = Request.Form("hidNewPid")
                Else
                    hidNewPid.Value = sqldt.Rows(i).Item("Pid")
                End If
                tc3.Text = "<input id='rd" & sqldt.Rows(i).Item("Pid") & "' name='selPart' type='radio' value='" & sqldt.Rows(i).Item("Pid") & "' checked='checked' onclick=""setNewPid(this.value)"" />"
            Else
                tc3.Text = "<input id='rd" & sqldt.Rows(i).Item("Pid") & "' name='selPart' type='radio' value='" & sqldt.Rows(i).Item("Pid") & "' onclick=""setNewPid(this.value)"" />"
            End If
            tc3.Wrap = False
            trx.Cells.Add(tc3)
            '  
            Dim tc4 As New TableCell
            tc4.Text = sqldt.Rows(i).Item("Part")
            tc4.Wrap = False
            trx.Cells.Add(tc4)
            '  
            Dim tc5 As New TableCell
            tc5.Text = sqldt.Rows(i).Item("Nomenclature")
            tc5.Wrap = False
            trx.Cells.Add(tc5)
            '  
            Dim tc6 As New TableCell
            If sqldt.Rows(i).Item("Model") = "" Then
                tc6.Text = "&nbsp;"
            Else
                tc6.Text = sqldt.Rows(i).Item("Model")
            End If
            tc6.Wrap = False
            trx.Cells.Add(tc6)
            '  
            Dim tc7 As New TableCell
            If sqldt.Rows(i).Item("CAGE") = "" Then
                tc7.Text = "&nbsp;"
            Else
                tc7.Text = sqldt.Rows(i).Item("CAGE")
            End If
            tc7.Wrap = False
            trx.Cells.Add(tc7)
            '  
            '  
            'Dim tc2 As New TableCell
            'tc2.Text = sqldt.Rows(i).Item("Serial")
            'tc2.Wrap = False
            'trx.Cells.Add(tc2)
            ''  
            'Dim tc3 As New TableCell
            'tc3.Text = sqldt.Rows(i).Item("CC")
            'tc3.Wrap = False
            'trx.Cells.Add(tc3)
            ''
            'Dim tc8 As New TableCell
            'tc8.Text = sqldt.Rows(i).Item("ICN")
            'tc8.Wrap = False
            'trx.Cells.Add(tc8)
            '  
            If sqldt.Rows(i).Item("Context") = "Before Change" Then
                trx.BackColor = Drawing.Color.White
            ElseIf sqldt.Rows(i).Item("TruePP") = "1" Then
                trx.BackColor = Drawing.Color.WhiteSmoke
            Else
                trx.BackColor = Drawing.Color.White
            End If
            'trx.BackColor = Drawing.Color.LightGray
            BeforeAndAfter.Rows.Add(trx)
            i += 1
        Loop

    End Sub

    Sub ChangeIt()
        ''If ddlReason.SelectedValue = "A/6 MODIFY UNIT" Then
        ''    'Modify Asset
        ''    ModifyAsset()
        ''ElseIf ddlReason.SelectedValue = "F/7 WRONG MATERIAL" Then
        ''    'Change Asset
        ''    CorrectAsset()
        ''Else    'CORRECTION
        ''    'Correct Asset
        ''    CorrectAsset()
        ''End If

        Dim sql As String
        sql = "AssetNIINChange"
        Dim swmsDb As New SqlConnection(Session("swmsDbConnection"))
        swmsDb.Open()
        Dim sqlCmd As SqlCommand

        Try
            sqlCmd = New SqlCommand(sql, swmsDb)
            sqlCmd.CommandType = CommandType.StoredProcedure
            sqlCmd.Parameters.AddWithValue("@UserId", Session("SWMSUId").ToString)
            sqlCmd.Parameters.AddWithValue("@Reason", ddlReason.SelectedValue.ToString)
            sqlCmd.Parameters.AddWithValue("@OldNiin", txtFrNIIN.Text.ToString)
            sqlCmd.Parameters.AddWithValue("@SerialNum", txtSer.Text.ToString)
            sqlCmd.Parameters.AddWithValue("@NewNiin", txtToNIIN.Text.ToString)
            sqlCmd.Parameters.AddWithValue("@NewPid", hidNewPid.Value)
            'sqlCmd.Parameters.AddWithValue("@ReportedDate", txtEffectiveDate.Text.ToString)

            sqlCmd.ExecuteNonQuery()
 
        Catch ex As Exception
            lblMessage.Text = ex.Message

        End Try
        shoAfter()
        btnSub.Disabled = True

    End Sub

    Sub shoAfter()

        Dim asql As String = ""
        asql &= "DECLARE @NewNiin varchar(11);"
        asql &= " DECLARE @SerialNum varchar(50);"
        '
        asql &= " SELECT @NewNiin = '" & txtToNIIN.Text & "', @SerialNum = '" & txtSer.Text & "'"
        '
        asql &= " SELECT 'After' AS Context, AssetId, "
        asql &= " NIIN, SerialNumber AS Serial, CurrentCondition AS CC, PartNumber AS Part, Nomenclature, "
        asql &= " ISNULL(ModelNumber, '') AS Model, ISNULL(Manufacturer, '') AS CAGE, "
        asql &= " CASE SubGroup "
        asql &= " 	WHEN 'CICPOVHL' THEN"
        asql &= " 		ICNnum + '-' + RIGHT('0000' + CAST(ICNseq AS varchar(4)), 4)"
        asql &= " 	ELSE"
        asql &= " 		ISNULL(ICNnum, '')"
        asql &= " END AS ICN		"
        asql &= " FROM Assets"
        asql &= " WHERE (NIIN = @NewNiin) AND (SerialNumber = @SerialNum)"

        Dim swmsDb As New SqlConnection
        Dim sqldt As DataTable = Nothing

        Try
            swmsDb.ConnectionString = Session("swmsDbConnection")
            swmsDb.Open()
            Dim SqlCmd As New SqlCommand(asql, swmsDb)
            Dim sqlDA As SqlDataAdapter = New SqlDataAdapter(SqlCmd)
            sqldt = New DataTable("Results")
            sqlDA.Fill(sqldt)
        Catch ex As Exception
            cC.sendExEmail("AST/Tracking/NIINChangeSD.aspx -shoAfter()", asql, ex, Session("swmsDbConnection"), Session("SWMSUId"), "AST/Tracking/NIINChangeSD.aspx")
            Throw ex
        Finally
            swmsDb.Close()
        End Try

        ' BeforeAndAfter
        If sqldt.Rows.Count > 0 Then

            shoHeader("After", sqldt.Rows(0).Item("AssetId").ToString)

            lnkRet.NavigateUrl = "./MaintainAssetSD.aspx?id=" & sqldt.Rows(0).Item("AssetId")
            '
            Dim trx As New TableRow
            trx.ID = "trxAfter"

            Dim tc0 As New TableCell
            tc0.Text = sqldt.Rows(0).Item("Context")
            tc0.CssClass = "smBContent"
            trx.Cells.Add(tc0)
            '  
            Dim tc1 As New TableCell
            tc1.Text = sqldt.Rows(0).Item("NIIN")
            tc1.Wrap = False
            trx.Cells.Add(tc1)
            '  
            Dim tc2 As New TableCell
            tc2.Text = sqldt.Rows(0).Item("Serial")
            tc2.Wrap = False
            trx.Cells.Add(tc2)
            '  
            Dim tc3 As New TableCell
            tc3.Text = sqldt.Rows(0).Item("CC")
            tc3.Wrap = False
            trx.Cells.Add(tc3)
            '  
            Dim tc4 As New TableCell
            tc4.Text = sqldt.Rows(0).Item("Part")
            tc4.Wrap = False
            trx.Cells.Add(tc4)
            '  
            Dim tc5 As New TableCell
            tc5.Text = sqldt.Rows(0).Item("Nomenclature")
            tc5.Wrap = False
            trx.Cells.Add(tc5)
            '  
            Dim tc6 As New TableCell
            tc6.Text = sqldt.Rows(0).Item("Model") & "&nbsp;"
            tc6.Wrap = False
            trx.Cells.Add(tc6)
            '  
            Dim tc7 As New TableCell
            tc7.Text = sqldt.Rows(0).Item("CAGE")
            tc7.Wrap = False
            trx.Cells.Add(tc7)
            '  
            'Dim tc8 As New TableCell
            'tc8.Text = sqldt.Rows(0).Item("ICN") & "&nbsp;"
            'tc8.Wrap = False
            'trx.Cells.Add(tc8)
            '  
            trx.BackColor = Drawing.Color.WhiteSmoke
            BeforeAndAfter.Rows.Add(trx)
        End If
    End Sub

#Region "extracode"
    'Sub ModifyAsset()
    '    '/*  A6-Modify  */
    '    '	A new asset is created from the old asset with the new/correct NIIN information and
    '    '	a history record stating that the new asset was: the old asset modified to the new asset via A-6 Modify        
    '    ' 	The old asset gets a history record stating that the old asset has been changed to the new asset
    '    '   The old asset gets updated to show it is not "ACTIVE"
    '    '
    '    Dim mSql As String = ""
    '    mSql &= " DECLARE @SWMSUId int"
    '    mSql &= " DECLARE @OldNiin varchar(11)"
    '    mSql &= " DECLARE @OldPid int"
    '    mSql &= " DECLARE @SerialNum varchar(50)"
    '    mSql &= " DECLARE @OldAssetId int"
    '    mSql &= " DECLARE @NewNiin varchar(11)"
    '    mSql &= " DECLARE @NewPid int"
    '    mSql &= " DECLARE @NewAssetId int"
    '    mSql &= " DECLARE @ReportedDate datetime"
    '    mSql &= " DECLARE @RightNow datetime"
    '    mSql &= " SELECT @RightNow = Getdate()"
    '    '
    '    If txtEffectiveDate.Text <> "" Then
    '        mSql &= " SELECT @ReportedDate = '" & txtEffectiveDate.Text & "', @SWMSUId = " & Session("SWMSUId")
    '    Else
    '        mSql &= " SELECT @ReportedDate = @RightNow, @SWMSUId = " & Session("SWMSUId")
    '    End If
    '    mSql &= " SELECT @OldNiin = '" & txtFrNIIN.Text & "', @NewNiin = '" & txtToNIIN.Text & "', @SerialNum = '" & txtSer.Text & "'"
    '    '    /* Identify the new Pid */        
    '    mSql &= " SELECT @NewPid = Pid FROM PartsMaster WHERE NIIN = @NewNiin"
    '    '    /* Identify the old AssetId and Pid */
    '    mSql &= " SELECT @OldAssetId = AssetId, @OldPid = Pid FROM Assets WHERE NIIN = @OldNiin and SerialNumber = @SerialNum"
    '    '
    '    '   /* create new asset */
    '    mSql &= " INSERT INTO Assets"
    '    mSql &= " (Pid, PartNumber, Revision, NIIN, Nomenclature, "
    '    mSql &= " SerialNumber, ModelNumber, Manufacturer, ICNnum, ICNseq, "
    '    mSql &= " CurrentCondition, LocationId, Location2, Location3, Location4, "
    '    mSql &= " LastMoved, Remarks, SubGroup, DocumentNumber, Reason, "
    '    mSql &= " ReceivedFrom, IssuedTo, EffectiveDate, "
    '    mSql &= " LastTrans, LastTransDate, LastTransBy, STOCKNO, "
    '    mSql &= " DateRecorded, BSSId, VendorId, ModFromPid, "
    '    mSql &= " PIN, IntendedUse, AcceptanceDate, "
    '    mSql &= " WarrantyBeginDate, WarrantyExpireDate, "
    '    mSql &= " A_Cond_Date, PackingStatus, ShipWeight, "
    '    mSql &= " ShipLength, ShipWidth, ShipHeight, MarkFor)"
    '    mSql &= " SELECT"
    '    mSql &= " PM.Pid, PM.PartNumber, PM.Revision, PM.NIIN, PM.Nomenclature, "
    '    mSql &= " A.SerialNumber, PM.ModelNumber, PM.CAGE, A.ICNnum, A.ICNseq, "
    '    mSql &= " A.CurrentCondition, A.LocationId, A.Location2, "
    '    mSql &= " A.Location3, A.Location4, A.LastMoved, "
    '    mSql &= " 'MODIFIED FROM NIIN ' + @OldNiin + '. ' + LEFT(A.Remarks, 469) AS Remarks, "
    '    mSql &= " A.SubGroup, A.DocumentNumber, 'A/6 MODIFY UNIT' AS Reason, "
    '    mSql &= " 'MODIFIED FROM NIIN ' + @OldNiin AS ReceivedFrom, "
    '    mSql &= " NULL AS IssuedTo, @ReportedDate AS EffectiveDate, "
    '    mSql &= " 'RECEIVED MODIFIED ASSET' AS LastTrans, @RightNow AS LastTransDate, "
    '    mSql &= " @SWMSUId AS LastTransBy, A.STOCKNO, A.DateRecorded, "
    '    mSql &= " A.BSSId, A.VendorId, A.Pid AS ModFromPid, A.PIN, "
    '    mSql &= " A.IntendedUse, A.AcceptanceDate, NULL AS WarrantyBeginDate, "
    '    mSql &= " NULL AS WarrantyExpireDate, A.A_Cond_Date, A.PackingStatus, "
    '    mSql &= " ISNULL(PM.ShipWeight, A.ShipWeight) AS ShipWeight,"
    '    mSql &= " ISNULL(PM.ShipLength, A.ShipLength) AS ShipLength,"
    '    mSql &= " ISNULL(PM.ShipWidth, A.ShipWidth) AS ShipWidth,"
    '    mSql &= " ISNULL(PM.ShipHeight, A.ShipHeight) AS ShipHeight,"
    '    mSql &= " A.MarkFor"
    '    mSql &= " FROM Assets A, PartsMaster PM"
    '    mSql &= " WHERE (A.AssetId = @OldAssetId) AND (PM.Pid = @NewPid);"
    '    '
    '    '   /* get the new AssetId */
    '    mSql &= " SELECT @NewAssetId = MAX(AssetId) "
    '    mSql &= " FROM Assets "
    '    mSql &= " WHERE (LastTransBy = @SWMSUId) AND (Pid = @NewPid);"
    '    '
    '    '   /* insert new asset history */
    '    mSql &= " INSERT INTO AssetHistory ("
    '    mSql &= " AssetId, ConditionCode, TransType, TransDate, TransBy,"
    '    mSql &= " Remarks, Reason, "
    '    mSql &= " LocationId, Location2, Location3, Location4, "
    '    mSql &= " Location1Text, Location2Text, Location3Text, Location4Text, "
    '    mSql &= " EffectiveDate, oldAssetId, oldId, "
    '    mSql &= " ICNnum, ICNSeq, SubGroup, ReceivedFrom, "
    '    mSql &= " IssuedTo, PIN)"
    '    mSql &= " SELECT "
    '    mSql &= " A.AssetId, A.CurrentCondition AS ConditionCode, A.LastTrans AS TransType, "
    '    mSql &= " A.LastTransDate AS TransDate, A.LastTransBy AS TransBy,"
    '    mSql &= " 'MODIFIED FROM NIIN ' + @OldNiin + '. ' AS Remarks, A.Reason, "
    '    mSql &= " A.LocationId, A.Location2, A.Location3, A.Location4, "
    '    mSql &= " L1.LocationIdCode AS Location1Text, L2.LocationIdCode AS Location2Text, "
    '    mSql &= " L3.LocationIdCode AS Location3Text, L4.LocationIdCode AS Location4Text, "
    '    mSql &= " A.EffectiveDate, @OldAssetId AS oldAssetId, @OldPid AS oldId, "
    '    mSql &= " A.ICNnum, A.ICNSeq, A.SubGroup, A.ReceivedFrom, "
    '    mSql &= " A.IssuedTo, A.PIN "
    '    mSql &= " FROM Assets A"
    '    mSql &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationID"
    '    mSql &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationID"
    '    mSql &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationID"
    '    mSql &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationID"
    '    mSql &= " WHERE (A.AssetId = @NewAssetId);"
    '    '
    '    '/* retire old asset record */
    '    mSql &= " UPDATE Assets SET LocationId = 2, Location2 = NULL, Location3 = NULL, Location4 = NULL,"
    '    mSql &= " Remarks = 'MODIFIED TO NEW NIIN ' + @NewNiin + '. ' + LEFT(Remarks, 466),"
    '    mSql &= " Reason = 'A/6 MODIFY UNIT', IssuedTo = 'MODIFIED TO NEW NIIN ' + @NewNiin,"
    '    mSql &= " EffectiveDate = @ReportedDate, LastMoved = @RightNow, LastTrans = 'MODIFIED ASSET', "
    '    mSql &= " LastTransDate = @RightNow, LastTransBy = @SWMSUId, "
    '    mSql &= " IntendedUse = 'New AssetId:' + CAST(@NewAssetId AS varchar(10))"
    '    mSql &= " WHERE (NIIN = @OldNiin) AND (SerialNumber = @SerialNum); "
    '    '
    '    '   /* insert old asset history */
    '    mSql &= " INSERT INTO AssetHistory ("
    '    mSql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, "
    '    mSql &= " LocationId, Location2, Location3, Location4,"
    '    mSql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
    '    mSql &= " Status,"
    '    mSql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
    '    mSql &= " SELECT "
    '    mSql &= " AssetId, CurrentCondition AS ConditionCode, 'Change NIIN' AS TransType, "
    '    mSql &= " @RightNow AS TransDate, @SWMSUId AS TransBy, "
    '    mSql &= " 'MODIFIED TO NEW NIIN ' + @NewNiin + '. ' AS Remarks, 'A/6 MODIFY UNIT' AS Reason, "
    '    mSql &= " 2 AS LocationId, NULL AS Location2, NULL AS Location3, NULL AS Location4, "
    '    mSql &= " 'ISSUED' AS Location1Text, NULL AS Location2Text, NULL AS Location3Text, NULL AS Location4Text, "
    '    mSql &= " 'ISSUED' AS Status, @ReportedDate AS EffectiveDate, "
    '    mSql &= " ICNnum, ICNSeq, SubGroup, ReceivedFrom, 'MODIFIED TO NEW NIIN ' + @NewNiin AS IssuedTo, "
    '    mSql &= " PIN"
    '    mSql &= " FROM Assets "
    '    mSql &= " WHERE (NIIN = @OldNiin) AND (SerialNumber = @SerialNum); "
    '    '
    '    cC.executeNonQuery(mSql, Session("swmsDbConnection"))

    '    ' logit
    '    cC.LogIt("assets", "Assets: niin:" & txtFrNIIN.Text & " S/N:" & txtSer.Text & " Modified to niin:" & txtToNIIN.Text & ".", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))

    'End Sub

    'Sub CorrectAsset()
    ''       /* Change NIIN for Asset due to F/7 Wrong Material or Correction */
    'Dim csql As String = ""
    '    csql &= " DECLARE @ReportedDate datetime"
    '    csql &= " DECLARE @SWMSUId int"
    '    csql &= " DECLARE @ThisAssetId int"
    '    csql &= " DECLARE @NewPid int"
    '    csql &= " DECLARE @XtraAssetId int"
    '    csql &= " DECLARE @OldNiin varchar(11)"
    '    csql &= " DECLARE @NewNiin varchar(11)"
    '    csql &= " DECLARE @SerialNum varchar(50)"
    '    csql &= " DECLARE @RightNow datetime"
    ''
    '    csql &= " SELECT @RightNow = Getdate()"
    '    If txtEffectiveDate.Text <> "" Then
    '        csql &= " SELECT @ReportedDate = '" & txtEffectiveDate.Text & "', @SWMSUId = " & Session("SWMSUId")
    '    Else
    '        csql &= " SELECT @ReportedDate = @RightNow, @SWMSUId = " & Session("SWMSUId")
    '    End If
    '    csql &= " SELECT @OldNiin = '" & txtFrNIIN.Text & "', @NewNiin = '" & txtToNIIN.Text & "', @SerialNum = '" & txtSer.Text & "'"
    ''       /* Identify the new Pid */        
    '    csql &= " SELECT @NewPid = Pid FROM PartsMaster WHERE NIIN = @NewNiin"
    ''       /* Identify the old AssetId */
    '    csql &= " SELECT @ThisAssetId = AssetId FROM Assets WHERE NIIN = @OldNiin and SerialNumber = @SerialNum"
    ''
    ''       /* update existing asset */
    '    csql &= " UPDATE Assets"
    '    csql &= " SET PID = PM.Pid,"
    '    csql &= " PartNumber = PM.PartNumber,"
    '    csql &= " Revision = NULL, "
    '    csql &= " NIIN = PM.NIIN,"
    '    csql &= " Nomenclature = PM.Nomenclature,"
    '    csql &= " ModelNumber = PM.ModelNumber,"
    '    csql &= " Manufacturer = PM.Cage,"
    '    csql &= " Reason = 'CORRECTION',"
    '    csql &= " Remarks = 'CORRECTED NIIN FROM ' + @OLDNiin + '. ' + LEFT(Remarks, 466)"
    '    csql &= " FROM Assets A, PartsMaster PM"
    '    csql &= " WHERE A.AssetId = @ThisAssetId"
    '    csql &= " AND PM.Pid = @NewPid; "
    ''
    ''       /* insert history for existing asset */
    '    csql &= "INSERT INTO AssetHistory ("
    '    csql &= " AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, "
    '    csql &= " LocationId, Location2, Location3, Location4,"
    '    csql &= " Location1Text, Location2Text, Location3Text, Location4Text,"
    '    csql &= " Status,"
    '    csql &= " EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
    '    csql &= " SELECT "
    '    csql &= " A.AssetId, A.CurrentCondition AS ConditionCode, 'Change NIIN' AS TransType, "
    '    csql &= " @RightNow AS TransDate, @SWMSUId AS TransBy, "
    '    csql &= " 'CORRECTED NIIN FROM ' + @OLDNiin + '. ' AS Remarks, 'CORRECTION' AS Reason, "
    '    csql &= " A.LocationId, A.Location2, A.Location3, A.Location4, "
    '    csql &= " L1.LocationIdCode AS Location1Text, L2.LocationIdCode AS Location2Text, "
    '    csql &= " L3.LocationIdCode AS Location3Text, L4.LocationIdCode AS Location4Text, "
    '    csql &= " 'ACTIVE' AS Status, @ReportedDate AS EffectiveDate, "
    '    csql &= " A.ICNnum, A.ICNSeq, A.SubGroup, NULL AS ReceivedFrom, NULL AS IssuedTo, "
    '    csql &= " A.PIN"
    '    csql &= " FROM Assets A"
    '    csql &= " LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationID"
    '    csql &= " LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationID"
    '    csql &= " LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationID"
    '    csql &= " LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationID"
    '    csql &= " WHERE A.AssetId = @ThisAssetId"
    ''
    '    cC.executeNonQuery(csql, Session("swmsDbConnection"))

    '' logit
    '    cC.LogIt("assets", "Assets: niin:" & txtFrNIIN.Text & " S/N:" & txtSer.Text & " Corrected to niin:" & txtToNIIN.Text & ".", Session("PQnum"), Request.ServerVariables("Remote_Addr"), Session("SWMSUId"), "", Session("swmsDbConnection"))

    'End Sub

    'Sub PrepForNewAsset()
    '    'move all old asset history to new asset
    '    'copy old asset record to Archive 
    '    'Remove excess row from Assets
    '    Dim psql As String = ""
    '    psql &= " DECLARE @OldNiin varchar(11)"
    '    psql &= " DECLARE @NewNiin varchar(11)"
    '    psql &= " DECLARE @SerialNum varchar(50)"
    '    psql &= " DECLARE @ThisAssetId int"
    '    psql &= " DECLARE @XtraAssetId int"

    '    psql &= " SELECT @OldNiin = '" & txtFrNIIN.Text & "', @NewNiin = '" & txtToNIIN.Text & "', @SerialNum = '" & txtSer.Text & "'"
    '    '       /* Identify the AssetId to be corrected */
    '    psql &= " SELECT @ThisAssetId = AssetId FROM Assets WHERE NIIN = @OldNiin and SerialNumber = @SerialNum"
    '    '       /* Identify the extra AssetId */        
    '    psql &= " SELECT @XtraAssetId = AssetId FROM Assets WHERE NIIN = @NewNiin and SerialNumber = @SerialNum"
    '    '
    '    '        /* Transfer History */
    '    psql &= " UPDATE AssetHistory SET AssetId = @ThisAssetId WHERE AssetId = @XtraAssetId;"
    '    '
    '    '       /* Copy to AssetArchive */
    '    psql &= " INSERT INTO AssetArchive "
    '    psql &= " (AssetId, PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber, "
    '    psql &= " ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition, "
    '    psql &= " LocationId, Location2, Location3, Location4, LastMoved, "
    '    psql &= " Remarks, SubGroup, DocumentNumber, Reason, ReceivedFrom, "
    '    psql &= " IssuedTo, EffectiveDate, LastTrans, LastTransDate, LastTransBy, "
    '    psql &= " STOCKNO, DateRecorded, BSSId, VendorId, ModFromPid, PIN, IntendedUse, "
    '    psql &= " AcceptanceDate, WarrantyBeginDate, WarrantyExpireDate, "
    '    psql &= " A_Cond_Date, PackingStatus, ShipWeight, ShipLength, ShipWidth, ShipHeight, "
    '    psql &= " NewId, ArchiveDate, ArchiveBy)"
    '    psql &= " SELECT AssetId, PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber, "
    '    psql &= " ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition, "
    '    psql &= " LocationId, Location2, Location3, Location4, LastMoved, "
    '    psql &= " Remarks, SubGroup, DocumentNumber, Reason, ReceivedFrom, "
    '    psql &= " IssuedTo, EffectiveDate, LastTrans, LastTransDate, LastTransBy, "
    '    psql &= " STOCKNO, DateRecorded, BSSId, VendorId, ModFromPid, PIN, IntendedUse, "
    '    psql &= " AcceptanceDate, WarrantyBeginDate, WarrantyExpireDate, "
    '    psql &= " A_Cond_Date, PackingStatus, ShipWeight, ShipLength, ShipWidth, ShipHeight, "
    '    psql &= " @ThisAssetId AS NewId, GetDate() AS ArchiveDate, " & Session("SWMSUId") & " AS ArchiveBy"
    '    psql &= " FROM Assets "
    '    psql &= " WHERE (AssetId = @XtraAssetId);"
    '    '
    '    '       /* Remove excess row from Assets */ 
    '    psql &= " DELETE Assets WHERE AssetId = @XtraAssetId;"
    '    '
    '    cC.executeNonQuery(psql, Session("swmsDbConnection"))

    'End Sub

    'Sub somecode()
    '    '/* Change NIIN of Assets (due to mis typing or F7-Wrong Material or A6-Modify */"

    '    '/*	The old asset gets a history record stating that the old asset has been changed to the new asset
    '    '	A new asset is created from the old asset with the new/correct NIIN information and
    '    '	a history record stating that the new asset was: the old asset modified to the new asset via A-6 Modify
    '    '	or the old asset was wrongly identified and is corrected to the new asset due to F-7 Wrong Material or mis-typing */

    '    '--SELECT * FROM Assets WHERE NIIN = '01-550-8484' and SerialNumber = 'S4-666'

    '    '--SELECT * FROM AssetHistory WHERE AssetId = (SELECT AssetId FROM Assets WHERE NIIN = '01-550-8484' and SerialNumber = 'S4-666')

    '    '--SELECT * FROM PartsMaster WHERE NIIN = '01-550-8476'

    '    sql &= " DECLARE @ReportedDate datetime"
    '    sql &= " DECLARE @SWMSUId int"
    '    sql &= " DECLARE @OldNiin varchar(11);"
    '    sql &= " DECLARE @NewNiin varchar(11);"
    '    sql &= " DECLARE @SerialNum varchar(50);"
    '    sql &= " SELECT @SWMSUId = 60, @OldNiin = '01-550-8484', @NewNiin = '01-550-8476', @SerialNum = 'S4-765', @ReportedDate = Getdate()"

    '    '    /* Change Asset NIIN via A/6 Modify Unit */

    '    sql &= " DECLARE @NewPid int"
    '    sql &= " DECLARE @NewAssetId int"
    '    sql &= " DECLARE @OldAssetId int"
    '    sql &= " DECLARE @RightNow datetime"
    '    sql &= " SELECT @RightNow = Getdate()"

    '    sql &= " SELECT @OldAssetId = AssetId FROM Assets WHERE (NIIN = @OldNiin) AND (SerialNumber = @SerialNum)"
    '    sql &= " SELECT @NewPid = Pid FROM PartsMaster WHERE (NIIN = @NewNiin)"

    '    '--first test items 
    '    sql &= " if EXISTS(SELECT AssetId FROM Assets WHERE (NIIN = @OldNiin) AND (SerialNumber = @SerialNum)) "
    '    sql &= " begin"
    '    sql &= " 	if EXISTS(SELECT AssetId FROM Assets WHERE (NIIN = @NewNiin) AND (SerialNumber = @SerialNum))"
    '    sql &= " 	begin"
    '    sql &= " 		select '--update existing new asset'"
    '    '--UPDATE Assets
    '    '--SET PID = PM.Pid,
    '    '--PartNumber = PM.PartNumber,
    '    '--Revision = NULL, 
    '    '--NIIN = PM.NIIN,
    '    '--Nomenclature = PM.Nomenclature,
    '    '--ModelNumber = PM.ModelNumber,
    '    '--Manufacturer = PM.Cage
    '    '--FROM Assets A, PartsMaster PM
    '    '--WHERE A.AssetId = 86778
    '    '--AND PM.Pid = 10619
    '    sql &= "                            End"
    '    sql &= " 	else"
    '    sql &= " 	begin"
    '    '		--insert new asset
    '    sql &= " 		INSERT INTO Assets ("
    '    sql &= " 		PID, PartNumber, Revision, NIIN, Nomenclature, SerialNumber,"
    '    sql &= " 		ModelNumber, Manufacturer, ICNnum, ICNseq, CurrentCondition,"
    '    sql &= " 		LocationId, Location2, Location3, Location4, Remarks,"
    '    sql &= " 		SubGroup, DocumentNumber, Reason, ReceivedFrom, IssuedTo,"
    '    sql &= " 		EffectiveDate, LastMoved, LastTrans, LastTransDate, LastTransBy,"
    '    sql &= " 		DateRecorded, PIN, AcceptanceDate, ModFromPid)"
    '    sql &= " 		SELECT	 "
    '    sql &= " 		PM.PID, PM.PartNumber, PM.Revision, PM.NIIN, PM.Nomenclature, A.SerialNumber,"
    '    sql &= " 		PM.ModelNumber, PM.CAGE AS Manufacturer, A.ICNnum, A.ICNseq, A.CurrentCondition,"
    '    sql &= " 		A.LocationId, A.Location2, A.Location3, A.Location4, "
    '    sql &= "        'MODIFIED FROM NIIN ' + @OldNiin + '. ' + LEFT(Remarks, 469) AS Remarks,"
    '    sql &= " 		A.SubGroup, A.DocumentNumber, 'A/6 MODIFY UNIT' AS Reason, "
    '    sql &= "        'MODIFIED FROM NIIN ' + @OldNiin AS ReceivedFrom, NULL AS IssuedTo,"
    '    sql &= " 		@ReportedDate AS EffectiveDate, @RightNow AS LastMoved, 'RECEIVED MODIFIED ASSET' AS LastTrans, "
    '    sql &= " 		@RightNow AS LastTransDate, @SWMSUId AS LastTransBy,"
    '    sql &= " 		@RightNow AS DateRecorded, A.PIN, AcceptanceDate, A.Pid AS ModFromPid"
    '    sql &= " 		FROM Assets A, PartsMaster PM"
    '    sql &= " 		WHERE A.AssetId = @OldAssetId"
    '    sql &= " 		AND PM.Pid = @NewPid "
    '    sql &= " 		SELECT @NewAssetId = SCOPE_IDENTITY() "

    '    '		--insert new asset history
    '    sql &= " 		INSERT INTO AssetHistory ("
    '    sql &= " 		AssetId, ConditionCode, TransType, TransDate, TransBy,"
    '    sql &= " 		Remarks, Reason, 
    '    sql &= "         LocationId, Location2, Location3, Location4, "
    '    sql &= "         Location1Text, Location2Text, Location3Text, Location4Text, "
    '    sql &= "         EffectiveDate, oldAssetId, oldId, "
    '    sql &= "         ICNnum, ICNSeq, SubGroup, ReceivedFrom, "
    '    sql &= "         IssuedTo, PIN)"
    '    sql &= " 		SELECT "
    '    sql &= "         A.AssetId, A.CurrentCondition AS ConditionCode, A.LastTrans AS TransType, "
    '    sql &= " 		 A.LastTransDate AS TransDate, A.LastTransBy AS TransBy,"
    '    sql &= "        'MODIFIED FROM NIIN ' + @OldNiin + '. ' AS Remarks, A.Reason, 
    '    sql &= "         A.LocationId, A.Location2, A.Location3, A.Location4, "
    '    sql &= "         L1.LocationIdCode AS Location1Text, L2.LocationIdCode AS Location2Text, "
    '    sql &= "         L3.LocationIdCode AS Location3Text, L4.LocationIdCode AS Location4Text, "
    '    sql &= "         A.EffectiveDate, A.AssetId AS oldAssetId, A.Pid AS oldId, "
    '    sql &= "         A.ICNnum, A.ICNSeq, A.SubGroup, A.ReceivedFrom, "
    '    sql &= "         A.IssuedTo, A.PIN "
    '    sql &= "         FROM Assets A"
    '    sql &= "         LEFT OUTER JOIN Locations L1 ON A.LocationId = L1.LocationID"
    '    sql &= "         LEFT OUTER JOIN Locations L2 ON A.Location2 = L2.LocationID"
    '    sql &= "         LEFT OUTER JOIN Locations L3 ON A.Location3 = L3.LocationID"
    '    sql &= "         LEFT OUTER JOIN Locations L4 ON A.Location4 = L4.LocationID"
    '    sql &= "         WHERE (A.AssetId = @NewAssetId)"
    '    ' 		--
    '    sql &= "     End"
    '    '	--update old asset
    '    sql &= " 	UPDATE Assets SET LocationId = 2, Location2 = NULL, Location3 = NULL, Location4 = NULL,"
    '    sql &= " 	Remarks = 'MODIFIED TO NEW NIIN ' + @NewNiin + '. ' + LEFT(Remarks, 466),"
    '    sql &= " 	Reason = 'A/6 MODIFY UNIT', IssuedTo = 'MODIFIED TO NEW NIIN ' + @NewNiin,"
    '    sql &= " 	EffectiveDate = @ReportedDate, LastMoved = @RightNow, LastTrans = 'MODIFIED ASSET', "
    '    sql &= " 	LastTransDate = @RightNow, LastTransBy = @SWMSUId, IntendedUse = 'New AssetId:' + CAST(@NewAssetId AS varchar(10))"
    '    sql &= " 	WHERE (NIIN = @OldNiin) AND (SerialNumber = @SerialNum); "

    '    '--insert old asset history
    '    sql &= " 	INSERT INTO AssetHistory ("
    '    sql &= "     AssetId, ConditionCode, TransType, TransDate, TransBy, Remarks, Reason, "
    '    sql &= "     LocationId, Location2, Location3, Location4,"
    '    sql &= "     Location1Text, Location2Text, Location3Text, Location4Text,"
    '    sql &= "     Status,"
    '    sql &= "     EffectiveDate, ICNnum, ICNSeq, SubGroup, ReceivedFrom, IssuedTo, PIN )"
    '    sql &= "     SELECT "
    '    sql &= "     AssetId, CurrentCondition AS ConditionCode, 'Change NIIN' AS TransType, "
    '    sql &= "     @RightNow AS TransDate, @SWMSUId AS TransBy, "
    '    sql &= "     'MODIFIED TO NEW NIIN ' + @NewNiin + '. ' AS Remarks, 'A/6 MODIFY UNIT' AS Reason,  "
    '    sql &= "     2 AS LocationId, NULL AS Location2, NULL AS Location3, NULL AS Location4, "
    '    sql &= "     'ISSUED' AS Location1Text, NULL AS Location2Text, NULL AS Location3Text, NULL AS Location4Text, "
    '    sql &= "     'ISSUED' AS Status, @ReportedDate AS EffectiveDate, "
    '    sql &= "     ICNnum, ICNSeq, SubGroup, ReceivedFrom, 'MODIFIED TO NEW NIIN ' + @NewNiin AS IssuedTo, "
    '    sql &= "     PIN"
    '    sql &= "     FROM Assets "
    '    sql &= "     WHERE (NIIN = @OldNiin) AND (SerialNumber = @SerialNum); "
    '    sql &= " END "

    'End Sub
#End Region

    Sub fillddls()
        '
        ' reason -------------------------------------
        ddlReason.Items.Clear()
        ddlReason.Items.Add(New ListItem("-", "-"))
        ddlReason.Items.Add(New ListItem("A/6 MODIFY UNIT", "A/6 MODIFY UNIT"))
        ddlReason.Items.Add(New ListItem("F/7 WRONG MATERIAL", "F/7 WRONG MATERIAL"))
        ddlReason.Items.Add(New ListItem("CORRECTION", "CORRECTION"))
        '
    End Sub

End Class
